#!/usr/bin/env bash
# VERSION: 1.7 (2026-10-17)  installer of the plugin «مدیریت مجوزها» (kms-licenses v2.5.0: customers & licenses)
#   1.7: plugin 2.5.0: requests only as KMS-<TOKEN>.zip (AES-256, password from the name), form
#        fields + hardware shown and stored (schema v2), activation files as KMS-<TOKEN>.zip
#   1.6: plugin 2.4.2 for Outline 1.11.0 (koa-router -> @koa/router, type fix); the Outline source
#        folder and image tag are found from build/outline-* instead of being fixed to 1.10.1
#   1.5: plugin 2.4.1 (Persian digits in the duration fields no longer crash the page)
#   1.4: plugin 2.4.0 opens from Settings > License (patch 0010-plugin-hooks v2.1);
#        install.sh 10.5+ installs it itself (step 7), this script stays for a manual attach
#   1.3: plugin renamed «مدیریت مجوزها»; same id, data and keys, so it upgrades in place
#   1.2: own database kms_subscribers; independent of the Outline license; --purge
#   1.1: (withdrawn) tied the plugin to the Outline license
# =============================================================================
#  Attaches the plugin to an Outline installed by kms install.sh (10.0+), on the
#  vendor's own server only. Customers' installations never get it.
#
#  Needs: the install folder (e.g. /srv/kms) with build/outline-X.Y.Z patched
#  with the patch set (0010-plugin-hooks) and built once by install.sh (steps 4-10),
#  and the kms-license data folder (private.json, vendor-public.json, ledger.json).
#
#  The plugin is a separate app inside Outline: own database (kms_subscribers on
#  the same PostgreSQL server), own keys, and it keeps working when this
#  Outline's own license has expired, so an admin can always issue a new one.
#
#  What it does (each step asks first; Enter = yes):
#    0. creates the database kms_subscribers (owner: Outline's database user)
#    1. copies the vendor keys and ledger into <kms>/config/license/vendor
#       (seen read-only inside the container as /etc/kms-license/vendor)
#    2. copies the plugin into <kms>/build/outline-X.Y.Z/plugins/subscribers
#    3. yarn build (the same Node and Yarn install.sh used), then build/ into images/outline/app
#    4. rebuilds the kms/outline image
#    5. restarts only the outline container and waits until it is healthy
#    6. verifies the plugin and the keys inside the container
#
#  Usage: bash install-plugin.sh [--kms DIR] [--vendor DIR] [--yes] [--remove|--purge] [--version] [--help]
#    --kms DIR     install folder (default: from ~/kms/.kms-target, else /srv/kms)
#    --vendor DIR  kms-license data folder (default: ~/kms/Admin/kms-license-data)
#    --yes         default answers everywhere
#    --remove      detach: take the plugin out of Outline (database and keys stay)
#    --purge       detach and also drop the database kms_subscribers and the keys copy
#
#  Run it again after install.sh re-ran step 4 (a new patch set unzips a fresh
#  source tree without the plugin). Steps 7-10 of install.sh keep the plugin.
# =============================================================================
set -Eeuo pipefail

VERSION="1.7"
PLUGIN_VERSION="2.5.0"
SELF="$(readlink -f "${BASH_SOURCE[0]}")"; HERE="$(dirname "$SELF")"
PLUGIN_SRC="$HERE/plugin/subscribers"
PROJECT="kms"; OUTLINE_UID=1001

KMS=""; VENDOR=""; YES=0; REMOVE=0; PURGE=0; DB_NAME="kms_subscribers"
while (($#)); do
  case "$1" in
    --kms) KMS="${2:?--kms needs a folder}"; shift 2 ;;
    --vendor) VENDOR="${2:?--vendor needs a folder}"; shift 2 ;;
    --yes) YES=1; shift ;;
    --remove) REMOVE=1; shift ;;
    --purge) REMOVE=1; PURGE=1; shift ;;
    --version) echo "install-plugin.sh $VERSION (kms-licenses $PLUGIN_VERSION)"; exit 0 ;;
    --help|-h) sed -n '2,38p' "$SELF" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
done

if [[ -t 1 ]]; then C_G=$'\e[32m'; C_Y=$'\e[33m'; C_R=$'\e[31m'; C_B=$'\e[1m'; C_0=$'\e[0m'; else C_G=""; C_Y=""; C_R=""; C_B=""; C_0=""; fi
ok()   { printf '  [%sOK%s]   %s\n' "$C_G" "$C_0" "$*"; }
warn() { printf '  [%sWARN%s] %s\n' "$C_Y" "$C_0" "$*"; }
info() { printf '  [....] %s\n' "$*"; }
fail() { printf '  [%sFAIL%s] %s\n' "$C_R" "$C_0" "$*"; [[ -n ${LOG:-} ]] && printf '  Log: %s\n' "$LOG"; exit 1; }
section() { printf '\n%s==== %s ====%s\n' "$C_B" "$*" "$C_0"; }
trap 'fail "line $LINENO: $BASH_COMMAND"' ERR

ask_yn() { # ask_yn "question" default(y|n) ; Persian-layout keys accepted
  local q="$1" d="$2" a
  if ((YES)) || [[ ! -t 0 ]]; then [[ $d == y ]]; return; fi
  read -r -p "  $q [$([[ $d == y ]] && echo Y/n || echo y/N)] " a || a=""
  case "${a:-$d}" in y|Y|yes|غ|بله|ب) return 0 ;; n|N|no|د|خیر|خ) return 1 ;; *) [[ $d == y ]] ;; esac
}
ask_text() { local q="$1" d="$2" a; if ((YES)) || [[ ! -t 0 ]]; then echo "$d"; return; fi; read -r -p "  $q [$d] " a || a=""; echo "${a:-$d}"; }

if [[ $EUID -eq 0 ]]; then SUDO=""; else SUDO="sudo"; command -v sudo >/dev/null || fail "sudo is required."; sudo -v || fail "sudo access is required."; fi
dk() { if [[ -z $SUDO ]] || docker info >/dev/null 2>&1; then docker "$@"; else $SUDO docker "$@"; fi; }

section "kms-licenses plugin (مدیریت مجوزها) $PLUGIN_VERSION - install-plugin.sh $VERSION"
[[ -f $PLUGIN_SRC/plugin.json ]] || fail "No plugin/subscribers next to this script (unzip the whole package)."

# --- install folder -----------------------------------------------------------
if [[ -z $KMS ]]; then
  if [[ -f $HOME/kms/.kms-target ]]; then KMS="$(head -n1 "$HOME/kms/.kms-target")"; else KMS="/srv/kms"; fi
  KMS="$(ask_text "Install folder of kms" "$KMS")"
fi
KMS="$(readlink -f "$KMS")"
# The patched Outline source install.sh built last (the highest version in build/).
SRC_NAME="${SRC_NAME:-$(find "$KMS/build" -maxdepth 1 -type d -name 'outline-[0-9]*' -printf '%f\n' 2>/dev/null | sort -V | tail -n1)}"
[[ -n $SRC_NAME ]] || fail "No $KMS/build/outline-X.Y.Z: run kms install.sh step 4."
IMG_OUTLINE="kms/outline:${SRC_NAME#outline-}"
SRC="$KMS/build/$SRC_NAME"; APP="$KMS/images/outline/app"; CONFIG="$KMS/config"; VDIR="$CONFIG/license/vendor"
[[ -f $KMS/docker-compose.yml ]] || fail "$KMS has no docker-compose.yml: run kms install.sh first."
[[ -f $SRC/package.json ]] || fail "No $SRC: run install.sh step 4."
mkdir -p "$KMS/logs"; TS="$(date +%Y%m%d-%H%M%S)"; LOG="$KMS/logs/install-plugin-$TS.log"
exec > >(tee -a "$LOG") 2>&1
ok "Install folder: $KMS"

# The hooks of patch 0010-plugin-hooks must be in the source tree.
if ! grep -q 'SidebarLink = "sidebarLink"' "$SRC/app/utils/PluginManager.ts"; then
  fail "build/$SRC_NAME lacks patch 0010-plugin-hooks. Put the new patches.zip into the kit's assets/,
         run install.sh (steps 4, 7, 8, 10), then run this script again."
fi
ok "Patch 0010 (plugin hooks) is in build/$SRC_NAME"

# --- Node and Yarn as install.sh step 7 used them ----------------------------
if [[ -x $KMS/build/node/bin/node ]]; then NODE="$KMS/build/node/bin/node"; else NODE="$(command -v node || true)"; fi
[[ -n $NODE && -x $NODE ]] || fail "node not found (install.sh step 7 provides it)."
YJS="$KMS/build/yarn/package/bin/yarn.js"
[[ -f $YJS ]] || fail "No $YJS (install.sh step 7 provides it)."
export PATH="$(dirname "$NODE"):$PATH" YARN_ENABLE_TELEMETRY=0 YARN_NPM_REGISTRY_SERVER="${NPM_REGISTRY:-https://registry.npmjs.org}"
yarn_() { "$NODE" "$YJS" "$@"; }
ok "Node $("$NODE" -v), Yarn $(cd "$SRC" && yarn_ --version)"

dc() { (cd "$KMS" && dk compose -p "$PROJECT" -f "$KMS/docker-compose.yml" "$@"); }
PSQL=(exec -T postgres /usr/local/pgbin/psql -v ON_ERROR_STOP=1 -U postgres -d postgres -tA)
DB_OWNER="$($SUDO sed -n 's#^DATABASE_URL=postgres://\([^:@/]*\).*#\1#p' "$CONFIG/outline.env" 2>/dev/null | tail -n1)"; DB_OWNER="${DB_OWNER:-outline}"
db_exists() { [[ $(dc "${PSQL[@]}" -c "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" 2>/dev/null | tr -d '[:space:]') == 1 ]]; }
dc ps --status running postgres 2>/dev/null | grep -q postgres || fail "The postgres container is not running (start kms first: install.sh step 10)."

# --- 0. database --------------------------------------------------------------
if ((REMOVE == 0)); then
  section "0. Database $DB_NAME (separate from Outline's database)"
  if db_exists; then ok "Database $DB_NAME exists (kept as it is)"
  else
    dc "${PSQL[@]}" -c "CREATE DATABASE \"$DB_NAME\" OWNER \"$DB_OWNER\" ENCODING 'UTF8'" >/dev/null || fail "Could not create database $DB_NAME."
    ok "Database $DB_NAME created (owner $DB_OWNER); the plugin creates its tables on first use"
  fi
fi

# --- 1. vendor keys -----------------------------------------------------------
if ((REMOVE == 0)); then
  section "1. Vendor keys and ledger -> config/license/vendor"
  HAVE_KEYS=0; if $SUDO test -f "$VDIR/private.json"; then HAVE_KEYS=1; fi
  if ((HAVE_KEYS)); then info "config/license/vendor already holds keys."; fi
  if ask_yn "$( ((HAVE_KEYS)) && echo "Refresh them from the kms-license folder?" || echo "Copy the keys from the kms-license folder?")" "$( ((HAVE_KEYS)) && echo n || echo y)"; then
    [[ -n $VENDOR ]] || VENDOR="$(ask_text "kms-license data folder" "$HOME/kms/Admin/kms-license-data")"
    VENDOR="$(readlink -f "$VENDOR")"
    [[ -f $VENDOR/private.json ]] || fail "No $VENDOR/private.json."
    "$NODE" -e '
      const k = JSON.parse(require("fs").readFileSync(process.argv[1], "utf8"));
      if (!k.sign || !k.box || k.sign.crv !== "Ed25519" || k.box.crv !== "X25519") throw new Error("not a kms-license private.json");
      if (k.product && k.product !== "kms-outline") throw new Error("private.json is for product " + k.product);
    ' "$VENDOR/private.json" || fail "$VENDOR/private.json is not a kms-license key file."
    if ((HAVE_KEYS)) && ! $SUDO cmp -s "$VENDOR/private.json" "$VDIR/private.json"; then
      warn "The new private.json differs from the one installed. Licenses already issued stay tied to the old keys."
      ask_yn "Replace the keys anyway?" n || fail "Stopped; the installed keys were kept."
    fi
    if $SUDO test -d "$VDIR"; then
      $SUDO mkdir -p "$KMS/archive/$TS"; $SUDO cp -a "$VDIR" "$KMS/archive/$TS/kms-vendor"
      info "Previous copy kept in archive/$TS/kms-vendor"
    fi
    $SUDO mkdir -p "$VDIR"
    for f in private.json vendor-public.json ledger.json; do
      if [[ -f $VENDOR/$f ]]; then $SUDO install -m 640 -o 0 -g "$OUTLINE_UID" "$VENDOR/$f" "$VDIR/$f"; fi
    done
    for d in issued requests; do
      if [[ -d $VENDOR/$d ]]; then
        $SUDO rm -rf "$VDIR/$d"; $SUDO cp -r "$VENDOR/$d" "$VDIR/$d"
        $SUDO chown -R 0:"$OUTLINE_UID" "$VDIR/$d"; $SUDO find "$VDIR/$d" -type d -exec chmod 750 {} + ; $SUDO find "$VDIR/$d" -type f -exec chmod 640 {} +
      fi
    done
    $SUDO chown 0:"$OUTLINE_UID" "$VDIR"; $SUDO chmod 750 "$VDIR"
    ok "Keys and ledger in config/license/vendor ($( $SUDO ls "$VDIR" | tr '\n' ' '))"
  fi
  $SUDO test -f "$VDIR/private.json" || fail "config/license/vendor/private.json is missing: without it the plugin stays off."
fi

# --- 2. plugin source ---------------------------------------------------------
section "2. Plugin source -> build/$SRC_NAME/plugins/subscribers"
if [[ -d $SRC/plugins/subscribers ]]; then
  mkdir -p "$KMS/archive/$TS"; mv "$SRC/plugins/subscribers" "$KMS/archive/$TS/plugin-subscribers"
  info "Previous plugin moved to archive/$TS/plugin-subscribers"
fi
if ((REMOVE)); then
  ok "Plugin taken out of the source tree"
else
  cp -r "$PLUGIN_SRC" "$SRC/plugins/subscribers"
  ok "Plugin $PLUGIN_VERSION copied ($(find "$SRC/plugins/subscribers" -type f | wc -l) files)"
fi

# --- 3. build -----------------------------------------------------------------
section "3. Build Outline (yarn build: 10-30 minutes on an ARM board)"
if ask_yn "Build now?" y; then
  if [[ ! -d $SRC/node_modules ]]; then
    info "build/$SRC_NAME/node_modules is missing: yarn install --immutable"
    (cd "$SRC" && yarn_ install --immutable) || fail "yarn install failed."
  fi
  (cd "$SRC" && NODE_OPTIONS="--max-old-space-size=${BUILD_MEM_MB:-4096}" yarn_ build) || fail "yarn build failed (log: $LOG)."
  if ((REMOVE == 0)); then
    [[ -f $SRC/build/plugins/subscribers/server/index.js ]] || fail "The build has no build/plugins/subscribers."
  fi
  [[ -d $APP ]] || fail "No images/outline/app: run install.sh step 7 once."
  if command -v rsync >/dev/null; then rsync -a --delete "$SRC/build/" "$APP/build/"
  else rm -rf "$APP/build"; cp -a "$SRC/build" "$APP/build"; fi
  ok "images/outline/app/build updated"
else
  warn "Build skipped: the running Outline is unchanged."; exit 0
fi

# --- 4. image -----------------------------------------------------------------
section "4. Docker image $IMG_OUTLINE"
dk buildx version >/dev/null 2>&1 || export DOCKER_BUILDKIT=0
dk build --network host -t "$IMG_OUTLINE" "$KMS/images/outline" || fail "docker build failed."
if [[ -f $APP/.kms-patches ]]; then cp -f "$APP/.kms-patches" "$KMS/images/outline/.kms-patches-image"; fi
ok "Image $IMG_OUTLINE rebuilt"

# --- 5. restart ---------------------------------------------------------------
section "5. Restart outline"
dc up -d --no-deps --pull never --force-recreate outline >/dev/null || fail "Could not start outline."
end=$((SECONDS + 900)); code=000
while ((SECONDS < end)); do
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:3000/_health || true)"
  [[ $code == 200 ]] && break
  [[ $(dk inspect -f '{{.State.Status}}' kms-outline 2>/dev/null || echo missing) == running ]] || { dc logs --tail 60 outline; fail "outline stopped (logs above)."; }
  sleep 5
done
[[ $code == 200 ]] || { dc logs --tail 60 outline; fail "Outline did not become healthy (logs above)."; }
ok "outline is running and healthy"

# --- 6. verify ----------------------------------------------------------------
section "6. Verify"
if ((REMOVE)); then
  if dk exec kms-outline test ! -e build/plugins/subscribers; then ok "Plugin is gone from the running Outline"; else warn "build/plugins/subscribers still exists in the container"; fi
  if ((PURGE)); then
    section "Purge: database and keys"
    printf '  This deletes the database %s (all customers, requests, licenses, history)\n  and config/license/vendor. Type yes to continue: ' "$DB_NAME"
    if ((YES)); then a=no; else read -r a || a=""; fi
    if [[ $a == yes ]]; then
      if db_exists; then
        mkdir -p "$KMS/archive/$TS"
        dc exec -T postgres /usr/local/pgbin/pg_dump -U postgres -Fc "$DB_NAME" >"$KMS/archive/$TS/$DB_NAME.dump" && ok "Backup: archive/$TS/$DB_NAME.dump"
        dc "${PSQL[@]}" -c "DROP DATABASE \"$DB_NAME\"" >/dev/null && ok "Database $DB_NAME dropped"
      fi
      if $SUDO test -d "$VDIR"; then $SUDO mkdir -p "$KMS/archive/$TS"; $SUDO mv "$VDIR" "$KMS/archive/$TS/kms-vendor"; ok "Keys moved to archive/$TS/kms-vendor"; fi
    else warn "Purge not confirmed (with --yes it never runs): database and keys kept."; fi
  else
    printf '\n  Detached. Database %s and config/license/vendor were kept: attach again with install-plugin.sh.\n' "$DB_NAME"
  fi
  exit 0
fi
if dk exec kms-outline test -f build/plugins/subscribers/server/index.js; then ok "Plugin is in the running Outline"; else fail "Plugin is not in the container."; fi
if dk exec kms-outline test -r /etc/kms-license/vendor/private.json; then ok "Container can read /etc/kms-license/vendor/private.json"
else fail "The container cannot read the keys (expected 750/640 root:$OUTLINE_UID on config/license/vendor)."; fi
if dc logs --since 15m outline 2>/dev/null | grep -qi "Failed to load plugin.*subscribers"; then
  dc logs --since 15m outline | grep -i -A5 "subscribers" | tail -20; fail "Outline could not load the plugin (log above)."
fi
ok "No plugin load errors in the Outline log"
printf '\n  Done. Sign in as an admin: Settings -> مجوز -> «مدیریت مجوزها» opens /subscribers;\n'
printf '  its «تنظیمات» button shows the database and keys; «ورود دفتر kms-license» imports ledger.json once.\n'
printf '  Log: %s\n' "$LOG"
