// kms-licenses plugin v2.5.0
import * as React from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import Button from "~/components/Button";
import Heading from "~/components/Heading";
import Scene from "~/components/Scene";
import Text from "~/components/Text";
import { api, BASE_PATH, errorMessage, PLUGIN_VERSION, type Status } from "./api";
import { Card, CardTitle, Field, InfoGrid, Muted, Page, Warn } from "./components/ui";
import { faDate, faNum } from "./format";
import Icon from "./Icon";

export default function SubscribersSettings() {
  const [status, setStatus] = React.useState<Status | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);

  const load = React.useCallback(async () => {
    try {
      setStatus(await api.status());
      setError(null);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  const importLedger = async () => {
    setBusy(true);
    try {
      const r = await api.importLedger();
      toast.success(`${faNum(r.imported)} لایسنس وارد شد، ${faNum(r.skipped)} مورد از قبل بود`);
      await load();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Scene title="مدیریت مجوزها" icon={<Icon />}>
      <Page dir="rtl">
        <Heading>مدیریت مجوزها</Heading>
        <Text as="p" type="secondary">
          افزونه مستقل ثبت مشتریان، درخواست‌های لایسنس و صدور فایل فعال‌سازی (هر دو
          ‎KMS-….zip‎ رمزدار؛ رمز از روی نام فایل) و سابقه هر مشتری؛ سازگار با
          kms-license ۱٫۳ و پچ ۰۰۲۵. نسخه افزونه: {faNum(PLUGIN_VERSION)}
        </Text>

        {error ? (
          <Warn>
            افزونه روی سرور فعال نیست ({error}). install.sh را روی سرور اجرا کنید (مرحله‌ی ۷ و ۹)
            تا کلیدهای kms-license در config/license/vendor قرار بگیرد.
          </Warn>
        ) : !status ? (
          <Muted>در حال بارگذاری…</Muted>
        ) : (
          <>
            <Card>
              <CardTitle>
                برنامه
                <Button as={Link} to={BASE_PATH}>
                  باز کردن مدیریت مجوزها
                </Button>
              </CardTitle>
              <InfoGrid>
                <Field label="محصول" value={status.product} mono />
                <Field
                  label="مشتریان / لایسنس‌ها / در انتظار"
                  value={
                    status.database.counts
                      ? `${faNum(status.database.counts.customers)} / ${faNum(status.database.counts.licenses)} / ${faNum(status.database.counts.pending)}`
                      : null
                  }
                />
              </InfoGrid>
            </Card>

            {status.license.available && (
            <Card>
              <CardTitle>لایسنس اوت‌لاینِ همین سرور (فقط نمایش)</CardTitle>
              {status.license.readOnly && (
                <Warn>
                  اوت‌لاین این سرور فقط‌خواندنی است؛ افزونه مستقل است و برای تمدید آن
                  هم کار می‌کند.
                </Warn>
              )}
              <InfoGrid>
                <Field label="وضعیت" value={status.license.status} mono />
                <Field label="سریال" value={status.license.serial} mono />
                <Field label="مشتری" value={status.license.customer} />
                <Field label="اعتبار تا" value={faDate(status.license.expiresAt)} />
                <Field
                  label="روز مانده"
                  value={status.license.daysLeft === null ? null : faNum(Math.max(status.license.daysLeft, 0))}
                />
              </InfoGrid>
            </Card>
            )}

            <Card>
              <CardTitle>پایگاه داده افزونه</CardTitle>
              {status.database.ok ? (
                <InfoGrid>
                  <Field
                    label="محل"
                    value={status.separateDatabase ? "SUBSCRIBERS_DATABASE_URL" : "همان سرور PostgreSQL، پایگاه داده جدا"}
                  />
                  <Field label="پایگاه داده" value={status.databaseName} mono />
                  <Field label="شِما" value={status.schema} mono />
                </InfoGrid>
              ) : (
                <Warn>اتصال برقرار نشد: {status.database.error}</Warn>
              )}
            </Card>

            <Card>
              <CardTitle>کلیدهای فروشنده (kms-license)</CardTitle>
              <InfoGrid>
                <Field label="پوشه کلیدها (SUBSCRIBERS_VENDOR_DIR)" value={status.licenseHome} mono />
                {status.keys.ready ? (
                  <>
                    <Field label="اثر انگشت کلید امضا" value={status.keys.fingerprint} mono />
                    <Field label="ساخت کلید" value={faDate(status.keys.created)} />
                    <Field label="کلید عمومی امضا" value={status.keys.signPublic} mono />
                  </>
                ) : (
                  <Field label="وضعیت" value={status.keys.error ?? "در دسترس نیست"} />
                )}
              </InfoGrid>
              {status.keys.ready && (
                <>
                  <Text as="p" type="tertiary" size="small">
                    دفتر لایسنس‌های قبلی (ledger.json همین پوشه) را می‌توانید یک‌بار وارد کنید؛
                    تکرار آن مورد تکراری نمی‌سازد.
                  </Text>
                  <Button neutral onClick={importLedger} disabled={busy}>
                    ورود دفتر kms-license
                  </Button>
                </>
              )}
            </Card>
          </>
        )}
      </Page>
    </Scene>
  );
}
