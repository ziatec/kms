// kms-licenses plugin v2.5.0
import * as React from "react";
import { useHistory } from "react-router-dom";
import { toast } from "sonner";
import { api, BASE_PATH, errorMessage, type CustomerSummary } from "../api";
import { daysLeft, faDate, faNum, health, healthLabel, type Health } from "../format";
import CustomerForm from "./CustomerForm";
import RequestIntake from "./RequestIntake";
import {
  Badge,
  Card,
  CardTitle,
  Input,
  LinkButton,
  Muted,
  Select,
  Stat,
  Stats,
  Table,
  TableWrap,
} from "./ui";

type Filter = "all" | Health | "pending" | "inactive";

export default function CustomerList({ creating, onCloseCreate }: { creating: boolean; onCloseCreate: () => void }) {
  const history = useHistory();
  const [list, setList] = React.useState<CustomerSummary[] | null>(null);
  const [query, setQuery] = React.useState("");
  const [filter, setFilter] = React.useState<Filter>("all");

  const load = React.useCallback(async () => {
    try {
      setList(await api.customers());
    } catch (err) {
      toast.error(errorMessage(err));
      setList([]);
    }
  }, []);

  React.useEffect(() => {
    void load();
  }, [load]);

  const open = (id: string) => history.push(`${BASE_PATH}/${id}`);

  if (!list) {
    return <Muted>در حال بارگذاری…</Muted>;
  }

  const h = (c: CustomerSummary) => health(c.lastExpiresAt, c.lastWarnDays);
  const count = (x: Health) => list.filter((c) => h(c) === x).length;
  const q = query.trim().toLowerCase();
  const rows = list.filter((c) => {
    if (filter === "pending" && !c.pendingCount) {
      return false;
    }
    if (filter === "inactive" && c.status !== "inactive") {
      return false;
    }
    if (!["all", "pending", "inactive"].includes(filter) && h(c) !== filter) {
      return false;
    }
    return (
      !q ||
      [c.name, c.organization, c.contactName, c.phone, c.mobile, c.email, c.city, c.lastSerial]
        .filter(Boolean)
        .some((v) => v!.toLowerCase().includes(q))
    );
  });

  return (
    <>
      <Stats>
        <Stat label="مشتریان" value={faNum(list.length)} />
        <Stat label="لایسنس فعال" value={faNum(count("active"))} />
        <Stat label="رو به انقضا" value={faNum(count("warning"))} />
        <Stat label="منقضی" value={faNum(count("expired"))} />
        <Stat
          label="درخواست در انتظار"
          value={faNum(list.reduce((n, c) => n + c.pendingCount, 0))}
        />
      </Stats>

      {creating && (
        <Card $accent>
          <CardTitle>مشتری جدید</CardTitle>
          <CustomerForm
            onSaved={(c) => {
              onCloseCreate();
              open(c.id);
            }}
            onCancel={onCloseCreate}
          />
        </Card>
      )}

      <RequestIntake customers={list} onAdded={open} />

      <Card>
        <CardTitle>
          جدول مشتریان
          <Input
            style={{ maxWidth: 280, marginInlineStart: "auto" }}
            placeholder="جستجو: نام، سازمان، تلفن، سریال…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Select
            style={{ maxWidth: 170 }}
            value={filter}
            onChange={(e) => setFilter(e.target.value as Filter)}
          >
            <option value="all">همه</option>
            <option value="active">لایسنس فعال</option>
            <option value="warning">رو به انقضا</option>
            <option value="expired">منقضی</option>
            <option value="none">بدون لایسنس</option>
            <option value="pending">درخواست در انتظار</option>
            <option value="inactive">مشتری غیرفعال</option>
          </Select>
        </CardTitle>
        {rows.length === 0 ? (
          <Muted>{list.length ? "موردی پیدا نشد." : "هنوز مشتری‌ای ثبت نشده است."}</Muted>
        ) : (
          <TableWrap>
            <Table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>مشتری</th>
                  <th>سازمان</th>
                  <th>تلفن</th>
                  <th>نصب‌ها</th>
                  <th>آخرین لایسنس</th>
                  <th>وضعیت</th>
                  <th>اعتبار تا</th>
                  <th>روز مانده</th>
                  <th>فعال‌سازی</th>
                  <th>در انتظار</th>
                  <th>آخرین درخواست</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((c, i) => {
                  const hc = h(c);
                  const d = daysLeft(c.lastExpiresAt);
                  return (
                    <tr key={c.id} className="clickable" onClick={() => open(c.id)}>
                      <td>{faNum(i + 1)}</td>
                      <td>
                        <LinkButton>{c.name}</LinkButton>
                        {c.status === "inactive" && <Muted> (غیرفعال)</Muted>}
                      </td>
                      <td>{c.organization ?? "—"}</td>
                      <td className={c.phone || c.mobile ? "mono" : undefined}>
                        {c.mobile || c.phone || "—"}
                      </td>
                      <td>{faNum(c.installCount)}</td>
                      <td className="mono">{c.lastSerial ?? "—"}</td>
                      <td>
                        <Badge $health={hc}>{healthLabel[hc]}</Badge>
                      </td>
                      <td>{faDate(c.lastExpiresAt)}</td>
                      <td>{d === null ? "—" : faNum(Math.max(d, 0))}</td>
                      <td>{faDate(c.lastActivatedAt)}</td>
                      <td>
                        {c.pendingCount ? (
                          <Badge $tone="accent">{faNum(c.pendingCount)}</Badge>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td>{faDate(c.lastRequestAt)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </TableWrap>
        )}
      </Card>
    </>
  );
}
