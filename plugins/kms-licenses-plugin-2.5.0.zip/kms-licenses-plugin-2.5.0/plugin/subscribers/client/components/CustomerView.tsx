// kms-licenses plugin v2.5.0
// One customer: profile, pending requests (issue/reject), licenses, requests, history.
// 2.5.0: the request's form (holder, representative, phone, days, note) and hardware
// identifiers are shown and prefill the issue form; activation files are KMS-<TOKEN>.zip.
import * as React from "react";
import { toast } from "sonner";
import Button from "~/components/Button";
import {
  api,
  errorMessage,
  type Customer,
  type CustomerEvent,
  type License,
  type LicenseRequest,
} from "../api";
import {
  daysLeft,
  downloadText,
  downloadZip,
  faDate,
  faDateTime,
  faNum,
  health,
  healthLabel,
  hwLines,
  jalaliInput,
  latinDigits,
  requestStatusLabel,
} from "../format";
import CustomerForm from "./CustomerForm";
import RequestIntake from "./RequestIntake";
import {
  Actions,
  Badge,
  Card,
  CardTitle,
  Field,
  FormGrid,
  Hint,
  InfoGrid,
  Input,
  Label,
  LinkButton,
  Muted,
  Stat,
  Stats,
  Table,
  TableWrap,
  TextArea,
  Timeline,
} from "./ui";

type Data = {
  customer: Customer;
  requests: LicenseRequest[];
  licenses: License[];
  events: CustomerEvent[];
};

export default function CustomerView({ id, onTitle }: { id: string; onTitle: (t: string) => void }) {
  const [data, setData] = React.useState<Data | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [editing, setEditing] = React.useState(false);

  const load = React.useCallback(async () => {
    try {
      const d = await api.customer(id);
      setData(d);
      onTitle(d.customer.name);
    } catch (err) {
      setError(errorMessage(err));
    }
  }, [id, onTitle]);

  React.useEffect(() => {
    setData(null);
    setError(null);
    void load();
  }, [load]);

  if (error) {
    return <Muted>{error}</Muted>;
  }
  if (!data) {
    return <Muted>در حال بارگذاری…</Muted>;
  }

  const { customer, requests, licenses, events } = data;
  const valid = licenses.filter((l) => !l.revokedAt);
  const current = valid.slice().sort((a, b) => b.expiresAt.localeCompare(a.expiresAt))[0];
  const pending = requests.filter((r) => r.status === "pending");
  const hc = health(current?.expiresAt, current?.warnDays, null);
  const installs = new Set(licenses.map((l) => l.installId)).size;

  return (
    <>
      <Stats>
        <Stat label="وضعیت لایسنس" value={healthLabel[hc]} />
        <Stat label="آخرین لایسنس" value={current?.serial ?? "—"} mono />
        <Stat label="اعتبار تا" value={faDate(current?.expiresAt)} />
        <Stat
          label="روز مانده"
          value={current ? faNum(Math.max(daysLeft(current.expiresAt) ?? 0, 0)) : "—"}
        />
        <Stat label="نصب‌ها" value={faNum(installs)} />
        <Stat label="درخواست در انتظار" value={faNum(pending.length)} />
      </Stats>

      <Card>
        <CardTitle>
          مشخصات مشتری
          {customer.status === "inactive" && <Badge $tone="textTertiary">غیرفعال</Badge>}
          {!editing && <LinkButton onClick={() => setEditing(true)}>ویرایش</LinkButton>}
        </CardTitle>
        {editing ? (
          <CustomerForm
            customer={customer}
            onSaved={() => {
              setEditing(false);
              void load();
            }}
            onCancel={() => setEditing(false)}
          />
        ) : (
          <InfoGrid>
            <Field label="نام" value={customer.name} />
            <Field label="سازمان" value={customer.organization} />
            <Field label="رابط" value={customer.contactName} />
            <Field label="تلفن" value={customer.phone} mono />
            <Field label="همراه" value={customer.mobile} mono />
            <Field label="ایمیل" value={customer.email} mono />
            <Field label="شهر" value={customer.city} />
            <Field label="نشانی" value={customer.address} />
            <Field label="توضیحات" value={customer.notes} />
            <Field
              label="ثبت"
              value={`${faDate(customer.createdAt)}${customer.createdByName ? ` · ${customer.createdByName}` : ""}`}
            />
          </InfoGrid>
        )}
      </Card>

      {pending.map((r) => (
        <IssuePanel key={r.id} request={r} customer={customer} onDone={load} />
      ))}

      <RequestIntake customerId={customer.id} onAdded={() => load()} />

      <LicensesCard licenses={licenses} requests={requests} onChange={load} />
      <RequestsCard requests={requests} licenses={licenses} />
      <HistoryCard customerId={customer.id} events={events} onChange={load} />
    </>
  );
}

// ---------------------------------------------------------------------------

const PRESETS = [
  { days: 90, label: "۳ ماه" },
  { days: 180, label: "۶ ماه" },
  { days: 365, label: "۱ سال" },
  { days: 730, label: "۲ سال" },
];

function IssuePanel({
  request,
  customer,
  onDone,
}: {
  request: LicenseRequest;
  customer: Customer;
  onDone: () => Promise<void>;
}) {
  const [customerName, setCustomerName] = React.useState(
    request.contact?.legalName || request.current?.customer || customer.name
  );
  const [days, setDays] = React.useState(
    request.requested?.days ? String(request.requested.days) : "365"
  );
  const [untilJalali, setUntilJalali] = React.useState("");
  const [warnDays, setWarnDays] = React.useState("30");
  const [note, setNote] = React.useState(request.requested?.note ?? "");
  const [busy, setBusy] = React.useState(false);

  const base = Math.max(
    Date.now(),
    request.current?.expiresAt ? Date.parse(request.current.expiresAt) : 0
  );
  // Days are kept in Latin digits; an out-of-range value shows "—" instead of
  // throwing (new Date(NaN).toISOString() crashed the page in 2.4.0).
  const end = days ? new Date(base + Number(days) * 86400000) : null;
  const preview = untilJalali
    ? untilJalali
    : end && Number.isFinite(end.getTime())
      ? faDate(end.toISOString())
      : "—";

  const issue = async () => {
    setBusy(true);
    try {
      const lic = await api.issue({
        requestId: request.id,
        customerName,
        days: untilJalali ? null : Number(days) || null,
        untilJalali: untilJalali || null,
        warnDays: Number(warnDays),
        note: note || null,
      });
      if (lic.licenseText) {
        const z = await api.licenseZip(lic.id);
        downloadZip(z.fileName, z.zip);
        toast.success(`لایسنس ${lic.serial} صادر شد: ${z.fileName} را برای مشتری بفرستید`);
      } else {
        toast.success(`لایسنس ${lic.serial} صادر شد`);
      }
      await onDone();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const reject = async () => {
    const reason = window.prompt("علت رد درخواست (اختیاری):", "");
    if (reason === null) {
      return;
    }
    setBusy(true);
    try {
      await api.rejectRequest(request.id, reason || null);
      await onDone();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card $accent>
      <CardTitle>
        پاسخ به درخواست — دریافت {faDateTime(request.receivedAt)}
        {request.current?.serial && <Badge $tone="accent">تمدید {request.current.serial}</Badge>}
      </CardTitle>
      <InfoGrid>
        <Field label="نام دارندهٔ مجوز" value={request.contact?.legalName} />
        <Field
          label="نماینده"
          value={[request.contact?.firstName, request.contact?.lastName].filter(Boolean).join(" ")}
        />
        <Field label="تلفن" value={request.contact?.phone} mono />
        <Field
          label="مدت درخواستی"
          value={request.requested?.days ? `${faNum(request.requested.days)} روز` : null}
        />
        <Field label="توضیح مشتری" value={request.requested?.note} />
        <Field label="زمان ایجاد درخواست" value={faDateTime(request.requestedAt)} />
        <Field label="سازمان (در درخواست)" value={request.organization} />
        <Field
          label="مدیر سامانه"
          value={[request.adminName, request.adminEmail].filter(Boolean).join(" · ")}
        />
        <Field label="شناسه نصب" value={request.installId} mono />
        <Field label="نسخه برنامه" value={request.appVersion} mono />
        <Field
          label={`شناسه‌های سخت‌افزار (${faNum(Object.keys(request.hw ?? {}).length)})`}
          value={hwLines(request.hw).join("\n")}
          mono
        />
        {request.current?.expiresAt && (
          <Field label="اعتبار فعلی تا" value={faDate(request.current.expiresAt)} />
        )}
      </InfoGrid>
      <FormGrid style={{ marginTop: 12 }}>
        <Label>
          نام مشتری روی لایسنس
          <Input value={customerName} onChange={(e) => setCustomerName(e.target.value)} />
        </Label>
        <Label>
          مدت (روز)
          <Input
            inputMode="numeric"
            dir="ltr"
            value={days}
            disabled={!!untilJalali}
            onChange={(e) => setDays(latinDigits(e.target.value).replace(/\D/g, "").slice(0, 4))}
          />
          <Hint>
            {PRESETS.map((p) => (
              <LinkButton
                key={p.days}
                style={{ marginInlineEnd: 8 }}
                onClick={() => {
                  setDays(String(p.days));
                  setUntilJalali("");
                }}
              >
                {p.label}
              </LinkButton>
            ))}
          </Hint>
        </Label>
        <Label>
          یا اعتبار تا تاریخ شمسی
          <Input
            dir="ltr"
            placeholder="1406/12/29"
            value={untilJalali}
            onChange={(e) => setUntilJalali(latinDigits(e.target.value))}
          />
          <Hint>پایان اعتبار: {preview}</Hint>
        </Label>
        <Label>
          روزهای هشدار پیش از پایان
          <Input
            inputMode="numeric"
            dir="ltr"
            value={warnDays}
            onChange={(e) => setWarnDays(latinDigits(e.target.value).replace(/\D/g, "").slice(0, 3))}
          />
        </Label>
      </FormGrid>
      <Label>
        یادداشت (داخل لایسنس هم ذخیره می‌شود)
        <Input value={note} onChange={(e) => setNote(e.target.value)} />
      </Label>
      <Actions>
        <Button onClick={issue} disabled={busy}>
          صدور و دریافت فایل فعال‌سازی (‎.zip‎)
        </Button>
        <Button danger onClick={reject} disabled={busy}>
          رد درخواست
        </Button>
      </Actions>
    </Card>
  );
}

function LicensesCard({
  licenses,
  requests,
  onChange,
}: {
  licenses: License[];
  requests: LicenseRequest[];
  onChange: () => Promise<void>;
}) {
  const [open, setOpen] = React.useState<string | null>(null);

  const download = async (l: License) => {
    try {
      const z = await api.licenseZip(l.id);
      downloadZip(z.fileName, z.zip);
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const setActivation = async (l: License) => {
    const value = window.prompt(
      "زمان فعال‌سازی (شمسی، مثل 1405/07/20 14:30) — خالی برای حذف:",
      jalaliInput(l.activatedAt ?? new Date())
    );
    if (value === null) {
      return;
    }
    try {
      await api.updateLicense({ id: l.id, activatedAt: value.trim() || null });
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const revoke = async (l: License) => {
    if (!window.confirm(`لایسنس ${l.serial} در سوابق باطل ثبت شود؟\n(روی سرور آفلاین مشتری اثری ندارد)`)) {
      return;
    }
    try {
      await api.updateLicense({ id: l.id, revoke: true });
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <Card>
      <CardTitle>لایسنس‌های صادرشده (پاسخ‌ها)</CardTitle>
      {!licenses.length ? (
        <Muted>هنوز لایسنسی صادر نشده است.</Muted>
      ) : (
        <TableWrap>
          <Table>
            <thead>
              <tr>
                <th>سریال</th>
                <th>وضعیت</th>
                <th>زمان درخواست</th>
                <th>زمان پاسخ</th>
                <th>اعتبار از</th>
                <th>اعتبار تا</th>
                <th>روز مانده</th>
                <th>زمان فعال‌سازی</th>
                <th>شناسه نصب</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              {licenses.map((l) => {
                const hl = health(l.expiresAt, l.warnDays, l.revokedAt);
                const req = requests.find((r) => r.id === l.requestId);
                const d = daysLeft(l.expiresAt);
                return (
                  <React.Fragment key={l.id}>
                    <tr className="clickable" onClick={() => setOpen(open === l.id ? null : l.id)}>
                      <td className="mono">{l.serial}</td>
                      <td>
                        <Badge $health={hl}>{healthLabel[hl]}</Badge>
                      </td>
                      <td>{faDateTime(req?.requestedAt)}</td>
                      <td>{faDateTime(l.issuedAt)}</td>
                      <td>{faDate(l.notBefore)}</td>
                      <td>{faDate(l.expiresAt)}</td>
                      <td>{d === null ? "—" : faNum(Math.max(d, 0))}</td>
                      <td>
                        {faDateTime(l.activatedAt)}
                        {l.activationSource === "request" && <Muted> (گزارش سرور)</Muted>}
                      </td>
                      <td className="mono">{l.installId.slice(0, 12)}…</td>
                      <td onClick={(e) => e.stopPropagation()}>
                        <Actions style={{ marginTop: 0, flexWrap: "nowrap" }}>
                          {l.licenseText && (
                            <LinkButton onClick={() => download(l)}>فایل zip</LinkButton>
                          )}
                          {!l.revokedAt && (
                            <>
                              <LinkButton onClick={() => setActivation(l)}>فعال‌سازی</LinkButton>
                              <LinkButton $danger onClick={() => revoke(l)}>
                                ابطال
                              </LinkButton>
                            </>
                          )}
                        </Actions>
                      </td>
                    </tr>
                    {open === l.id && (
                      <tr className="details">
                        <td colSpan={10}>
                          <InfoGrid>
                            <Field label="نام روی لایسنس" value={l.customerName} />
                            <Field label="شناسه نصب" value={l.installId} mono />
                            <Field label="سخت‌افزار" value={hwLines(l.hw).join("\n")} mono />
                            <Field label="هشدار پیش از پایان" value={`${faNum(l.warnDays)} روز`} />
                            <Field label="تمدیدِ" value={l.renewalOf} mono />
                            <Field label="صادرکننده" value={l.issuedByName ?? (l.source === "import" ? "ورود از kms-license" : null)} />
                            <Field label="ابطال" value={l.revokedAt ? faDateTime(l.revokedAt) : null} />
                            <Field label="یادداشت" value={l.note} />
                          </InfoGrid>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </Table>
        </TableWrap>
      )}
    </Card>
  );
}

function RequestsCard({ requests, licenses }: { requests: LicenseRequest[]; licenses: License[] }) {
  return (
    <Card>
      <CardTitle>درخواست‌های دریافت‌شده</CardTitle>
      {!requests.length ? (
        <Muted>هنوز درخواستی ثبت نشده است.</Muted>
      ) : (
        <TableWrap>
          <Table>
            <thead>
              <tr>
                <th>زمان درخواست</th>
                <th>زمان دریافت</th>
                <th>وضعیت</th>
                <th>زمان پاسخ</th>
                <th>لایسنس پاسخ</th>
                <th>نوع</th>
                <th>دارنده / نماینده</th>
                <th>مدت درخواستی</th>
                <th>سازمان / مدیر</th>
                <th>نسخه</th>
                <th>شناسه نصب</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {requests.map((r) => {
                const lic = licenses.find((l) => l.requestId === r.id);
                return (
                  <tr key={r.id}>
                    <td>{faDateTime(r.requestedAt)}</td>
                    <td>{faDateTime(r.receivedAt)}</td>
                    <td>
                      <Badge
                        $tone={r.status === "issued" ? "success" : r.status === "pending" ? "accent" : "textTertiary"}
                        title={r.rejectReason ?? undefined}
                      >
                        {requestStatusLabel[r.status]}
                      </Badge>
                    </td>
                    <td>{faDateTime(r.answeredAt ?? lic?.issuedAt)}</td>
                    <td className="mono">{lic?.serial ?? "—"}</td>
                    <td>{r.current?.serial ? `تمدید ${r.current.serial}` : "فعال‌سازی اول"}</td>
                    <td title={r.requested?.note || undefined}>
                      {[
                        r.contact?.legalName,
                        [r.contact?.firstName, r.contact?.lastName].filter(Boolean).join(" "),
                        r.contact?.phone,
                      ]
                        .filter(Boolean)
                        .join(" · ") || "—"}
                    </td>
                    <td>{r.requested?.days ? `${faNum(r.requested.days)} روز` : "—"}</td>
                    <td>{[r.organization, r.adminEmail].filter(Boolean).join(" · ") || "—"}</td>
                    <td className="mono">{r.appVersion ?? "—"}</td>
                    <td className="mono">{r.installId.slice(0, 12)}…</td>
                    <td>
                      <LinkButton
                        onClick={() =>
                          downloadText(`${lic?.serial ?? r.installId.slice(0, 8)}.kmsreq`, r.requestText)
                        }
                      >
                        فایل درخواست
                      </LinkButton>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </Table>
        </TableWrap>
      )}
    </Card>
  );
}

function HistoryCard({
  customerId,
  events,
  onChange,
}: {
  customerId: string;
  events: CustomerEvent[];
  onChange: () => Promise<void>;
}) {
  const [text, setText] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  const add = async () => {
    if (!text.trim()) {
      return;
    }
    setBusy(true);
    try {
      await api.addNote(customerId, text);
      setText("");
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardTitle>سابقه مشتری</CardTitle>
      <TextArea
        rows={2}
        placeholder="یادداشت جدید: تماس، قرارداد، پرداخت، پیگیری…"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <Actions style={{ marginBottom: 12 }}>
        <Button onClick={add} disabled={busy || !text.trim()}>
          افزودن به سابقه
        </Button>
      </Actions>
      {!events.length ? (
        <Muted>سابقه‌ای ثبت نشده است.</Muted>
      ) : (
        <Timeline>
          {events.map((e) => (
            <li key={e.id}>
              <div>
                <b>{e.title}</b>
              </div>
              {e.body && <div className="body">{e.body}</div>}
              <div className="meta">
                {faDateTime(e.createdAt)}
                {e.actorName ? ` · ${e.actorName}` : ""}
              </div>
            </li>
          ))}
        </Timeline>
      )}
    </Card>
  );
}
