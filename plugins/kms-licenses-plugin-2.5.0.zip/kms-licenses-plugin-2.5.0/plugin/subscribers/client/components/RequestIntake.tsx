// kms-licenses plugin v2.5.0
// Read the customer's request .zip, show what it contains (the License page form,
// the hardware identifiers), attach it to a customer.
// 2.5.0: only KMS-<TOKEN>.zip (the password comes from the file name); a new
// customer is created with the license holder, representative and phone of the form.
import * as React from "react";
import { toast } from "sonner";
import Button from "~/components/Button";
import { api, errorMessage, type CustomerSummary, type Inspection, type ZipFile } from "../api";
import { faDate, faDateTime, faNum, fileToBase64, hwLines } from "../format";
import { Actions, Card, CardTitle, Field, Hint, InfoGrid, Input, Label, Select, Warn } from "./ui";

type Props = {
  /** Fixed customer (customer page); otherwise the admin chooses one. */
  customerId?: string;
  customers?: CustomerSummary[];
  onAdded: (customerId: string) => void;
};

const NEW = "__new__";

export default function RequestIntake({ customerId, customers, onAdded }: Props) {
  const [file, setFile] = React.useState<ZipFile | null>(null);
  const [info, setInfo] = React.useState<Inspection | null>(null);
  const [target, setTarget] = React.useState<string>(customerId ?? "");
  const [newName, setNewName] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const fileRef = React.useRef<HTMLInputElement>(null);

  const reset = () => {
    setFile(null);
    setInfo(null);
  };

  const onFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const chosen = e.target.files?.[0];
    e.target.value = "";
    if (!chosen) {
      return;
    }
    if (!/\.zip$/i.test(chosen.name)) {
      toast.error("فقط فایل zip درخواست (‎KMS-….zip‎) پذیرفته می‌شود");
      return;
    }
    if (chosen.size > 140000) {
      toast.error("فایل بیش از حد بزرگ است");
      return;
    }
    setBusy(true);
    setInfo(null);
    try {
      const f = { zip: await fileToBase64(chosen), fileName: chosen.name };
      const i = await api.inspect(f);
      setFile(f);
      setInfo(i);
      if (!customerId) {
        setTarget(i.suggestedCustomerId ?? NEW);
        setNewName(i.suggestedName);
      }
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const add = async () => {
    if (!file || !info) {
      return;
    }
    if (info.duplicate) {
      const owner = info.duplicate.customerId;
      reset();
      onAdded(owner);
      return;
    }
    setBusy(true);
    try {
      let id = target;
      if (!id || id === NEW) {
        if (!newName.trim()) {
          toast.error("نام مشتری جدید را وارد کنید");
          return;
        }
        const rep = [info.contact.firstName, info.contact.lastName].filter(Boolean).join(" ");
        id = (
          await api.saveCustomer({
            name: newName.trim(),
            organization: info.organization || null,
            contactName: rep || null,
            phone: info.contact.phone || null,
          })
        ).id;
      }
      const res = await api.addRequest(id, file);
      toast[res.duplicate ? "info" : "success"](
        res.duplicate ? "این درخواست قبلاً ثبت شده است" : "درخواست ثبت شد"
      );
      reset();
      onAdded(res.request.customerId);
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  const rep = info ? [info.contact.firstName, info.contact.lastName].filter(Boolean).join(" ") : "";

  return (
    <Card>
      <CardTitle>ثبت فایل درخواست لایسنس (‎KMS-….zip‎)</CardTitle>
      {!info ? (
        <>
          <Hint>
            فایل zip که مشتری از صفحه «مجوز» گرفته است. نام فایل را تغییر ندهید: رمز zip از روی
            نام ساخته می‌شود.
          </Hint>
          <Actions>
            <Button onClick={() => fileRef.current?.click()} disabled={busy}>
              {busy ? "در حال خواندن…" : "انتخاب فایل zip درخواست…"}
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept=".zip,application/zip"
              hidden
              onChange={onFile}
            />
          </Actions>
        </>
      ) : (
        <>
          <InfoGrid>
            <Field label="نام دارندهٔ مجوز" value={info.contact.legalName} />
            <Field label="نماینده" value={rep} />
            <Field label="تلفن" value={info.contact.phone} mono />
            <Field
              label="مدت درخواستی"
              value={info.requested.days ? `${faNum(info.requested.days)} روز` : null}
            />
            <Field label="توضیح مشتری" value={info.requested.note} />
            <Field label="سازمان (در درخواست)" value={info.organization} />
            <Field
              label="مدیر سامانه"
              value={[info.admin.name, info.admin.email].filter(Boolean).join(" · ")}
            />
            <Field label="زمان ایجاد درخواست" value={faDateTime(info.createdAt)} />
            <Field label="نسخه برنامه" value={info.appVersion} mono />
            <Field label="شناسه نصب" value={info.installId} mono />
            <Field
              label={`شناسه‌های سخت‌افزار (${faNum(info.hardware.length)})`}
              value={hwLines(info.hw).join("\n")}
              mono
            />
            <Field
              label="لایسنس فعلی"
              value={
                info.current?.serial
                  ? `${info.current.serial} · ${info.current.customer ?? ""} · تا ${faDate(info.current.expiresAt)}`
                  : "ندارد (فعال‌سازی اول)"
              }
            />
            <Field label="سرور" value={info.knownServer ? "شناخته‌شده" : "سرور جدید"} />
          </InfoGrid>
          {info.duplicate && <Warn>این درخواست قبلاً ثبت شده است.</Warn>}
          {!customerId && (
            <InfoGrid style={{ marginTop: 12 }}>
              <Label>
                مشتری
                <Select value={target} onChange={(e) => setTarget(e.target.value)}>
                  <option value={NEW}>— مشتری جدید —</option>
                  {(customers ?? []).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                      {c.organization ? ` (${c.organization})` : ""}
                    </option>
                  ))}
                </Select>
              </Label>
              {target === NEW && (
                <Label>
                  نام مشتری جدید
                  <Input value={newName} onChange={(e) => setNewName(e.target.value)} />
                </Label>
              )}
            </InfoGrid>
          )}
          <Hint>
            نماینده و تلفن در مشخصات مشتری (اگر خالی باشد) ثبت می‌شود؛ مدت و توضیح در فرم صدور
            پیش‌فرض می‌شود.
          </Hint>
          <Actions>
            <Button onClick={add} disabled={busy}>
              {info.duplicate ? "رفتن به درخواست ثبت‌شده" : "ثبت درخواست"}
            </Button>
            <Button neutral onClick={reset} disabled={busy}>
              انصراف
            </Button>
          </Actions>
        </>
      )}
    </Card>
  );
}
