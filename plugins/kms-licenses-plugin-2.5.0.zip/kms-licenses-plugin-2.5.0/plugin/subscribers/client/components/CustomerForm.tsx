// kms-licenses plugin v2.5.0
import * as React from "react";
import { toast } from "sonner";
import Button from "~/components/Button";
import { api, errorMessage, type Customer } from "../api";
import { Actions, FormGrid, Input, Label, Select, TextArea } from "./ui";

type Props = {
  customer?: Customer | null;
  initialName?: string;
  onSaved: (c: Customer) => void;
  onCancel?: () => void;
};

const empty = {
  name: "",
  organization: "",
  contactName: "",
  phone: "",
  mobile: "",
  email: "",
  city: "",
  address: "",
  notes: "",
  status: "active" as Customer["status"],
};

export default function CustomerForm({ customer, initialName, onSaved, onCancel }: Props) {
  const [form, setForm] = React.useState(() =>
    customer
      ? {
          name: customer.name,
          organization: customer.organization ?? "",
          contactName: customer.contactName ?? "",
          phone: customer.phone ?? "",
          mobile: customer.mobile ?? "",
          email: customer.email ?? "",
          city: customer.city ?? "",
          address: customer.address ?? "",
          notes: customer.notes ?? "",
          status: customer.status,
        }
      : { ...empty, name: initialName ?? "" }
  );
  const [saving, setSaving] = React.useState(false);

  const set =
    (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const save = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!form.name.trim()) {
      toast.error("نام مشتری الزامی است");
      return;
    }
    setSaving(true);
    try {
      const saved = await api.saveCustomer({ ...(customer ? { id: customer.id } : {}), ...form });
      toast.success("مشخصات مشتری ذخیره شد");
      onSaved(saved);
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={save}>
      <FormGrid>
        <Label>
          نام مشتری *
          <Input value={form.name} onChange={set("name")} autoFocus />
        </Label>
        <Label>
          سازمان
          <Input value={form.organization} onChange={set("organization")} />
        </Label>
        <Label>
          نام رابط
          <Input value={form.contactName} onChange={set("contactName")} />
        </Label>
        <Label>
          تلفن
          <Input dir="ltr" value={form.phone} onChange={set("phone")} />
        </Label>
        <Label>
          همراه
          <Input dir="ltr" value={form.mobile} onChange={set("mobile")} />
        </Label>
        <Label>
          ایمیل
          <Input dir="ltr" type="email" value={form.email} onChange={set("email")} />
        </Label>
        <Label>
          شهر
          <Input value={form.city} onChange={set("city")} />
        </Label>
        <Label>
          وضعیت
          <Select value={form.status} onChange={set("status")}>
            <option value="active">فعال</option>
            <option value="inactive">غیرفعال</option>
          </Select>
        </Label>
      </FormGrid>
      <FormGrid>
        <Label>
          نشانی
          <TextArea rows={2} value={form.address} onChange={set("address")} />
        </Label>
        <Label>
          توضیحات
          <TextArea rows={2} value={form.notes} onChange={set("notes")} />
        </Label>
      </FormGrid>
      <Actions>
        <Button type="submit" disabled={saving}>
          {saving ? "در حال ذخیره…" : "ذخیره"}
        </Button>
        {onCancel && (
          <Button neutral onClick={onCancel}>
            انصراف
          </Button>
        )}
      </Actions>
    </form>
  );
}
