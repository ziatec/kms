// kms-licenses plugin v2.5.0
// Full page app at /subscribers, /subscribers/:customerId and /subscribers/settings
// (opened from Settings > License > «مدیریت مجوزها»).
import { observer } from "mobx-react";
import { PlusIcon } from "outline-icons";
import * as React from "react";
import { Link, useParams } from "react-router-dom";
import { Action } from "~/components/Actions";
import Button from "~/components/Button";
import Scene from "~/components/Scene";
import useCurrentUser from "~/hooks/useCurrentUser";
import { settingsPath } from "~/utils/routeHelpers";
import SubscribersSettings from "./Settings";
import { api, BASE_PATH, PLUGIN_VERSION, type Status } from "./api";
import CustomerList from "./components/CustomerList";
import CustomerView from "./components/CustomerView";
import { Muted, Page, Warn } from "./components/ui";
import { faNum } from "./format";
import Icon from "./Icon";

function SubscribersApp() {
  const user = useCurrentUser();
  const { customerId } = useParams<{ customerId?: string }>();
  const [creating, setCreating] = React.useState(false);
  const [customerTitle, setCustomerTitle] = React.useState("");
  const [license, setLicense] = React.useState<Status["license"] | null>(null);

  React.useEffect(() => {
    api
      .status()
      .then((st) => setLicense(st.license))
      .catch(() => setLicense(null));
  }, []);

  if (customerId === "settings") {
    return <SubscribersSettings />;
  }

  if (!user.isAdmin) {
    return (
      <Scene title="مدیریت مجوزها" icon={<Icon />}>
        <Page>
          <Muted>این بخش فقط برای مدیران سامانه است.</Muted>
        </Page>
      </Scene>
    );
  }

  return (
    <Scene
      wide
      icon={<Icon />}
      textTitle={customerId ? customerTitle || "مشتری" : "مدیریت مجوزها"}
      title={
        customerId ? (
          <>
            <Link to={BASE_PATH}>مدیریت مجوزها</Link>&nbsp;/&nbsp;{customerTitle || "…"}
          </>
        ) : (
          "مدیریت مجوزها"
        )
      }
      actions={
        <>
          {!customerId && (
            <Action>
              <Button icon={<PlusIcon />} onClick={() => setCreating(true)}>
                مشتری جدید
              </Button>
            </Action>
          )}
          <Action>
            <Button neutral as={Link} to={`${BASE_PATH}/settings`}>
              تنظیمات
            </Button>
          </Action>
          <Action>
            <Button neutral as={Link} to={settingsPath("license")}>
              مجوز این سرور
            </Button>
          </Action>
        </>
      }
    >
      <Page dir="rtl" data-subscribers-version={PLUGIN_VERSION}>
        {license?.readOnly && (
          <Warn>
            اوت‌لاین این سرور فعال‌سازی نشده یا لایسنس آن تمام شده و فقط‌خواندنی است؛
            مدیریت مجوزها مستقل است و کار می‌کند. فایل درخواست همین سرور را از
            «تنظیمات ← مجوز» بگیرید، این‌جا لایسنس صادر کنید و در همان‌جا وارد کنید.
          </Warn>
        )}
        {customerId ? (
          <CustomerView key={customerId} id={customerId} onTitle={setCustomerTitle} />
        ) : (
          <CustomerList creating={creating} onCloseCreate={() => setCreating(false)} />
        )}
        <Muted style={{ fontSize: 12 }}>افزونه مدیریت مجوزها · نسخه {faNum(PLUGIN_VERSION)}</Muted>
      </Page>
    </Scene>
  );
}

export default observer(SubscribersApp);
