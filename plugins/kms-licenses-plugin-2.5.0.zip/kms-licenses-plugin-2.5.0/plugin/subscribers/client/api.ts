// kms-licenses plugin v2.5.0
import { observable, runInAction } from "mobx";
import { client } from "~/utils/ApiClient";

export const PLUGIN_VERSION = "2.5.0";
export const BASE_PATH = "/subscribers";

export type Status = {
  version: string;
  product: string;
  schema: string;
  separateDatabase: boolean;
  licenseHome: string;
  keys:
    | { ready: true; fingerprint: string; created: string | null; signPublic: string }
    | { ready: false; error?: string };
  databaseName: string;
  /** This server's own KMS license (patch 0008-license), information only. */
  license: {
    available: boolean;
    status: string;
    readOnly: boolean;
    serial: string | null;
    customer: string | null;
    expiresAt: string | null;
    daysLeft: number | null;
  };
  database: {
    ok: boolean;
    error?: string;
    counts?: { customers: number; licenses: number; pending: number };
  };
};

export type Customer = {
  id: string;
  name: string;
  organization: string | null;
  contactName: string | null;
  phone: string | null;
  mobile: string | null;
  email: string | null;
  city: string | null;
  address: string | null;
  notes: string | null;
  status: "active" | "inactive";
  createdByName: string | null;
  createdAt: string;
  updatedAt: string;
};

export type CustomerSummary = Customer & {
  installCount: number;
  licenseCount: number;
  pendingCount: number;
  lastSerial: string | null;
  lastExpiresAt: string | null;
  lastWarnDays: number | null;
  lastActivatedAt: string | null;
  lastRequestAt: string | null;
};

export type CurrentLicense = {
  serial?: string;
  customer?: string;
  expiresAt?: string;
  activatedAt?: string;
} | null;

/** Patch 0022: the form on the customer's License page. */
export type RequestContact = {
  legalName?: string;
  firstName?: string;
  lastName?: string;
  phone?: string;
} | null;
export type Requested = { days?: number | null; note?: string } | null;

/** A request file chosen by the admin: the .zip as base64 and its name. */
export type ZipFile = { zip: string; fileName: string };

export type LicenseRequest = {
  id: string;
  customerId: string;
  status: "pending" | "issued" | "rejected";
  installId: string;
  serverKey: string;
  hardware: string[];
  organization: string | null;
  adminName: string | null;
  adminEmail: string | null;
  appVersion: string | null;
  current: CurrentLicense;
  hw: Record<string, string>;
  contact: RequestContact;
  requested: Requested;
  requestedAt: string;
  receivedAt: string;
  receivedByName: string | null;
  answeredAt: string | null;
  rejectReason: string | null;
  requestText: string;
};

export type License = {
  id: string;
  customerId: string;
  requestId: string | null;
  serial: string;
  customerName: string;
  installId: string;
  hardware: string[];
  hw: Record<string, string>;
  issuedAt: string;
  notBefore: string;
  expiresAt: string;
  warnDays: number;
  note: string | null;
  renewalOf: string | null;
  licenseText: string | null;
  activatedAt: string | null;
  activationSource: "manual" | "request" | "import" | null;
  revokedAt: string | null;
  issuedByName: string | null;
  source: "plugin" | "import";
};

export type CustomerEvent = {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  refId: string | null;
  actorName: string | null;
  createdAt: string;
};

export type Inspection = {
  organization: string;
  admin: { name: string; email: string };
  createdAt: string;
  installId: string;
  serverKey: string;
  hardware: string[];
  hw: Record<string, string>;
  contact: { legalName: string; firstName: string; lastName: string; phone: string };
  requested: { days: number | null; note: string };
  current: CurrentLicense;
  appVersion: string;
  knownServer: boolean;
  suggestedCustomerId: string | null;
  suggestedName: string;
  duplicate: { id: string; customerId: string; status: string } | null;
};

const post = async <R>(method: string, body: Record<string, unknown> = {}) =>
  (await client.post<{ data: R }>(`/subscribers.${method}`, body as never)).data;

/**
 * Whether the plugin is enabled on the server (the API exists only then).
 * null = not checked yet.
 */
export const availability = observable.box<boolean | null>(null);
let checking: Promise<void> | null = null;

export function checkAvailability() {
  if (!checking) {
    checking = post<Status>("status")
      .then(() => runInAction(() => availability.set(true)))
      .catch(() => runInAction(() => availability.set(false)));
  }
  return checking;
}

export const api = {
  status: () => post<Status>("status"),
  customers: () => post<CustomerSummary[]>("customers.list"),
  customer: (id: string) =>
    post<{
      customer: Customer;
      requests: LicenseRequest[];
      licenses: License[];
      events: CustomerEvent[];
    }>("customers.info", { id }),
  saveCustomer: (c: Partial<Customer> & { name: string }) =>
    post<Customer>("customers.save", c),
  addNote: (id: string, text: string) =>
    post<CustomerEvent>("customers.note", { id, text }),
  inspect: (file: ZipFile) => post<Inspection>("requests.inspect", file),
  addRequest: (customerId: string, file: ZipFile) =>
    post<{ request: LicenseRequest; duplicate: boolean }>("requests.add", {
      customerId,
      ...file,
    }),
  licenseZip: (id: string) =>
    post<{ serial: string; fileName: string; password: string; zip: string }>("licenses.zip", { id }),
  rejectRequest: (id: string, reason: string | null) =>
    post<LicenseRequest>("requests.reject", { id, reason }),
  issue: (b: {
    requestId: string;
    customerName?: string | null;
    days?: number | null;
    untilJalali?: string | null;
    warnDays?: number | null;
    note?: string | null;
  }) => post<License>("licenses.issue", b),
  updateLicense: (b: { id: string; activatedAt?: string | null; revoke?: boolean }) =>
    post<License>("licenses.update", b),
  importLedger: () => post<{ imported: number; skipped: number }>("import"),
};

export const errorMessage = (err: unknown) =>
  err instanceof Error ? err.message : "خطای ناشناخته";
