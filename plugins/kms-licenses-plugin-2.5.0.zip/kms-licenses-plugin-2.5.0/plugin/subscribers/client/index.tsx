// kms-licenses plugin v2.5.0
// 2.4.0: one entry point, a row in Settings > License (Hook.PageLink, patch
// 0010-plugin-hooks v2.1) instead of a sidebar link plus a settings item; the
// plugin's own settings are at /subscribers/settings. On an Outline without
// Hook.PageLink the sidebar link and settings item of 2.3.0 are used.
import { createLazyComponent } from "~/components/LazyLoad";
import { Hook, PluginManager } from "~/utils/PluginManager";
import config from "../plugin.json";
import { availability, BASE_PATH, checkAvailability } from "./api";
import Icon from "./Icon";

/** Admins only, and only where the server side of the plugin is enabled. */
const enabled = (_team: unknown, user: { isAdmin: boolean }) => {
  if (!user.isAdmin) {
    return false;
  }
  const available = availability.get();
  if (available === null) {
    void checkAvailability();
  }
  return available === true;
};

const LABEL = "مدیریت مجوزها";
const DESCRIPTION = "مشتریان، درخواست‌ها و صدور لایسنس KMS.";
const App = createLazyComponent(() => import("./App"));
const pageLink = (Hook as unknown as Record<string, string>).PageLink;

const plugins: unknown[] = [
  {
    ...config,
    type: Hook.Route,
    value: { path: `${BASE_PATH}/:customerId?`, component: App, enabled },
  },
];
if (pageLink) {
  plugins.push({
    ...config,
    name: LABEL,
    type: pageLink,
    value: {
      page: "license",
      label: LABEL,
      description: DESCRIPTION,
      icon: Icon,
      path: BASE_PATH,
      enabled,
    },
  });
} else {
  plugins.push(
    {
      ...config,
      name: LABEL,
      type: Hook.Settings,
      value: {
        group: "Workspace",
        icon: Icon,
        description: DESCRIPTION,
        component: createLazyComponent(() => import("./Settings")),
        enabled,
      },
    },
    {
      ...config,
      type: Hook.SidebarLink,
      value: { label: LABEL, icon: Icon, path: BASE_PATH, enabled },
    }
  );
}

PluginManager.add(plugins as Parameters<typeof PluginManager.add>[0]);
