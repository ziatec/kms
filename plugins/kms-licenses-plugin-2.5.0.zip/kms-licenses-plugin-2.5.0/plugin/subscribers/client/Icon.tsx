// kms-licenses plugin v2.5.0
type Props = { size?: number; color?: string };

export default function SubscribersIcon({ size = 24, color = "currentColor" }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M14.5 4a5 5 0 0 0-4.8 6.4L4 16.1V20h3.9v-2h2v-2h2l1.2-1.2A5 5 0 1 0 14.5 4Zm1.5 5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z"
        fill={color}
      />
    </svg>
  );
}
