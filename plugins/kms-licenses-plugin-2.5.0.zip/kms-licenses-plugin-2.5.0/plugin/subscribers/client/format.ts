// kms-licenses plugin v2.5.0
// Jalali display helpers (Intl persian calendar, Tehran time).
const TZ = "Asia/Tehran";

const dateFmt = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  timeZone: TZ,
});
const dateTimeFmt = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  timeZone: TZ,
});
const numParts = new Intl.DateTimeFormat("en-US-u-ca-persian", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  hourCycle: "h23",
  timeZone: TZ,
});

const valid = (v?: string | null) => !!v && Number.isFinite(new Date(v).getTime());
export const faDate = (v?: string | null) => (valid(v) ? dateFmt.format(new Date(v!)) : "—");
export const faDateTime = (v?: string | null) =>
  valid(v) ? dateTimeFmt.format(new Date(v!)) : "—";

/** Persian (۰-۹) and Arabic-Indic (٠-٩) digits to 0-9, for numeric and date inputs. */
export const latinDigits = (s: string) =>
  s
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));
export const faNum = (n: number | string) =>
  String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);

/** "1405/07/20 14:30" in Latin digits, for editable Jalali inputs. */
export function jalaliInput(v: Date | string, withTime = true) {
  const parts = numParts.formatToParts(new Date(v));
  const get = (t: string) => parts.find((p) => p.type === t)?.value.replace(/\D/g, "") ?? "";
  const date = `${get("year")}/${get("month")}/${get("day")}`;
  return withTime ? `${date} ${get("hour")}:${get("minute")}` : date;
}

const DAY = 86400000;

export function daysLeft(until?: string | null) {
  return until ? Math.ceil((new Date(until).getTime() - Date.now()) / DAY) : null;
}

export type Health = "none" | "active" | "warning" | "expired" | "revoked";

export function health(
  expiresAt?: string | null,
  warnDays?: number | null,
  revokedAt?: string | null
): Health {
  if (revokedAt) {
    return "revoked";
  }
  const d = daysLeft(expiresAt);
  if (d === null) {
    return "none";
  }
  if (d <= 0) {
    return "expired";
  }
  return d <= (warnDays ?? 30) ? "warning" : "active";
}

export const healthLabel: Record<Health, string> = {
  none: "بدون لایسنس",
  active: "فعال",
  warning: "رو به انقضا",
  expired: "منقضی",
  revoked: "باطل‌شده",
};

export const requestStatusLabel = {
  pending: "در انتظار پاسخ",
  issued: "پاسخ داده شد",
  rejected: "ردشده",
} as const;

export function downloadText(filename: string, text: string) {
  const url = URL.createObjectURL(new Blob([text], { type: "text/plain" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** v2.5.0: saves a base64 .zip sent by the server. */
export function downloadZip(filename: string, base64: string) {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  const url = URL.createObjectURL(new Blob([bytes], { type: "application/zip" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** v2.5.0: a chosen file as base64. */
export async function fileToBase64(file: File) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

/** v2.5.0: "machine: 1a2b3c…" lines of the hardware identifiers. */
export const hwLines = (hw: Record<string, string> | null | undefined) =>
  Object.entries(hw ?? {}).map(([k, v]) => `${k}: ${String(v)}`);
