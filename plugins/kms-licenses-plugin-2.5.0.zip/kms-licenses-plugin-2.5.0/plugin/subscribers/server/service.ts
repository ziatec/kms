// kms-licenses plugin v2.5.0
// License operations; mirrors `inspect`, `issue` and the ledger of kms-license.mjs 1.3.
// 2.5.0: requests are read only from the customer's KMS-<TOKEN>.zip (AES-256, password
// derived from the file name); the form fields (license holder, representative, phone,
// requested days, note) and the hardware identifiers are read from the request, stored
// and filled into the customer; the activation code goes out as KMS-<TOKEN>.zip.
import fs from "node:fs";
import path from "node:path";
import { db } from "./db/database";
import * as store from "./db/store";
import {
  LICENSE_TYPE,
  LicenseFormatError,
  openRequest,
  PRODUCT,
  requestHash,
  sealLicense,
  type LicenseRequest,
} from "./license/format";
import { faDigits, parseJalali } from "./license/jalali";
import { licenseHome, loadVendorKeys } from "./license/keys";
import { newZipName, passwordFor, readZip, writeEncryptedZip, zipPassword } from "./license/zip";

const DAY = 24 * 60 * 60 * 1000;

export class UserError extends Error {}


function vendorKeys() {
  const { keys, error } = loadVendorKeys();
  if (!keys) {
    throw new UserError(error ?? "کلیدهای فروشنده در دسترس نیست");
  }
  return keys;
}

/**
 * The armored request inside the customer's zip. Only a .zip is accepted:
 * KMS-<TOKEN>.zip (password from the name) or the unencrypted zip of servers
 * with patch 0022 only.
 */
export function requestFromZip(zipBase64: string, fileName: string) {
  if (!/\.zip$/i.test(fileName)) {
    throw new UserError("فقط فایل zip درخواست پذیرفته می‌شود");
  }
  let text: string;
  try {
    text = readZip(Buffer.from(zipBase64, "base64"), passwordFor(fileName)).data.toString("utf8");
  } catch (err) {
    const msg = (err as Error).message;
    throw new UserError(
      /KMS-X/.test(msg)
        ? "نام فایل تغییر کرده است: بخش KMS-… نام باید بماند (رمز zip از آن ساخته می‌شود)"
        : /wrong zip password/.test(msg)
          ? "رمز zip با نام فایل جور نیست: نام فایل را تغییر ندهید"
          : `فایل zip باز نمی‌شود: ${msg}`
    );
  }
  if (!text.includes("-----BEGIN KMS LICENSE REQUEST-----")) {
    throw new UserError("در این zip درخواست لایسنس KMS نیست");
  }
  return text;
}

/** The activation code as a password-protected KMS-<TOKEN>.zip. */
export function licenseZip(licenseText: string) {
  const { token, fileName } = newZipName();
  const password = zipPassword(token);
  const zip = writeEncryptedZip("activation.kmslic", licenseText, password);
  return { fileName, password, zip: zip.toString("base64") };
}

const contactName = (req: LicenseRequest) =>
  [req.contact?.firstName, req.contact?.lastName].filter(Boolean).join(" ").trim() || null;

function open(text: string): LicenseRequest {
  try {
    return openRequest(text, vendorKeys().boxPrivate);
  } catch (err) {
    throw err instanceof LicenseFormatError ? new UserError(err.message) : err;
  }
}

const describe = (req: LicenseRequest) => ({
  organization: req.organization || "",
  admin: { name: req.admin?.name || "", email: req.admin?.email || "" },
  createdAt: req.createdAt,
  installId: req.installId,
  serverKey: req.serverKey,
  hardware: Object.keys(req.hw || {}),
  hw: req.hw || {},
  contact: {
    legalName: req.contact?.legalName || "",
    firstName: req.contact?.firstName || "",
    lastName: req.contact?.lastName || "",
    phone: req.contact?.phone || "",
  },
  requested: {
    days: Number.isFinite(req.requested?.days) ? Number(req.requested!.days) : null,
    note: req.requested?.note || "",
  },
  current: req.current || null,
  appVersion: req.appVersion || "",
});

/** Reads a request without storing it, and suggests the customer it belongs to. */
export async function inspect(teamId: string, text: string) {
  const req = open(text);
  const hash = requestHash(text);
  const existing = await store.findRequestByHash(teamId, hash);
  const owner = await store.customerForInstall(teamId, req.installId);
  let suggested = owner?.customerId ?? null;
  if (!suggested && req.contact?.legalName) {
    suggested = (await store.findCustomerByName(teamId, req.contact.legalName))?.id ?? null;
  }
  if (!suggested && req.current?.customer) {
    suggested = (await store.findCustomerByName(teamId, req.current.customer))?.id ?? null;
  }
  if (!suggested && req.organization) {
    suggested = (await store.findCustomerByName(teamId, req.organization))?.id ?? null;
  }
  return {
    ...describe(req),
    knownServer: !!owner,
    suggestedCustomerId: suggested,
    suggestedName: req.contact?.legalName || req.current?.customer || req.organization || "",
    duplicate: existing ? { id: existing.id, customerId: existing.customerId, status: existing.status } : null,
  };
}

/** Stores a request for a customer (deduplicated by content). */
export async function addRequest(teamId: string, actor: store.Actor, customerId: string, text: string) {
  const req = open(text);
  const hash = requestHash(text);
  return db.transaction(async (t) => {
    const customer = await store.getCustomer(teamId, customerId, t);
    if (!customer) {
      throw new UserError("مشتری پیدا نشد");
    }
    const existing = await store.findRequestByHash(teamId, hash, t);
    if (existing) {
      return { request: existing, duplicate: true };
    }
    // A renewal request reports the activation of the current license.
    if (req.current?.serial && req.current.activatedAt) {
      const lic = await store.licenseBySerial(teamId, req.current.serial, t);
      if (lic && !lic.activatedAt) {
        await store.setActivation(lic.id, req.current.activatedAt, "request", t);
      }
    }
    const request = (await store.insertRequest(
      teamId,
      actor,
      {
        customerId,
        requestText: text.trim() + "\n",
        requestHash: hash,
        installId: req.installId,
        serverKey: req.serverKey,
        serverBoxKey: req.serverBoxKey,
        hw: req.hw || {},
        organization: req.organization || null,
        adminName: req.admin?.name || null,
        adminEmail: req.admin?.email || null,
        appVersion: req.appVersion || null,
        current: req.current || null,
        contact: req.contact || null,
        requested: req.requested || null,
        requestedAt: req.createdAt,
      },
      "pending",
      null,
      t
    ))!;
    await store.addEvent(
      teamId,
      customerId,
      actor,
      {
        kind: "request",
        title: req.current?.serial ? `درخواست تمدید ${req.current.serial}` : "درخواست فعال‌سازی",
        body: [
          req.contact?.legalName && `دارنده: ${req.contact.legalName}`,
          contactName(req) && `نماینده: ${contactName(req)}`,
          req.contact?.phone && `تلفن: ${req.contact.phone}`,
          req.requested?.days && `مدت درخواستی: ${req.requested.days} روز`,
          req.requested?.note && `توضیح: ${req.requested.note}`,
          req.organization,
          req.admin?.email,
          req.appVersion && `نسخه ${req.appVersion}`,
        ]
          .filter(Boolean)
          .join(" · "),
        refId: request.id,
      },
      t
    );
    // The form fills the customer's empty contact fields.
    const filled = await store.fillCustomerContact(
      teamId,
      customerId,
      { contactName: contactName(req), phone: req.contact?.phone, organization: req.organization },
      t
    );
    if (filled.length) {
      await store.addEvent(
        teamId,
        customerId,
        actor,
        { kind: "update", title: "تکمیل مشخصات از فرم درخواست", body: filled.join("، ") },
        t
      );
    }
    return { request, duplicate: false };
  });
}

export type IssueOptions = {
  requestId: string;
  customerName?: string | null;
  days?: number | null;
  untilJalali?: string | null;
  warnDays?: number | null;
  note?: string | null;
};

export async function issue(teamId: string, actor: store.Actor, o: IssueOptions) {
  const keys = vendorKeys();
  return db.transaction(async (t) => {
    const request = await store.getRequest(teamId, o.requestId, t);
    if (!request) {
      throw new UserError("درخواست پیدا نشد");
    }
    if (request.status !== "pending") {
      throw new UserError("به این درخواست قبلاً پاسخ داده شده است");
    }
    const customer = (await store.getCustomer(teamId, request.customerId, t))!;
    // Re-open the stored request: it is the source of truth for the binding.
    const req = open(request.requestText);
    const now = new Date();
    const customerName = (
      o.customerName ||
      req.contact?.legalName ||
      req.current?.customer ||
      customer.name ||
      ""
    ).trim();
    if (!customerName) {
      throw new UserError("نام مشتری روی لایسنس لازم است");
    }

    let expires: Date;
    if (o.untilJalali) {
      try {
        expires = parseJalali(o.untilJalali);
      } catch (err) {
        throw new UserError((err as Error).message);
      }
    } else if (o.days) {
      const days = Number(faDigits(String(o.days)));
      if (!Number.isFinite(days) || days < 1 || days > 3660) {
        throw new UserError("مدت باید بین ۱ تا ۳۶۶۰ روز باشد");
      }
      // A renewal continues from the current expiry when that is later than now.
      const current = req.current?.expiresAt ? Date.parse(req.current.expiresAt) : 0;
      expires = new Date(Math.max(now.getTime(), current || 0) + days * DAY);
    } else {
      throw new UserError("مدت (روز) یا تاریخ پایان شمسی را وارد کنید");
    }
    if (expires.getTime() <= now.getTime()) {
      throw new UserError("تاریخ پایان گذشته است");
    }
    const warnDays = o.warnDays ?? 30;
    if (!Number.isInteger(warnDays) || warnDays < 0 || warnDays > 365) {
      throw new UserError("روزهای هشدار باید بین ۰ تا ۳۶۵ باشد");
    }

    const serial = await store.nextSerial(teamId, t);
    const payload = {
      type: LICENSE_TYPE as typeof LICENSE_TYPE,
      v: 1 as const,
      product: PRODUCT,
      serial,
      customer: customerName,
      installId: req.installId,
      serverKey: req.serverKey,
      hw: req.hw,
      issuedAt: now.toISOString(),
      notBefore: new Date(now.getTime() - 5 * 60 * 1000).toISOString(),
      expiresAt: expires.toISOString(),
      warnDays,
      ...(o.note ? { note: String(o.note) } : {}),
    };
    const licenseText = sealLicense(payload, keys.signPrivate, req.serverBoxKey);
    const license = (await store.insertLicense(
      teamId,
      actor,
      {
        customerId: customer.id,
        requestId: request.id,
        serial,
        customerName,
        installId: req.installId,
        serverKey: req.serverKey,
        hw: req.hw,
        issuedAt: payload.issuedAt,
        notBefore: payload.notBefore,
        expiresAt: payload.expiresAt,
        warnDays,
        note: o.note || null,
        renewalOf: req.current?.serial || null,
        licenseText,
        activatedAt: null,
        activationSource: null,
        source: "plugin",
      },
      t
    ))!;
    await store.answerRequest(request.id, "issued", null, t);
    await store.addEvent(
      teamId,
      customer.id,
      actor,
      { kind: "license", title: `صدور لایسنس ${serial}`, body: o.note || null, refId: license.id },
      t
    );
    return license;
  });
}

export async function rejectRequest(teamId: string, actor: store.Actor, id: string, reason: string | null) {
  return db.transaction(async (t) => {
    const request = await store.getRequest(teamId, id, t);
    if (!request) {
      throw new UserError("درخواست پیدا نشد");
    }
    if (request.status !== "pending") {
      throw new UserError("فقط درخواست در انتظار قابل رد است");
    }
    const row = await store.answerRequest(id, "rejected", reason, t);
    await store.addEvent(
      teamId,
      request.customerId,
      actor,
      { kind: "reject", title: "رد درخواست", body: reason, refId: id },
      t
    );
    return row!;
  });
}

export async function updateLicense(
  teamId: string,
  actor: store.Actor,
  id: string,
  change: { activatedAt?: string | null; revoke?: boolean }
) {
  return db.transaction(async (t) => {
    let license = await store.getLicense(teamId, id, t);
    if (!license) {
      throw new UserError("لایسنس پیدا نشد");
    }
    if (change.activatedAt !== undefined) {
      let iso: string | null = null;
      if (change.activatedAt) {
        try {
          iso = /^\d{4}-\d{2}-\d{2}T/.test(change.activatedAt)
            ? new Date(change.activatedAt).toISOString()
            : parseJalali(change.activatedAt, false).toISOString();
        } catch (err) {
          throw new UserError((err as Error).message);
        }
      }
      license = (await store.setActivation(id, iso, "manual", t))!;
      await store.addEvent(
        teamId,
        license.customerId,
        actor,
        {
          kind: "activation",
          title: iso ? `ثبت فعال‌سازی ${license.serial}` : `حذف زمان فعال‌سازی ${license.serial}`,
          refId: id,
        },
        t
      );
    }
    if (change.revoke) {
      license = (await store.revokeLicense(id, t)) ?? license;
      await store.addEvent(
        teamId,
        license.customerId,
        actor,
        { kind: "revoke", title: `ابطال لایسنس ${license.serial} (در سوابق)`, refId: id },
        t
      );
    }
    return license;
  });
}

type LedgerRecord = {
  serial: string;
  customer: string;
  organization?: string;
  adminEmail?: string;
  installId: string;
  serverKey: string;
  serverBoxKey?: string;
  hw?: Record<string, string>;
  issuedAt: string;
  notBefore: string;
  expiresAt: string;
  warnDays?: number;
  note?: string;
  renewalOf?: string;
  licenseFile?: string;
  requestFile?: string;
};

const readIfInside = (home: string, rel?: string) => {
  if (!rel) {
    return null;
  }
  const file = path.resolve(home, rel);
  if (!file.startsWith(home + path.sep)) {
    return null;
  }
  try {
    return fs.readFileSync(file, "utf8");
  } catch {
    return null;
  }
};

/** Imports ledger.json of kms-license.mjs from SUBSCRIBERS_VENDOR_DIR (idempotent). */
export async function importLedger(teamId: string, actor: store.Actor) {
  const home = licenseHome();
  let ledger: { licenses?: LedgerRecord[] };
  try {
    ledger = JSON.parse(fs.readFileSync(path.join(home, "ledger.json"), "utf8"));
  } catch {
    throw new UserError(`ledger.json در ${home} پیدا نشد`);
  }
  const keys = loadVendorKeys().keys;
  let imported = 0;
  let skipped = 0;
  for (const rec of ledger.licenses ?? []) {
    await db.transaction(async (t) => {
      if (await store.licenseBySerial(teamId, rec.serial, t)) {
        skipped++;
        return;
      }
      const name = rec.customer || rec.organization || rec.installId;
      const customer =
        (await store.customerForInstall(teamId, rec.installId, t).then((o) =>
          o ? store.getCustomer(teamId, o.customerId, t) : null
        )) ??
        (await store.findCustomerByName(teamId, name, t)) ??
        (await store.createCustomer(teamId, actor, { name, organization: rec.organization || null }, t));

      const requestText = readIfInside(home, rec.requestFile);
      let requestId: string | null = null;
      if (requestText) {
        const hash = requestHash(requestText);
        const existing = await store.findRequestByHash(teamId, hash, t);
        let req: LicenseRequest | null = null;
        try {
          req = keys ? openRequest(requestText, keys.boxPrivate) : null;
        } catch {
          req = null;
        }
        requestId =
          existing?.id ??
          (await store.insertRequest(
            teamId,
            actor,
            {
              customerId: customer.id,
              requestText,
              requestHash: hash,
              installId: rec.installId,
              serverKey: rec.serverKey,
              serverBoxKey: rec.serverBoxKey || req?.serverBoxKey || "",
              hw: rec.hw || req?.hw || {},
              organization: rec.organization || req?.organization || null,
              adminName: req?.admin?.name || null,
              adminEmail: rec.adminEmail || req?.admin?.email || null,
              appVersion: req?.appVersion || null,
              current: req?.current || null,
              contact: req?.contact || null,
              requested: req?.requested || null,
              requestedAt: req?.createdAt || rec.issuedAt,
            },
            "issued",
            rec.issuedAt,
            t
          ))!.id;
      }
      const license = (await store.insertLicense(
        teamId,
        null,
        {
          customerId: customer.id,
          requestId,
          serial: rec.serial,
          customerName: rec.customer,
          installId: rec.installId,
          serverKey: rec.serverKey,
          hw: rec.hw || {},
          issuedAt: rec.issuedAt,
          notBefore: rec.notBefore,
          expiresAt: rec.expiresAt,
          warnDays: rec.warnDays ?? 30,
          note: rec.note || null,
          renewalOf: rec.renewalOf || null,
          licenseText: readIfInside(home, rec.licenseFile),
          activatedAt: null,
          activationSource: null,
          source: "import",
        },
        t
      ))!;
      await store.addEvent(
        teamId,
        customer.id,
        actor,
        { kind: "import", title: `ورود لایسنس ${rec.serial} از دفتر kms-license`, refId: license.id },
        t
      );
      imported++;
    });
  }
  return { imported, skipped };
}
