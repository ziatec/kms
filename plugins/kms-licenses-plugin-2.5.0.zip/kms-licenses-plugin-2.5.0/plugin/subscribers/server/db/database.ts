// kms-licenses plugin v2.5.0
// The plugin's own database. It never touches Outline's database: it uses a
// separate database (SUBSCRIBERS_DB_NAME, default "kms_subscribers") on the same
// PostgreSQL server and credentials as Outline, created by install-plugin.sh.
// SUBSCRIBERS_DATABASE_URL points it anywhere else instead.
import { QueryTypes, Sequelize, type Transaction } from "sequelize";
import env from "@server/env";
import Logger from "@server/logging/Logger";
import { migrations } from "./migrations";

export const SCHEMA = (() => {
  const name = process.env.SUBSCRIBERS_DB_SCHEMA || "kms_subscribers";
  if (!/^[a-z_][a-z0-9_]{0,62}$/.test(name)) {
    throw new Error(`invalid SUBSCRIBERS_DB_SCHEMA: ${name}`);
  }
  return name;
})();

export const DB_NAME = (() => {
  const name = process.env.SUBSCRIBERS_DB_NAME || "kms_subscribers";
  if (!/^[a-z_][a-z0-9_]{0,62}$/.test(name)) {
    throw new Error(`invalid SUBSCRIBERS_DB_NAME: ${name}`);
  }
  return name;
})();

/** Schema-qualified table name. */
export const T = (table: string) => `"${SCHEMA}"."${table}"`;

function connection(): Sequelize {
  const ssl =
    env.isProduction && env.PGSSLMODE !== "disable"
      ? { rejectUnauthorized: false }
      : false;
  const options = {
    dialect: "postgres" as const,
    logging: false as const,
    pool: { max: 3, min: 0, idle: 10000, acquire: 30000 },
    dialectOptions: { ssl, application_name: "outline:subscribers" },
  };
  if (process.env.SUBSCRIBERS_DATABASE_URL) {
    return new Sequelize(process.env.SUBSCRIBERS_DATABASE_URL, options);
  }
  if (env.DATABASE_URL) {
    // Outline's server and credentials, the plugin's own database.
    const url = new URL(env.DATABASE_URL);
    url.pathname = `/${DB_NAME}`;
    return new Sequelize(url.toString(), options);
  }
  return new Sequelize({
    ...options,
    database: DB_NAME,
    username: env.DATABASE_USER,
    password: env.DATABASE_PASSWORD || undefined,
    host: env.DATABASE_HOST,
    port: env.DATABASE_PORT || 5432,
  });
}

export const db = connection();

let ready: Promise<void> | null = null;

/** Creates the schema and applies pending plugin migrations, once per process. */
export function ensureReady() {
  if (!ready) {
    ready = migrate().catch((err) => {
      ready = null;
      throw err;
    });
  }
  return ready;
}

async function migrate() {
  await db.transaction(async (transaction) => {
    // Serialize concurrent workers.
    await db.query(`SELECT pg_advisory_xact_lock(hashtext(:k))`, {
      replacements: { k: `${SCHEMA}:migrate` },
      transaction,
    });
    await db.query(
      `CREATE SCHEMA IF NOT EXISTS "${SCHEMA}";
       CREATE TABLE IF NOT EXISTS ${T("schema_version")} (
         version integer PRIMARY KEY,
         "appliedAt" timestamptz NOT NULL DEFAULT now()
       );`,
      { transaction }
    );
    const [row] = await db.query<{ v: number | null }>(
      `SELECT max(version) AS v FROM ${T("schema_version")}`,
      { type: QueryTypes.SELECT, transaction }
    );
    const current = row?.v ?? 0;
    for (const m of migrations.filter((x) => x.version > current)) {
      Logger.info("plugins", `subscribers: migrating schema to v${m.version}`);
      await db.query(m.sql(T), { transaction });
      await db.query(`INSERT INTO ${T("schema_version")} (version) VALUES (:v)`, {
        replacements: { v: m.version },
        transaction,
      });
    }
  });
}

type Repl = Record<string, unknown>;

export async function rows<R>(sql: string, replacements: Repl = {}, transaction?: Transaction) {
  return (await db.query(sql, {
    replacements,
    transaction,
    type: QueryTypes.SELECT,
  })) as R[];
}

export async function one<R>(sql: string, replacements: Repl = {}, transaction?: Transaction) {
  return (await rows<R>(sql, replacements, transaction))[0] ?? null;
}
