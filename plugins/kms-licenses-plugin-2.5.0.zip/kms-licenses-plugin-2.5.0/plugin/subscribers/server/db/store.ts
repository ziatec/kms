// kms-licenses plugin v2.5.0
import { randomUUID } from "node:crypto";
import type { Transaction } from "sequelize";
import { one, rows, T } from "./database";

export type Actor = { id: string; name: string };

export type CustomerRow = {
  id: string;
  teamId: string;
  name: string;
  organization: string | null;
  contactName: string | null;
  phone: string | null;
  mobile: string | null;
  email: string | null;
  city: string | null;
  address: string | null;
  notes: string | null;
  status: "active" | "inactive";
  createdByName: string | null;
  createdAt: Date;
  updatedAt: Date;
};

export type RequestRow = {
  id: string;
  customerId: string;
  status: "pending" | "issued" | "rejected";
  requestText: string;
  requestHash: string;
  installId: string;
  serverKey: string;
  serverBoxKey: string;
  hw: Record<string, string>;
  organization: string | null;
  adminName: string | null;
  adminEmail: string | null;
  appVersion: string | null;
  current: { serial?: string; customer?: string; expiresAt?: string; activatedAt?: string } | null;
  /** v2.5.0: the License page form (legal name, representative, phone). */
  contact: { legalName?: string; firstName?: string; lastName?: string; phone?: string } | null;
  /** v2.5.0: the duration (days) and note asked for. */
  requested: { days?: number; note?: string } | null;
  requestedAt: Date;
  receivedAt: Date;
  receivedByName: string | null;
  answeredAt: Date | null;
  rejectReason: string | null;
};

export type LicenseRow = {
  id: string;
  customerId: string;
  requestId: string | null;
  serial: string;
  customerName: string;
  installId: string;
  serverKey: string;
  hw: Record<string, string>;
  issuedAt: Date;
  notBefore: Date;
  expiresAt: Date;
  warnDays: number;
  note: string | null;
  renewalOf: string | null;
  licenseText: string | null;
  activatedAt: Date | null;
  activationSource: "manual" | "request" | "import" | null;
  revokedAt: Date | null;
  issuedByName: string | null;
  source: "plugin" | "import";
};

export type EventRow = {
  id: string;
  kind: string;
  title: string;
  body: string | null;
  refId: string | null;
  actorName: string | null;
  createdAt: Date;
};

// --- customers -------------------------------------------------------------

export type CustomerInput = {
  name: string;
  organization?: string | null;
  contactName?: string | null;
  phone?: string | null;
  mobile?: string | null;
  email?: string | null;
  city?: string | null;
  address?: string | null;
  notes?: string | null;
  status?: "active" | "inactive";
};

const CUSTOMER_FIELDS = [
  "name",
  "organization",
  "contactName",
  "phone",
  "mobile",
  "email",
  "city",
  "address",
  "notes",
  "status",
] as const;

export type CustomerSummary = CustomerRow & {
  installCount: number;
  licenseCount: number;
  pendingCount: number;
  lastSerial: string | null;
  lastExpiresAt: Date | null;
  lastWarnDays: number | null;
  lastActivatedAt: Date | null;
  lastRequestAt: Date | null;
};

export const listCustomers = (teamId: string) =>
  rows<CustomerSummary>(
    `SELECT c.*,
       (SELECT count(DISTINCT "installId")::int FROM ${T("licenses")} l WHERE l."customerId" = c.id) AS "installCount",
       (SELECT count(*)::int FROM ${T("licenses")} l WHERE l."customerId" = c.id) AS "licenseCount",
       (SELECT count(*)::int FROM ${T("requests")} r WHERE r."customerId" = c.id AND r.status = 'pending') AS "pendingCount",
       (SELECT max(r."receivedAt") FROM ${T("requests")} r WHERE r."customerId" = c.id) AS "lastRequestAt",
       last.serial AS "lastSerial", last."expiresAt" AS "lastExpiresAt",
       last."warnDays" AS "lastWarnDays", last."activatedAt" AS "lastActivatedAt"
     FROM ${T("customers")} c
     LEFT JOIN LATERAL (
       SELECT serial, "expiresAt", "warnDays", "activatedAt" FROM ${T("licenses")} l
        WHERE l."customerId" = c.id AND l."revokedAt" IS NULL
        ORDER BY l."expiresAt" DESC LIMIT 1
     ) last ON true
     WHERE c."teamId" = :teamId
     ORDER BY c.name`,
    { teamId }
  );

export const getCustomer = (teamId: string, id: string, t?: Transaction) =>
  one<CustomerRow>(
    `SELECT * FROM ${T("customers")} WHERE "teamId" = :teamId AND id = :id`,
    { teamId, id },
    t
  );

export const findCustomerByName = (teamId: string, name: string, t?: Transaction) =>
  one<CustomerRow>(
    `SELECT * FROM ${T("customers")} WHERE "teamId" = :teamId AND lower(name) = lower(:name)
     ORDER BY "createdAt" LIMIT 1`,
    { teamId, name },
    t
  );

export async function createCustomer(teamId: string, actor: Actor, input: CustomerInput, t?: Transaction) {
  const values: Record<string, unknown> = { id: randomUUID(), teamId, actorId: actor.id, actorName: actor.name };
  for (const f of CUSTOMER_FIELDS) {
    values[f] = input[f] ?? null;
  }
  values.status = input.status ?? "active";
  return (await one<CustomerRow>(
    `INSERT INTO ${T("customers")}
       (id, "teamId", ${CUSTOMER_FIELDS.map((f) => `"${f}"`).join(", ")}, "createdById", "createdByName")
     VALUES (:id, :teamId, ${CUSTOMER_FIELDS.map((f) => `:${f}`).join(", ")}, :actorId, :actorName)
     RETURNING *`,
    values,
    t
  ))!;
}

export async function updateCustomer(teamId: string, id: string, input: CustomerInput, t?: Transaction) {
  const values: Record<string, unknown> = { teamId, id };
  for (const f of CUSTOMER_FIELDS) {
    values[f] = input[f] ?? null;
  }
  values.status = input.status ?? "active";
  return one<CustomerRow>(
    `UPDATE ${T("customers")} SET
       ${CUSTOMER_FIELDS.map((f) => `"${f}" = :${f}`).join(", ")}, "updatedAt" = now()
     WHERE "teamId" = :teamId AND id = :id RETURNING *`,
    values,
    t
  );
}

/**
 * v2.5.0: fills the customer's empty contact fields from a request's form
 * (fields the vendor already filled in are kept). Returns the names of the
 * fields that changed.
 */
export async function fillCustomerContact(
  teamId: string,
  id: string,
  input: { contactName?: string | null; phone?: string | null; organization?: string | null },
  t?: Transaction
) {
  const before = await one<CustomerRow>(
    `SELECT * FROM ${T("customers")} WHERE "teamId" = :teamId AND id = :id`,
    { teamId, id },
    t
  );
  if (!before) {
    return [];
  }
  const changed = (["contactName", "phone", "organization"] as const).filter(
    (f) => !(before[f] ?? "").trim() && (input[f] ?? "").trim()
  );
  if (!changed.length) {
    return [];
  }
  const values: Record<string, unknown> = { teamId, id };
  for (const f of changed) {
    values[f] = input[f]!.trim();
  }
  await one<CustomerRow>(
    `UPDATE ${T("customers")} SET ${changed.map((f) => `"${f}" = :${f}`).join(", ")}, "updatedAt" = now()
     WHERE "teamId" = :teamId AND id = :id RETURNING *`,
    values,
    t
  );
  return changed;
}

/** The customer that already owns this installation, if any. */
export const customerForInstall = (teamId: string, installId: string, t?: Transaction) =>
  one<{ customerId: string }>(
    `SELECT "customerId" FROM (
       SELECT "customerId", "issuedAt" AS at FROM ${T("licenses")} WHERE "teamId" = :teamId AND "installId" = :installId
       UNION ALL
       SELECT "customerId", "receivedAt" AS at FROM ${T("requests")} WHERE "teamId" = :teamId AND "installId" = :installId
     ) x ORDER BY at DESC LIMIT 1`,
    { teamId, installId },
    t
  );

// --- events ----------------------------------------------------------------

export const addEvent = (
  teamId: string,
  customerId: string,
  actor: Actor | null,
  e: { kind: string; title: string; body?: string | null; refId?: string | null },
  t?: Transaction
) =>
  one<EventRow>(
    `INSERT INTO ${T("events")} (id, "teamId", "customerId", kind, title, body, "refId", "actorId", "actorName")
     VALUES (:id, :teamId, :customerId, :kind, :title, :body, :refId, :actorId, :actorName) RETURNING *`,
    {
      id: randomUUID(),
      teamId,
      customerId,
      kind: e.kind,
      title: e.title.slice(0, 255),
      body: e.body ?? null,
      refId: e.refId ?? null,
      actorId: actor?.id ?? null,
      actorName: actor?.name ?? null,
    },
    t
  );

export const listEvents = (customerId: string) =>
  rows<EventRow>(
    `SELECT * FROM ${T("events")} WHERE "customerId" = :customerId ORDER BY "createdAt" DESC LIMIT 500`,
    { customerId }
  );

// --- requests --------------------------------------------------------------

export const listRequests = (customerId: string) =>
  rows<RequestRow>(
    `SELECT * FROM ${T("requests")} WHERE "customerId" = :customerId ORDER BY "receivedAt" DESC`,
    { customerId }
  );

export const getRequest = (teamId: string, id: string, t?: Transaction) =>
  one<RequestRow>(
    `SELECT * FROM ${T("requests")} WHERE "teamId" = :teamId AND id = :id FOR UPDATE`,
    { teamId, id },
    t
  );

export const findRequestByHash = (teamId: string, hash: string, t?: Transaction) =>
  one<RequestRow>(
    `SELECT * FROM ${T("requests")} WHERE "teamId" = :teamId AND "requestHash" = :hash`,
    { teamId, hash },
    t
  );

export type RequestInsert = Omit<
  RequestRow,
  "id" | "status" | "receivedAt" | "receivedByName" | "answeredAt" | "rejectReason" | "requestedAt"
> & { requestedAt: string };

export const insertRequest = (
  teamId: string,
  actor: Actor,
  r: RequestInsert,
  status: RequestRow["status"] = "pending",
  receivedAt: string | null = null,
  t?: Transaction
) =>
  one<RequestRow>(
    `INSERT INTO ${T("requests")}
      (id, "teamId", "customerId", status, "requestText", "requestHash", "installId", "serverKey",
       "serverBoxKey", hw, organization, "adminName", "adminEmail", "appVersion", "current",
       contact, requested, "requestedAt", "receivedAt", "receivedById", "receivedByName")
     VALUES
      (:id, :teamId, :customerId, :status, :requestText, :requestHash, :installId, :serverKey,
       :serverBoxKey, CAST(:hw AS jsonb), :organization, :adminName, :adminEmail, :appVersion,
       CAST(:current AS jsonb), CAST(:contact AS jsonb), CAST(:requested AS jsonb),
       :requestedAt, COALESCE(CAST(:receivedAt AS timestamptz), now()),
       :actorId, :actorName)
     RETURNING *`,
    {
      ...r,
      id: randomUUID(),
      teamId,
      status,
      receivedAt,
      hw: JSON.stringify(r.hw ?? {}),
      current: r.current ? JSON.stringify(r.current) : null,
      contact: r.contact ? JSON.stringify(r.contact) : null,
      requested: r.requested ? JSON.stringify(r.requested) : null,
      actorId: actor.id,
      actorName: actor.name,
    },
    t
  );

export const answerRequest = (
  id: string,
  status: "issued" | "rejected",
  reason: string | null,
  t?: Transaction
) =>
  one<RequestRow>(
    `UPDATE ${T("requests")} SET status = :status, "answeredAt" = now(), "rejectReason" = :reason
     WHERE id = :id RETURNING *`,
    { id, status, reason },
    t
  );

// --- licenses --------------------------------------------------------------

export const listLicenses = (customerId: string) =>
  rows<LicenseRow>(
    `SELECT * FROM ${T("licenses")} WHERE "customerId" = :customerId ORDER BY "issuedAt" DESC`,
    { customerId }
  );

export const getLicense = (teamId: string, id: string, t?: Transaction) =>
  one<LicenseRow>(
    `SELECT * FROM ${T("licenses")} WHERE "teamId" = :teamId AND id = :id FOR UPDATE`,
    { teamId, id },
    t
  );

export const licenseBySerial = (teamId: string, serial: string, t?: Transaction) =>
  one<LicenseRow>(
    `SELECT * FROM ${T("licenses")} WHERE "teamId" = :teamId AND serial = :serial`,
    { teamId, serial },
    t
  );

/** Next serial in the vendor tool's style: KMS-<year>-<count+1, 4 digits>. */
export async function nextSerial(teamId: string, t?: Transaction) {
  // Serialize serial allocation per team.
  await rows(`SELECT pg_advisory_xact_lock(hashtext(:k))`, { k: `subscribers:serial:${teamId}` }, t);
  const row = await one<{ n: number }>(
    `SELECT count(*)::int AS n FROM ${T("licenses")} WHERE "teamId" = :teamId`,
    { teamId },
    t
  );
  const year = new Date().getFullYear();
  for (let n = (row?.n ?? 0) + 1; ; n++) {
    const serial = `KMS-${year}-${String(n).padStart(4, "0")}`;
    if (!(await licenseBySerial(teamId, serial, t))) {
      return serial;
    }
  }
}

export type LicenseInsert = Omit<
  LicenseRow,
  "id" | "issuedAt" | "notBefore" | "expiresAt" | "activatedAt" | "revokedAt" | "issuedByName"
> & {
  issuedAt: string;
  notBefore: string;
  expiresAt: string;
  activatedAt: string | null;
};

export const insertLicense = (teamId: string, actor: Actor | null, l: LicenseInsert, t?: Transaction) =>
  one<LicenseRow>(
    `INSERT INTO ${T("licenses")}
      (id, "teamId", "customerId", "requestId", serial, "customerName", "installId", "serverKey", hw,
       "issuedAt", "notBefore", "expiresAt", "warnDays", note, "renewalOf", "licenseText",
       "activatedAt", "activationSource", "issuedById", "issuedByName", source)
     VALUES
      (:id, :teamId, :customerId, :requestId, :serial, :customerName, :installId, :serverKey,
       CAST(:hw AS jsonb), :issuedAt, :notBefore, :expiresAt, :warnDays, :note, :renewalOf,
       :licenseText, :activatedAt, :activationSource, :actorId, :actorName, :source)
     RETURNING *`,
    {
      ...l,
      id: randomUUID(),
      teamId,
      hw: JSON.stringify(l.hw ?? {}),
      actorId: actor?.id ?? null,
      actorName: actor?.name ?? null,
    },
    t
  );

export const setActivation = (
  id: string,
  activatedAt: string | null,
  source: LicenseRow["activationSource"],
  t?: Transaction
) =>
  one<LicenseRow>(
    `UPDATE ${T("licenses")} SET "activatedAt" = :activatedAt,
       "activationSource" = CASE WHEN CAST(:activatedAt AS timestamptz) IS NULL THEN NULL ELSE :source END
     WHERE id = :id RETURNING *`,
    { id, activatedAt, source },
    t
  );

export const revokeLicense = (id: string, t?: Transaction) =>
  one<LicenseRow>(
    `UPDATE ${T("licenses")} SET "revokedAt" = now() WHERE id = :id AND "revokedAt" IS NULL RETURNING *`,
    { id },
    t
  );

export const counts = (teamId: string) =>
  one<{ customers: number; licenses: number; pending: number }>(
    `SELECT
       (SELECT count(*)::int FROM ${T("customers")} WHERE "teamId" = :teamId) AS customers,
       (SELECT count(*)::int FROM ${T("licenses")} WHERE "teamId" = :teamId) AS licenses,
       (SELECT count(*)::int FROM ${T("requests")} WHERE "teamId" = :teamId AND status = 'pending') AS pending`,
    { teamId }
  );
