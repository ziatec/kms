// kms-licenses plugin v2.5.0
// Schema of the plugin's own database. Append new versions; never edit old ones.
// Users are stored by id and name only (no foreign keys into Outline).

export const migrations: { version: number; sql: (T: (t: string) => string) => string }[] = [
  {
    version: 1,
    sql: (T) => `
      CREATE TABLE ${T("customers")} (
        id uuid PRIMARY KEY,
        "teamId" uuid NOT NULL,
        name varchar(255) NOT NULL,
        organization varchar(255),
        "contactName" varchar(255),
        phone varchar(64),
        mobile varchar(64),
        email varchar(255),
        city varchar(128),
        address text,
        notes text,
        status varchar(16) NOT NULL DEFAULT 'active',
        "createdById" uuid,
        "createdByName" varchar(255),
        "createdAt" timestamptz NOT NULL DEFAULT now(),
        "updatedAt" timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX customers_team ON ${T("customers")} ("teamId", name);

      CREATE TABLE ${T("requests")} (
        id uuid PRIMARY KEY,
        "teamId" uuid NOT NULL,
        "customerId" uuid NOT NULL REFERENCES ${T("customers")}(id) ON DELETE CASCADE,
        status varchar(16) NOT NULL DEFAULT 'pending',
        "requestText" text NOT NULL,
        "requestHash" varchar(64) NOT NULL,
        "installId" varchar(128) NOT NULL,
        "serverKey" varchar(128) NOT NULL,
        "serverBoxKey" varchar(64) NOT NULL,
        hw jsonb NOT NULL DEFAULT '{}',
        organization varchar(255),
        "adminName" varchar(255),
        "adminEmail" varchar(255),
        "appVersion" varchar(64),
        "current" jsonb,
        "requestedAt" timestamptz NOT NULL,
        "receivedAt" timestamptz NOT NULL DEFAULT now(),
        "receivedById" uuid,
        "receivedByName" varchar(255),
        "answeredAt" timestamptz,
        "rejectReason" text,
        UNIQUE ("teamId", "requestHash")
      );
      CREATE INDEX requests_customer ON ${T("requests")} ("customerId");
      CREATE INDEX requests_install ON ${T("requests")} ("teamId", "installId");

      CREATE TABLE ${T("licenses")} (
        id uuid PRIMARY KEY,
        "teamId" uuid NOT NULL,
        "customerId" uuid NOT NULL REFERENCES ${T("customers")}(id) ON DELETE CASCADE,
        "requestId" uuid REFERENCES ${T("requests")}(id) ON DELETE SET NULL,
        serial varchar(64) NOT NULL,
        "customerName" varchar(255) NOT NULL,
        "installId" varchar(128) NOT NULL,
        "serverKey" varchar(128) NOT NULL,
        hw jsonb NOT NULL DEFAULT '{}',
        "issuedAt" timestamptz NOT NULL,
        "notBefore" timestamptz NOT NULL,
        "expiresAt" timestamptz NOT NULL,
        "warnDays" integer NOT NULL DEFAULT 30,
        note text,
        "renewalOf" varchar(64),
        "licenseText" text,
        "activatedAt" timestamptz,
        "activationSource" varchar(16),
        "revokedAt" timestamptz,
        "issuedById" uuid,
        "issuedByName" varchar(255),
        source varchar(16) NOT NULL DEFAULT 'plugin',
        UNIQUE ("teamId", serial)
      );
      CREATE INDEX licenses_customer ON ${T("licenses")} ("customerId");
      CREATE INDEX licenses_install ON ${T("licenses")} ("teamId", "installId");

      CREATE TABLE ${T("events")} (
        id uuid PRIMARY KEY,
        "teamId" uuid NOT NULL,
        "customerId" uuid NOT NULL REFERENCES ${T("customers")}(id) ON DELETE CASCADE,
        kind varchar(24) NOT NULL,
        title varchar(255) NOT NULL,
        body text,
        "refId" uuid,
        "actorId" uuid,
        "actorName" varchar(255),
        "createdAt" timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX events_customer ON ${T("events")} ("customerId", "createdAt");
    `,
  },
  {
    // v2.5.0: the License page form of the customer (patch 0022)
    version: 2,
    sql: (T) => `
      ALTER TABLE ${T("requests")} ADD COLUMN IF NOT EXISTS contact jsonb;
      ALTER TABLE ${T("requests")} ADD COLUMN IF NOT EXISTS requested jsonb;
    `,
  },
];
