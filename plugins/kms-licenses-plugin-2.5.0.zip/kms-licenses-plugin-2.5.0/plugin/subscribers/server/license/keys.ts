// kms-licenses plugin v2.5.0
// Vendor keys are the ones created by `kms-license.mjs keygen`. install-plugin.sh
// copies them to <kms>/config/license/vendor/, which the existing read-only
// mount shows inside the container as /etc/kms-license/vendor (the default).
import fs from "node:fs";
import path from "node:path";
import { createPrivateKey, createPublicKey, type KeyObject } from "node:crypto";
import { keyFingerprint, PRODUCT } from "./format";

export type VendorKeys = {
  signPrivate: KeyObject;
  signPublic: KeyObject;
  boxPrivate: KeyObject;
  fingerprint: string;
  created: string | null;
};

export const licenseHome = () =>
  path.resolve(process.env.SUBSCRIBERS_VENDOR_DIR || "/etc/kms-license/vendor");

let cache: { mtime: number; keys: VendorKeys } | null = null;

/** Loads the vendor keys, or returns an error message. */
export function loadVendorKeys(): { keys?: VendorKeys; error?: string } {
  const file = path.join(licenseHome(), "private.json");
  try {
    const mtime = fs.statSync(file).mtimeMs;
    if (cache && cache.mtime === mtime) {
      return { keys: cache.keys };
    }
    const priv = JSON.parse(fs.readFileSync(file, "utf8"));
    if (priv.product && priv.product !== PRODUCT) {
      return { error: `private.json برای محصول ${priv.product} است` };
    }
    const signPrivate = createPrivateKey({ key: priv.sign, format: "jwk" });
    const keys: VendorKeys = {
      signPrivate,
      signPublic: createPublicKey(signPrivate),
      boxPrivate: createPrivateKey({ key: priv.box, format: "jwk" }),
      fingerprint: "",
      created: priv.created ?? null,
    };
    keys.fingerprint = keyFingerprint(keys.signPublic).slice(0, 16);
    cache = { mtime, keys };
    return { keys };
  } catch (err) {
    return {
      error:
        (err as NodeJS.ErrnoException).code === "ENOENT"
          ? `فایل کلید پیدا نشد: ${file}`
          : `خواندن ${file} ممکن نشد: ${(err as Error).message}`,
    };
  }
}
