// kms-licenses plugin v2.5.0
// Byte-compatible port of the formats in kms-license.mjs 1.1 (vendor tool) and
// server/license/format.ts of patch 0008-license (customer side):
//   request  "-----BEGIN KMS LICENSE REQUEST-----" sealed to the vendor box key,
//            signed by the customer server's Ed25519 key
//   license  "-----BEGIN KMS ACTIVATION-----" signed with the vendor Ed25519 key,
//            sealed to the customer server's X25519 box key
import {
  createCipheriv,
  createDecipheriv,
  createHash,
  createPublicKey,
  diffieHellman,
  generateKeyPairSync,
  hkdfSync,
  randomBytes,
  sign,
  verify,
  type KeyObject,
} from "node:crypto";

export const PRODUCT = "kms-outline";
export const LICENSE_TYPE = "kms-license";
export const REQUEST_TYPE = "kms-license-request";
export const LICENSE_ARMOR = "KMS ACTIVATION";
export const REQUEST_ARMOR = "KMS LICENSE REQUEST";
const REQUEST_HKDF_INFO = "kms-license-request-v1";
const LICENSE_HKDF_INFO = "kms-license-v2";
const ALG = "X25519-HKDF-SHA256-A256GCM";

export type HardwareIds = Record<string, string>;

export type LicenseRequest = {
  type: typeof REQUEST_TYPE;
  v: 1;
  product: string;
  createdAt: string;
  installId: string;
  serverKey: string;
  serverPublicKey: string;
  serverBoxKey: string;
  hw: HardwareIds;
  organization?: string;
  admin?: { name?: string; email?: string };
  /** Patch 0022: the form on the customer's License page. */
  contact?: { legalName?: string; firstName?: string; lastName?: string; phone?: string } | null;
  requested?: { days?: number; note?: string } | null;
  current?: {
    serial?: string;
    customer?: string;
    expiresAt?: string;
    activatedAt?: string;
  } | null;
  appVersion?: string;
};

export type LicensePayload = {
  type: typeof LICENSE_TYPE;
  v: 1;
  product: string;
  serial: string;
  customer: string;
  installId: string;
  serverKey: string;
  hw: HardwareIds;
  issuedAt: string;
  notBefore: string;
  expiresAt: string;
  warnDays: number;
  note?: string;
};

export class LicenseFormatError extends Error {}

const b64u = (buf: Buffer | string) => Buffer.from(buf).toString("base64url");
const fromB64u = (text: string) => Buffer.from(text, "base64url");

export function armor(label: string, body: string) {
  const lines = body.match(/.{1,64}/g) ?? [];
  return `-----BEGIN ${label}-----\n${lines.join("\n")}\n-----END ${label}-----\n`;
}

export function unarmor(label: string, text: string) {
  const m = new RegExp(
    `-----BEGIN ${label}-----([\\s\\S]*?)-----END ${label}-----`
  ).exec(text);
  return m ? m[1].replace(/\s+/g, "") : undefined;
}

export const keyFingerprint = (key: KeyObject) =>
  createHash("sha256")
    .update(key.export({ type: "spki", format: "der" }))
    .digest("hex");

const rawX25519 = (key: KeyObject) =>
  fromB64u(key.export({ format: "jwk" }).x as string);
const x25519FromRaw = (x: string) =>
  createPublicKey({ key: { kty: "OKP", crv: "X25519", x }, format: "jwk" });

function boxSeal(plain: Buffer, recipient: KeyObject, info: string) {
  const eph = generateKeyPairSync("x25519");
  const epk = rawX25519(eph.publicKey);
  const shared = diffieHellman({ privateKey: eph.privateKey, publicKey: recipient });
  const key = Buffer.from(
    hkdfSync("sha256", shared, Buffer.concat([epk, rawX25519(recipient)]), info, 32)
  );
  const iv = randomBytes(12);
  const c = createCipheriv("aes-256-gcm", key, iv);
  const ct = Buffer.concat([c.update(plain), c.final(), c.getAuthTag()]);
  return b64u(
    Buffer.from(
      JSON.stringify({ v: 1, alg: ALG, epk: b64u(epk), iv: b64u(iv), ct: b64u(ct) }),
      "utf8"
    )
  );
}

function boxOpen(body: string, recipientPrivate: KeyObject, info: string) {
  const env = JSON.parse(fromB64u(body).toString("utf8"));
  if (env.v !== 1 || env.alg !== ALG) {
    throw new Error("unsupported envelope");
  }
  const epk = fromB64u(env.epk);
  const shared = diffieHellman({
    privateKey: recipientPrivate,
    publicKey: x25519FromRaw(env.epk),
  });
  const key = Buffer.from(
    hkdfSync(
      "sha256",
      shared,
      Buffer.concat([epk, rawX25519(createPublicKey(recipientPrivate))]),
      info,
      32
    )
  );
  const ct = fromB64u(env.ct);
  const d = createDecipheriv("aes-256-gcm", key, fromB64u(env.iv));
  d.setAuthTag(ct.subarray(ct.length - 16));
  return Buffer.concat([d.update(ct.subarray(0, ct.length - 16)), d.final()]);
}

/** Decrypts and verifies a customer's request file. */
export function openRequest(text: string, boxPrivate: KeyObject): LicenseRequest {
  const body = unarmor(REQUEST_ARMOR, text);
  if (!body) {
    throw new LicenseFormatError("فایل درخواست لایسنس KMS (‎.kmsreq‎) نیست");
  }
  let plain: Buffer;
  try {
    plain = boxOpen(body, boxPrivate, REQUEST_HKDF_INFO);
  } catch {
    throw new LicenseFormatError(
      "درخواست باز نمی‌شود: برای کلید فروشنده دیگری ساخته شده یا تغییر کرده است"
    );
  }
  let payload: LicenseRequest;
  try {
    const { inner, sig } = JSON.parse(plain.toString("utf8"));
    const innerBytes = fromB64u(inner);
    payload = JSON.parse(innerBytes.toString("utf8"));
    const serverPublic = createPublicKey(payload.serverPublicKey);
    if (!verify(null, innerBytes, serverPublic, fromB64u(sig))) {
      throw new LicenseFormatError("امضای درخواست معتبر نیست");
    }
    if (keyFingerprint(serverPublic) !== payload.serverKey) {
      throw new LicenseFormatError("کلید سرور در درخواست هم‌خوان نیست");
    }
  } catch (err) {
    throw err instanceof LicenseFormatError
      ? err
      : new LicenseFormatError("ساختار درخواست نادرست است");
  }
  if (payload.type !== REQUEST_TYPE || payload.v !== 1) {
    throw new LicenseFormatError("نوع درخواست پشتیبانی نمی‌شود");
  }
  if (payload.product !== PRODUCT) {
    throw new LicenseFormatError(`درخواست برای محصول دیگری است: ${payload.product}`);
  }
  if (!payload.serverBoxKey) {
    throw new LicenseFormatError(
      "درخواست از نسخه قدیمی سرور است و کلید رمزنگاری ندارد؛ سرور مشتری را به‌روز کنید"
    );
  }
  return payload;
}

/** Signs with the vendor key, then encrypts for the one server that asked. */
export function sealLicense(
  payload: LicensePayload,
  signPrivate: KeyObject,
  serverBoxKey: string
) {
  const bytes = Buffer.from(JSON.stringify(payload), "utf8");
  const plain = Buffer.from(
    JSON.stringify({ p: b64u(bytes), s: b64u(sign(null, bytes, signPrivate)) }),
    "utf8"
  );
  return armor(
    LICENSE_ARMOR,
    boxSeal(plain, x25519FromRaw(serverBoxKey), LICENSE_HKDF_INFO)
  );
}

/** Customer side, used only by tests: opens a license with the server box key. */
export function openLicenseForTest(
  text: string,
  serverBoxPrivate: KeyObject,
  vendorSignPublic: KeyObject
): LicensePayload {
  const body = unarmor(LICENSE_ARMOR, text);
  if (!body) {
    throw new LicenseFormatError("not a license");
  }
  const { p, s } = JSON.parse(
    boxOpen(body, serverBoxPrivate, LICENSE_HKDF_INFO).toString("utf8")
  );
  const bytes = fromB64u(p);
  if (!verify(null, bytes, vendorSignPublic, fromB64u(s))) {
    throw new LicenseFormatError("bad signature");
  }
  return JSON.parse(bytes.toString("utf8"));
}

export const requestHash = (text: string) =>
  createHash("sha256")
    .update(unarmor(REQUEST_ARMOR, text) ?? text.replace(/\s+/g, ""))
    .digest("hex");
