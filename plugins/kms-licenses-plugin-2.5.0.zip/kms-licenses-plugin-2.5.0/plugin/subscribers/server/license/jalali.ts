// kms-licenses plugin v2.5.0
// Jalali <-> Gregorian (jalaali algorithm, same as kms-license.mjs 1.1).
const div = (a: number, b: number) => ~~(a / b);
const mod = (a: number, b: number) => a - ~~(a / b) * b;

function jalCal(jy: number) {
  const breaks = [
    -61, 9, 38, 199, 426, 686, 756, 818, 1111, 1181, 1210, 1635, 2060, 2097,
    2192, 2262, 2324, 2394, 2456, 3178,
  ];
  const gy = jy + 621;
  let leapJ = -14;
  let jp = breaks[0];
  let jm = 0;
  let jump = 0;
  if (jy < jp || jy >= breaks[breaks.length - 1]) {
    throw new Error(`invalid Jalali year ${jy}`);
  }
  for (let i = 1; i < breaks.length; i += 1) {
    jm = breaks[i];
    jump = jm - jp;
    if (jy < jm) {
      break;
    }
    leapJ = leapJ + div(jump, 33) * 8 + div(mod(jump, 33), 4);
    jp = jm;
  }
  const n = jy - jp;
  leapJ = leapJ + div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
  if (mod(jump, 33) === 4 && jump - n === 4) {
    leapJ += 1;
  }
  const leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
  return { gy, march: 20 + leapJ - leapG };
}

const g2d = (gy: number, gm: number, gd: number) =>
  div((gy + div(gm - 8, 6) + 100100) * 1461, 4) +
  div(153 * mod(gm + 9, 12) + 2, 5) +
  gd -
  34840408 -
  div(div(gy + 100100 + div(gm - 8, 6), 100) * 3, 4) +
  752;

function d2g(jdn: number) {
  let j = 4 * jdn + 139361631;
  j = j + div(div(4 * jdn + 183187720, 146097) * 3, 4) * 4 - 3908;
  const i = div(mod(j, 1461), 4) * 5 + 308;
  const gd = div(mod(i, 153), 5) + 1;
  const gm = mod(div(i, 153), 12) + 1;
  return { gy: div(j, 1461) - 100100 + div(8 - gm, 6), gm, gd };
}

export function jalaliToGregorian(jy: number, jm: number, jd: number) {
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31 || (jm > 6 && jd > 30)) {
    throw new Error("invalid Jalali date");
  }
  const r = jalCal(jy);
  return d2g(g2d(r.gy, 3, r.march) + (jm - 1) * 31 - div(jm, 7) * (jm - 7) + jd - 1);
}

export const faDigits = (s: string) =>
  String(s)
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x6f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x660));

const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Parses "1406/12/29" (end of that day, Tehran) or "1406/12/29 14:30".
 * Persian digits are accepted.
 */
export function parseJalali(text: string, endOfDay = true): Date {
  const m =
    /^(\d{4})[/-](\d{1,2})[/-](\d{1,2})(?:[ T]+(\d{1,2}):(\d{2}))?$/.exec(
      faDigits(text).trim()
    );
  if (!m) {
    throw new Error("تاریخ شمسی باید مثل ۱۴۰۶/۱۲/۲۹ یا ۱۴۰۶/۱۲/۲۹ ۱۴:۳۰ باشد");
  }
  const { gy, gm, gd } = jalaliToGregorian(+m[1], +m[2], +m[3]);
  const time =
    m[4] !== undefined
      ? `${pad(+m[4])}:${m[5]}:00`
      : endOfDay
        ? "23:59:59"
        : "00:00:00";
  const d = new Date(`${gy}-${pad(gm)}-${pad(gd)}T${time}+03:30`);
  if (Number.isNaN(d.getTime())) {
    throw new Error("تاریخ نامعتبر است");
  }
  return d;
}
