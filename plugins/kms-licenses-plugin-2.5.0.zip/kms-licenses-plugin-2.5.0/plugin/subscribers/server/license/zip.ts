/**
 * Password-protected .zip files for the license request and the activation code.
 *
 * Both files travel as a zip with one entry, encrypted with WinZip AES-256
 * (AE-2; opens in 7-Zip, WinRAR, Windows 11, `7z x`). The file name carries
 * no customer data, only a random token:
 *   KMS-<TOKEN>.zip        TOKEN = 16 characters A-Z, 2-7
 * and the password is derived from that token:
 *   password = first 32 hex characters of HMAC-SHA256(key "KMS-ZIP-1", TOKEN)
 * By hand:
 *   printf %s TOKEN | openssl dgst -sha256 -hmac KMS-ZIP-1 | awk '{print $NF}' | cut -c1-32
 * Only the token is used, so a browser adding " (1)" to the name does no harm.
 * The entry inside stays encrypted for the vendor (request) or the server
 * (activation) as before: the zip password only hides the file from casual eyes.
 *
 * Reading also accepts an unencrypted zip (requests of servers with patch
 * 0022 only) and AES-128/192 entries.
 *
 * Same code in: kms-license.mjs (vendor tool) and the kms-licenses plugin
 * (server/license/zip.ts).
 *
 * VERSION: 2.0 (2026-10-17) — kms-licenses plugin v2.5.0 (copy of server/license/zip.ts, KMS patch 0025)
 */
import {
  createCipheriv,
  createHmac,
  pbkdf2Sync,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";
import { deflateRawSync, inflateRawSync } from "node:zlib";

export const ZIP_SECRET = "KMS-ZIP-1";
const TOKEN_RE = /KMS-([A-Z2-7]{16})/i;
const B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";

export class ZipError extends Error {}

/** A new random token and the file name that carries it. */
export function newZipName() {
  const bytes = randomBytes(10);
  let bits = 0;
  let value = 0;
  let token = "";
  for (const b of bytes) {
    value = (value << 8) | b;
    bits += 8;
    while (bits >= 5) {
      token += B32[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  return { token, fileName: `KMS-${token}.zip` };
}

/** The token in a file name, or null. */
export function tokenOf(fileName: string) {
  const m = TOKEN_RE.exec(fileName || "");
  return m ? m[1].toUpperCase() : null;
}

/** The zip password for a file name, or null when the name has no token. */
export function passwordFor(fileName: string) {
  const token = tokenOf(fileName);
  return token ? zipPassword(token) : null;
}

/** The zip password for a file name (or a bare token). */
export function zipPassword(fileNameOrToken: string) {
  const token = tokenOf(fileNameOrToken) ?? (/^[A-Z2-7]{16}$/i.test(fileNameOrToken) ? fileNameOrToken.toUpperCase() : null);
  if (!token) {
    throw new ZipError(
      "file name must keep its KMS-XXXXXXXXXXXXXXXX part (the password comes from it)"
    );
  }
  return createHmac("sha256", ZIP_SECRET).update(token).digest("hex").slice(0, 32);
}

// --- AES (WinZip AE-2) -------------------------------------------------------

const KEY_LEN: Record<number, number> = { 1: 16, 2: 24, 3: 32 };

/** AES-CTR with WinZip's little-endian counter starting at 1. */
function aesCtr(key: Buffer, data: Buffer) {
  const ecb = createCipheriv(`aes-${key.length * 8}-ecb`, key, null);
  ecb.setAutoPadding(false);
  const out = Buffer.alloc(data.length);
  const counter = Buffer.alloc(16);
  for (let off = 0, n = 1; off < data.length; off += 16, n++) {
    counter.fill(0);
    let v = n;
    for (let i = 0; i < 8 && v > 0; i++) {
      counter[i] = v & 0xff;
      v = Math.floor(v / 256);
    }
    const ks = ecb.update(counter);
    const end = Math.min(16, data.length - off);
    for (let i = 0; i < end; i++) {
      out[off + i] = data[off + i] ^ ks[i];
    }
  }
  return out;
}

function deriveKeys(password: string, salt: Buffer, strength: number) {
  const len = KEY_LEN[strength];
  const dk = pbkdf2Sync(Buffer.from(password, "utf8"), salt, 1000, 2 * len + 2, "sha1");
  return { enc: dk.subarray(0, len), mac: dk.subarray(len, 2 * len), check: dk.subarray(2 * len) };
}

function dosDateTime(d: Date) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2);
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}

/**
 * Builds a zip with one AES-256 encrypted, deflated entry.
 *
 * @param entryName The name of the file inside the zip.
 * @param data The file contents.
 * @param password The zip password.
 * @returns The zip bytes.
 */
export function writeEncryptedZip(entryName: string, data: Buffer | string, password: string) {
  const plain = Buffer.isBuffer(data) ? data : Buffer.from(data, "utf8");
  const salt = randomBytes(16);
  const keys = deriveKeys(password, salt, 3);
  const ct = aesCtr(keys.enc, deflateRawSync(plain));
  const auth = createHmac("sha1", keys.mac).update(ct).digest().subarray(0, 10);
  const body = Buffer.concat([salt, keys.check, ct, auth]);
  const name = Buffer.from(entryName, "utf8");
  // AES extra field: AE-2, "AE", strength 3 (256), real method 8 (deflate)
  const extra = Buffer.alloc(11);
  extra.writeUInt16LE(0x9901, 0);
  extra.writeUInt16LE(7, 2);
  extra.writeUInt16LE(2, 4);
  extra.write("AE", 6, "latin1");
  extra.writeUInt8(3, 8);
  extra.writeUInt16LE(8, 9);
  const { time, date } = dosDateTime(new Date());
  const flags = 0x0001 | 0x0800; // encrypted, UTF-8 name

  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(51, 4);
  local.writeUInt16LE(flags, 6);
  local.writeUInt16LE(99, 8);
  local.writeUInt16LE(time, 10);
  local.writeUInt16LE(date, 12);
  local.writeUInt32LE(0, 14); // CRC is 0 in AE-2
  local.writeUInt32LE(body.length, 18);
  local.writeUInt32LE(plain.length, 22);
  local.writeUInt16LE(name.length, 26);
  local.writeUInt16LE(extra.length, 28);

  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0);
  central.writeUInt16LE(0x033f, 4); // made by: Unix, 6.3
  central.writeUInt16LE(51, 6);
  central.writeUInt16LE(flags, 8);
  central.writeUInt16LE(99, 10);
  central.writeUInt16LE(time, 12);
  central.writeUInt16LE(date, 14);
  central.writeUInt32LE(0, 16);
  central.writeUInt32LE(body.length, 20);
  central.writeUInt32LE(plain.length, 24);
  central.writeUInt16LE(name.length, 28);
  central.writeUInt16LE(extra.length, 30);
  central.writeUInt32LE((0o100644 << 16) >>> 0, 38);
  central.writeUInt32LE(0, 42);

  const cdOffset = local.length + name.length + extra.length + body.length;
  const cdSize = central.length + name.length + extra.length;
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(1, 8);
  end.writeUInt16LE(1, 10);
  end.writeUInt32LE(cdSize, 12);
  end.writeUInt32LE(cdOffset, 16);
  return Buffer.concat([local, name, extra, body, central, name, extra, end]);
}

/**
 * Reads the first file of a zip: AES encrypted (with the password) or not
 * encrypted at all.
 *
 * @param zip The zip bytes.
 * @param password The zip password (null: the file name had no token).
 * @returns The entry name and contents.
 */
export function readZip(zip: Buffer, password: string | null) {
  if (zip.length < 22 || zip.readUInt32LE(0) !== 0x04034b50) {
    throw new ZipError("not a zip file");
  }
  let eocd = -1;
  for (let i = zip.length - 22; i >= Math.max(0, zip.length - 22 - 65535); i--) {
    if (zip.readUInt32LE(i) === 0x06054b50) {
      eocd = i;
      break;
    }
  }
  if (eocd < 0) {
    throw new ZipError("damaged zip file (no central directory)");
  }
  const count = zip.readUInt16LE(eocd + 10);
  let p = zip.readUInt32LE(eocd + 16);
  for (let n = 0; n < count; n++) {
    if (zip.readUInt32LE(p) !== 0x02014b50) {
      throw new ZipError("damaged zip file");
    }
    const flags = zip.readUInt16LE(p + 8);
    let method = zip.readUInt16LE(p + 10);
    const compSize = zip.readUInt32LE(p + 20);
    const nameLen = zip.readUInt16LE(p + 28);
    const extraLen = zip.readUInt16LE(p + 30);
    const commentLen = zip.readUInt16LE(p + 32);
    const localOffset = zip.readUInt32LE(p + 42);
    const name = zip.subarray(p + 46, p + 46 + nameLen).toString(flags & 0x0800 ? "utf8" : "latin1");
    const extra = zip.subarray(p + 46 + nameLen, p + 46 + nameLen + extraLen);
    p += 46 + nameLen + extraLen + commentLen;
    if (name.endsWith("/")) {
      continue;
    }
    const lNameLen = zip.readUInt16LE(localOffset + 26);
    const lExtraLen = zip.readUInt16LE(localOffset + 28);
    const start = localOffset + 30 + lNameLen + lExtraLen;
    let data = zip.subarray(start, start + compSize);
    if (flags & 0x0001) {
      if (method !== 99) {
        throw new ZipError("this zip uses the old ZipCrypto encryption; use AES-256");
      }
      let strength = 0;
      for (let e = 0; e + 4 <= extra.length; ) {
        const id = extra.readUInt16LE(e);
        const size = extra.readUInt16LE(e + 2);
        if (id === 0x9901) {
          strength = extra.readUInt8(e + 8);
          method = extra.readUInt16LE(e + 9);
        }
        e += 4 + size;
      }
      const len = KEY_LEN[strength];
      if (!len) {
        throw new ZipError("unsupported zip encryption");
      }
      if (password === null) {
        throw new ZipError(
          "file name must keep its KMS-XXXXXXXXXXXXXXXX part (the password comes from it)"
        );
      }
      const salt = data.subarray(0, len / 2);
      const keys = deriveKeys(password, salt, strength);
      const check = data.subarray(len / 2, len / 2 + 2);
      if (!check.equals(keys.check)) {
        throw new ZipError("wrong zip password: was the file renamed?");
      }
      const ct = data.subarray(len / 2 + 2, data.length - 10);
      const mac = createHmac("sha1", keys.mac).update(ct).digest().subarray(0, 10);
      if (!timingSafeEqual(mac, data.subarray(data.length - 10))) {
        throw new ZipError("the zip file is damaged or was changed");
      }
      data = aesCtr(keys.enc, ct);
    }
    if (method === 8) {
      data = inflateRawSync(data);
    } else if (method !== 0) {
      throw new ZipError(`unsupported zip compression (${method})`);
    }
    return { name, data: Buffer.from(data) };
  }
  throw new ZipError("the zip file is empty");
}
