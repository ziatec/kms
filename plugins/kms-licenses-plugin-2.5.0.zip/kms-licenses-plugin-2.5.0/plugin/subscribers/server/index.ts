// kms-licenses plugin v2.5.0
// On only on the vendor's own server: SUBSCRIBERS_ENABLED=true, or (when the
// variable is not set) when the vendor keys are present. SUBSCRIBERS_ENABLED=false
// always turns it off.
import fs from "node:fs";
import path from "node:path";
import { PluginManager, Hook } from "@server/utils/PluginManager";
import config from "../plugin.json";

const flag = process.env.SUBSCRIBERS_ENABLED;
const vendorDir = process.env.SUBSCRIBERS_VENDOR_DIR || "/etc/kms-license/vendor";
const enabled =
  flag === "true" ||
  (flag === undefined && fs.existsSync(path.join(vendorDir, "private.json")));

if (enabled) {
  // oxlint-disable-next-line typescript/no-require-imports -- load the plugin only when enabled
  const router = require("./api/router").default;
  PluginManager.add({
    ...config,
    type: Hook.API,
    value: router,
  });
}
