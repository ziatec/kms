// kms-licenses plugin v2.5.0
import Router from "@koa/router";
import { z } from "zod";
import { UserRole } from "@shared/types";
import { InvalidRequestError, NotFoundError, ValidationError } from "@server/errors";
import Logger from "@server/logging/Logger";
import auth from "@server/middlewares/authentication";
import validate from "@server/middlewares/validate";
import { BaseSchema } from "@server/routes/api/schema";
import type { APIContext } from "@server/types";
import { DB_NAME, ensureReady, SCHEMA } from "../db/database";
import * as store from "../db/store";
import { licenseHome, loadVendorKeys } from "../license/keys";
import { PRODUCT } from "../license/format";
import * as service from "../service";
import { presentCustomer, presentEvent, presentLicense, presentRequest } from "./presenters";

export const VERSION = "2.5.0";

const router = new Router();

const text = (max: number) =>
  z
    .string()
    .max(max)
    .nullish()
    .transform((v) => (v && v.trim() ? v.trim() : null));

const actorOf = (ctx: APIContext) => {
  const { user } = ctx.state.auth;
  return { id: user.id, name: user.name };
};

/**
 * This server's own KMS license (patch 0008-license), shown for information only. The
 * plugin never depends on it: it keeps working when Outline is read-only, so a
 * new license can always be issued. Loaded at runtime, so the plugin also runs
 * on an Outline without patch 0008-license.
 */
function ownLicense() {
  try {
    // build/plugins/subscribers/server/api -> build/server/license/state
    // oxlint-disable-next-line typescript/no-require-imports -- optional, runtime only
    const state = require("../../../../server/license/state");
    const l = state.getLicenseInfo();
    return {
      available: true,
      status: String(l.status),
      readOnly: !!l.readOnly,
      serial: l.serial ?? null,
      customer: l.customer ?? null,
      expiresAt: l.expiresAt ?? null,
      daysLeft: typeof l.daysLeft === "number" ? l.daysLeft : null,
    };
  } catch {
    return { available: false, status: "none", readOnly: false, serial: null, customer: null, expiresAt: null, daysLeft: null };
  }
}

/** Admin only, database ready, plugin errors turned into API errors. */
function handler<C extends APIContext>(fn: (ctx: C) => Promise<unknown>) {
  return async (ctx: C) => {
    try {
      await ensureReady();
      ctx.body = { data: await fn(ctx) };
    } catch (err) {
      if (err instanceof service.UserError) {
        throw ValidationError(err.message);
      }
      if (err instanceof Error && /ECONNREFUSED|does not exist|password authentication/i.test(err.message)) {
        Logger.error("subscribers: database error", err);
        throw InvalidRequestError(`پایگاه داده افزونه در دسترس نیست: ${err.message}`);
      }
      throw err;
    }
  };
}

const admin = () => auth({ role: UserRole.Admin });

router.post(
  "subscribers.status",
  admin(),
  async (ctx: APIContext) => {
    const { user } = ctx.state.auth;
    const { keys, error: keyError } = loadVendorKeys();
    let database: { ok: boolean; error?: string; counts?: unknown } = { ok: true };
    try {
      await ensureReady();
      database = { ok: true, counts: await store.counts(user.teamId) };
    } catch (err) {
      database = { ok: false, error: (err as Error).message };
    }
    ctx.body = {
      data: {
        version: VERSION,
        product: PRODUCT,
        schema: SCHEMA,
        databaseName: DB_NAME,
        separateDatabase: !!process.env.SUBSCRIBERS_DATABASE_URL,
        licenseHome: licenseHome(),
        keys: keys
          ? {
              ready: true,
              fingerprint: keys.fingerprint,
              created: keys.created,
              signPublic: keys.signPublic.export({ format: "jwk" }).x,
            }
          : { ready: false, error: keyError },
        database,
        license: ownLicense(),
      },
    };
  }
);

router.post(
  "subscribers.customers.list",
  admin(),
  handler(async (ctx: APIContext) => {
    const list = await store.listCustomers(ctx.state.auth.user.teamId);
    return list.map((c) => ({
      ...presentCustomer(c),
      installCount: c.installCount,
      licenseCount: c.licenseCount,
      pendingCount: c.pendingCount,
      lastSerial: c.lastSerial,
      lastExpiresAt: c.lastExpiresAt,
      lastWarnDays: c.lastWarnDays,
      lastActivatedAt: c.lastActivatedAt,
      lastRequestAt: c.lastRequestAt,
    }));
  })
);

const IdSchema = BaseSchema.extend({ body: z.object({ id: z.uuid() }) });

router.post(
  "subscribers.customers.info",
  admin(),
  validate(IdSchema),
  handler(async (ctx: APIContext<z.infer<typeof IdSchema>>) => {
    const { teamId } = ctx.state.auth.user;
    const customer = await store.getCustomer(teamId, ctx.input.body.id);
    if (!customer) {
      throw NotFoundError("Customer not found");
    }
    const [requests, licenses, events] = await Promise.all([
      store.listRequests(customer.id),
      store.listLicenses(customer.id),
      store.listEvents(customer.id),
    ]);
    return {
      customer: presentCustomer(customer),
      requests: requests.map(presentRequest),
      licenses: licenses.map(presentLicense),
      events: events.map(presentEvent),
    };
  })
);

const CustomerSchema = BaseSchema.extend({
  body: z.object({
    id: z.uuid().optional(),
    name: z.string().trim().min(1).max(255),
    organization: text(255),
    contactName: text(255),
    phone: text(64),
    mobile: text(64),
    email: text(255),
    city: text(128),
    address: text(2000),
    notes: text(10000),
    status: z.enum(["active", "inactive"]).optional(),
  }),
});

router.post(
  "subscribers.customers.save",
  admin(),
  validate(CustomerSchema),
  handler(async (ctx: APIContext<z.infer<typeof CustomerSchema>>) => {
    const { teamId } = ctx.state.auth.user;
    const actor = actorOf(ctx);
    const { id, ...input } = ctx.input.body;
    if (id) {
      const row = await store.updateCustomer(teamId, id, input);
      if (!row) {
        throw NotFoundError("Customer not found");
      }
      await store.addEvent(teamId, id, actor, { kind: "update", title: "ویرایش مشخصات" });
      return presentCustomer(row);
    }
    const row = await store.createCustomer(teamId, actor, input);
    await store.addEvent(teamId, row.id, actor, { kind: "create", title: "ثبت مشتری" });
    return presentCustomer(row);
  })
);

const NoteSchema = BaseSchema.extend({
  body: z.object({ id: z.uuid(), text: z.string().trim().min(1).max(10000) }),
});

router.post(
  "subscribers.customers.note",
  admin(),
  validate(NoteSchema),
  handler(async (ctx: APIContext<z.infer<typeof NoteSchema>>) => {
    const { teamId } = ctx.state.auth.user;
    const { id, text: body } = ctx.input.body;
    if (!(await store.getCustomer(teamId, id))) {
      throw NotFoundError("Customer not found");
    }
    const row = await store.addEvent(teamId, id, actorOf(ctx), { kind: "note", title: "یادداشت", body });
    return presentEvent(row!);
  })
);

// 2.5.0: a request arrives only as the customer's .zip (base64) with its file
// name, from which the zip password is derived.
const zipFile = {
  zip: z.string().min(16).max(200000),
  fileName: z.string().min(1).max(255),
};
const RequestZipSchema = BaseSchema.extend({ body: z.object(zipFile) });

router.post(
  "subscribers.requests.inspect",
  admin(),
  validate(RequestZipSchema),
  handler((ctx: APIContext<z.infer<typeof RequestZipSchema>>) =>
    service.inspect(
      ctx.state.auth.user.teamId,
      service.requestFromZip(ctx.input.body.zip, ctx.input.body.fileName)
    )
  )
);

const AddRequestSchema = BaseSchema.extend({
  body: z.object({ ...zipFile, customerId: z.uuid() }),
});

router.post(
  "subscribers.requests.add",
  admin(),
  validate(AddRequestSchema),
  handler(async (ctx: APIContext<z.infer<typeof AddRequestSchema>>) => {
    const { zip, fileName, customerId } = ctx.input.body;
    const r = await service.addRequest(
      ctx.state.auth.user.teamId,
      actorOf(ctx),
      customerId,
      service.requestFromZip(zip, fileName)
    );
    return { request: presentRequest(r.request), duplicate: r.duplicate };
  })
);

const RejectSchema = BaseSchema.extend({
  body: z.object({ id: z.uuid(), reason: text(2000) }),
});

router.post(
  "subscribers.requests.reject",
  admin(),
  validate(RejectSchema),
  handler(async (ctx: APIContext<z.infer<typeof RejectSchema>>) =>
    presentRequest(
      await service.rejectRequest(
        ctx.state.auth.user.teamId,
        actorOf(ctx),
        ctx.input.body.id,
        ctx.input.body.reason
      )
    )
  )
);

const IssueSchema = BaseSchema.extend({
  body: z.object({
    requestId: z.uuid(),
    customerName: text(255),
    days: z.number().int().positive().max(3660).nullish(),
    untilJalali: text(32),
    warnDays: z.number().int().min(0).max(365).nullish(),
    note: text(2000),
  }),
});

router.post(
  "subscribers.licenses.issue",
  admin(),
  validate(IssueSchema),
  handler(async (ctx: APIContext<z.infer<typeof IssueSchema>>) =>
    presentLicense(await service.issue(ctx.state.auth.user.teamId, actorOf(ctx), ctx.input.body))
  )
);

/** 2.5.0: the activation code of a license as a password-protected KMS-<TOKEN>.zip. */
router.post(
  "subscribers.licenses.zip",
  admin(),
  validate(IdSchema),
  handler(async (ctx: APIContext<z.infer<typeof IdSchema>>) => {
    const lic = await store.getLicense(ctx.state.auth.user.teamId, ctx.input.body.id);
    if (!lic?.licenseText) {
      throw NotFoundError("License file not found");
    }
    return { serial: lic.serial, ...service.licenseZip(lic.licenseText) };
  })
);

const LicenseUpdateSchema = BaseSchema.extend({
  body: z.object({
    id: z.uuid(),
    activatedAt: z.string().max(40).nullish(),
    revoke: z.boolean().optional(),
  }),
});

router.post(
  "subscribers.licenses.update",
  admin(),
  validate(LicenseUpdateSchema),
  handler(async (ctx: APIContext<z.infer<typeof LicenseUpdateSchema>>) => {
    const { id, activatedAt, revoke } = ctx.input.body;
    return presentLicense(
      await service.updateLicense(ctx.state.auth.user.teamId, actorOf(ctx), id, {
        activatedAt: activatedAt === undefined ? undefined : activatedAt || null,
        revoke,
      })
    );
  })
);

router.post(
  "subscribers.import",
  admin(),
  handler((ctx: APIContext) => service.importLedger(ctx.state.auth.user.teamId, actorOf(ctx)))
);

export default router;
