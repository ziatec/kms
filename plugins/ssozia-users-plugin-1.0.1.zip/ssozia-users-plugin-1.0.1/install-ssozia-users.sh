#!/usr/bin/env bash
# VERSION: 1.1 (2026-10-15)  installer of the ssozia-users plugin v1.0.1 (users & organization chart)
#   1.1: plugin 1.0.1 for Outline 1.11.0 (koa-router -> @koa/router, missing type import); the Outline
#        source folder and image tag are found from build/outline-*; the hooks patch is 0010-plugin-hooks
# =============================================================================
#  Attaches the plugin to an Outline installed by kms install.sh (10.0+). The
#  users and the organization chart live in ssozia itself (DATA_DIR of ssozia:
#  users-admin.json, orgchart.json); the plugin is only the admin screen inside
#  Outline and talks to ssozia's admin API with Outline's own OIDC client.
#
#  Needs: build/outline-X.Y.Z patched with 0010-plugin-hooks, and ssozia 0.2.0+
#  (put the new ssozia.zip into the kit's assets/ and run install.sh --from 6).
#
#  What it does (each step asks first; Enter = yes):
#    1. checks that ssozia offers the admin API (0.2.0+)
#    2. copies the plugin into <kms>/build/outline-X.Y.Z/plugins/ssozia-users
#    3. yarn build (the same Node and Yarn install.sh used), then build/ into images/outline/app
#    4. rebuilds the kms/outline image
#    5. restarts only the outline container and waits until it is healthy
#    6. verifies the plugin inside the container
#
#  Usage: bash install-ssozia-users.sh [--kms DIR] [--yes] [--remove] [--version] [--help]
#    --kms DIR     install folder (default: from ~/kms/.kms-target, else /srv/kms)
#    --yes         default answers everywhere
#    --remove      detach the plugin (ssozia keeps its users and chart)
#
#  Run it again after install.sh re-ran step 4. Steps 7-10 of install.sh keep the plugin.
# =============================================================================
set -Eeuo pipefail

VERSION="1.1"
PLUGIN_VERSION="1.0.1"
PLUGIN_ID="ssozia-users"
SELF="$(readlink -f "${BASH_SOURCE[0]}")"; HERE="$(dirname "$SELF")"
PLUGIN_SRC="$HERE/plugin/$PLUGIN_ID"
PROJECT="kms"

KMS=""; YES=0; REMOVE=0
while (($#)); do
  case "$1" in
    --kms) KMS="${2:?--kms needs a folder}"; shift 2 ;;
    --yes) YES=1; shift ;;
    --remove) REMOVE=1; shift ;;
    --version) echo "install-ssozia-users.sh $VERSION (ssozia-users $PLUGIN_VERSION)"; exit 0 ;;
    --help|-h) sed -n '2,27p' "$SELF" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "unknown option: $1 (see --help)" >&2; exit 2 ;;
  esac
done

if [[ -t 1 ]]; then C_G=$'\e[32m'; C_Y=$'\e[33m'; C_R=$'\e[31m'; C_B=$'\e[1m'; C_0=$'\e[0m'; else C_G=""; C_Y=""; C_R=""; C_B=""; C_0=""; fi
ok()   { printf '  [%sOK%s]   %s\n' "$C_G" "$C_0" "$*"; }
warn() { printf '  [%sWARN%s] %s\n' "$C_Y" "$C_0" "$*"; }
info() { printf '  [....] %s\n' "$*"; }
fail() { printf '  [%sFAIL%s] %s\n' "$C_R" "$C_0" "$*"; [[ -n ${LOG:-} ]] && printf '  Log: %s\n' "$LOG"; exit 1; }
section() { printf '\n%s==== %s ====%s\n' "$C_B" "$*" "$C_0"; }
trap 'fail "line $LINENO: $BASH_COMMAND"' ERR

ask_yn() { # ask_yn "question" default(y|n) ; Persian-layout keys accepted
  local q="$1" d="$2" a
  if ((YES)) || [[ ! -t 0 ]]; then [[ $d == y ]]; return; fi
  read -r -p "  $q [$([[ $d == y ]] && echo Y/n || echo y/N)] " a || a=""
  case "${a:-$d}" in y|Y|yes|غ|بله|ب) return 0 ;; n|N|no|د|خیر|خ) return 1 ;; *) [[ $d == y ]] ;; esac
}
ask_text() { local q="$1" d="$2" a; if ((YES)) || [[ ! -t 0 ]]; then echo "$d"; return; fi; read -r -p "  $q [$d] " a || a=""; echo "${a:-$d}"; }

if [[ $EUID -eq 0 ]]; then SUDO=""; else SUDO="sudo"; command -v sudo >/dev/null || fail "sudo is required."; sudo -v || fail "sudo access is required."; fi
dk() { if [[ -z $SUDO ]] || docker info >/dev/null 2>&1; then docker "$@"; else $SUDO docker "$@"; fi; }

section "ssozia-users plugin $PLUGIN_VERSION - install-ssozia-users.sh $VERSION"
[[ -f $PLUGIN_SRC/plugin.json ]] || fail "No plugin/$PLUGIN_ID next to this script (unzip the whole package)."

# --- install folder -----------------------------------------------------------
if [[ -z $KMS ]]; then
  if [[ -f $HOME/kms/.kms-target ]]; then KMS="$(head -n1 "$HOME/kms/.kms-target")"; else KMS="/srv/kms"; fi
  KMS="$(ask_text "Install folder of kms" "$KMS")"
fi
KMS="$(readlink -f "$KMS")"
# The patched Outline source install.sh built last (the highest version in build/).
SRC_NAME="${SRC_NAME:-$(find "$KMS/build" -maxdepth 1 -type d -name 'outline-[0-9]*' -printf '%f\n' 2>/dev/null | sort -V | tail -n1)}"
[[ -n $SRC_NAME ]] || fail "No $KMS/build/outline-X.Y.Z: run kms install.sh step 4."
IMG_OUTLINE="kms/outline:${SRC_NAME#outline-}"
SRC="$KMS/build/$SRC_NAME"; APP="$KMS/images/outline/app"; CONFIG="$KMS/config"
[[ -f $KMS/docker-compose.yml ]] || fail "$KMS has no docker-compose.yml: run kms install.sh first."
[[ -f $SRC/package.json ]] || fail "No $SRC: run install.sh step 4."
mkdir -p "$KMS/logs"; TS="$(date +%Y%m%d-%H%M%S)"; LOG="$KMS/logs/install-$PLUGIN_ID-$TS.log"
exec > >(tee -a "$LOG") 2>&1
ok "Install folder: $KMS"

# The hooks of patch 0010 must be in the source tree.
if ! grep -q 'SidebarLink = "sidebarLink"' "$SRC/app/utils/PluginManager.ts"; then
  fail "build/$SRC_NAME lacks patch 0010-plugin-hooks. Put the new patches.zip into the kit's assets/,
         run install.sh (steps 4, 7, 8, 10), then run this script again."
fi
ok "Patch 0016 (plugin hooks) is in build/$SRC_NAME"

# --- Node and Yarn as install.sh step 7 used them ----------------------------
if [[ -x $KMS/build/node/bin/node ]]; then NODE="$KMS/build/node/bin/node"; else NODE="$(command -v node || true)"; fi
[[ -n $NODE && -x $NODE ]] || fail "node not found (install.sh step 7 provides it)."
YJS="$KMS/build/yarn/package/bin/yarn.js"
[[ -f $YJS ]] || fail "No $YJS (install.sh step 7 provides it)."
export PATH="$(dirname "$NODE"):$PATH" YARN_ENABLE_TELEMETRY=0 YARN_NPM_REGISTRY_SERVER="${NPM_REGISTRY:-https://registry.npmjs.org}"
yarn_() { "$NODE" "$YJS" "$@"; }
ok "Node $("$NODE" -v), Yarn $(cd "$SRC" && yarn_ --version)"

dc() { (cd "$KMS" && dk compose -p "$PROJECT" -f "$KMS/docker-compose.yml" "$@"); }

# --- 1. ssozia admin API -----------------------------------------------------
if ((REMOVE == 0)); then
  section "1. ssozia admin API (0.2.0+)"
  ISSUER="$($SUDO sed -n 's#^OIDC_ISSUER_URL=##p' "$CONFIG/outline.env" 2>/dev/null | tail -n1)"
  [[ -n $ISSUER ]] || fail "config/outline.env has no OIDC_ISSUER_URL: Outline does not sign in through ssozia."
  CA=(); [[ -f $KMS/certs/ca/rootCA.pem ]] && CA=(--cacert "$KMS/certs/ca/rootCA.pem")
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "${CA[@]}" "${ISSUER%/}/admin/api/users" || true)"
  case "$code" in
    401|403) ok "ssozia at $ISSUER offers the admin API" ;;
    404) fail "ssozia at $ISSUER has no admin API: put ssozia.zip 0.2.0 into the kit's assets/ and run install.sh --from 6 first." ;;
    *) warn "ssozia at $ISSUER answered HTTP $code; continuing (the settings page shows the connection)." ;;
  esac
fi

# --- 2. plugin source ---------------------------------------------------------
section "2. Plugin source -> build/$SRC_NAME/plugins/$PLUGIN_ID"
if [[ -d $SRC/plugins/$PLUGIN_ID ]]; then
  mkdir -p "$KMS/archive/$TS"; mv "$SRC/plugins/$PLUGIN_ID" "$KMS/archive/$TS/plugin-$PLUGIN_ID"
  info "Previous plugin moved to archive/$TS/plugin-$PLUGIN_ID"
fi
if ((REMOVE)); then
  ok "Plugin taken out of the source tree"
else
  cp -r "$PLUGIN_SRC" "$SRC/plugins/$PLUGIN_ID"
  ok "Plugin $PLUGIN_VERSION copied ($(find "$SRC/plugins/$PLUGIN_ID" -type f | wc -l) files)"
fi

# --- 3. build -----------------------------------------------------------------
section "3. Build Outline (yarn build: 10-30 minutes on an ARM board)"
if ask_yn "Build now?" y; then
  if [[ ! -d $SRC/node_modules ]]; then
    info "build/$SRC_NAME/node_modules is missing: yarn install --immutable"
    (cd "$SRC" && yarn_ install --immutable) || fail "yarn install failed."
  fi
  (cd "$SRC" && NODE_OPTIONS="--max-old-space-size=${BUILD_MEM_MB:-4096}" yarn_ build) || fail "yarn build failed (log: $LOG)."
  if ((REMOVE == 0)); then
    [[ -f $SRC/build/plugins/$PLUGIN_ID/server/index.js ]] || fail "The build has no build/plugins/$PLUGIN_ID."
  fi
  [[ -d $APP ]] || fail "No images/outline/app: run install.sh step 7 once."
  if command -v rsync >/dev/null; then rsync -a --delete "$SRC/build/" "$APP/build/"
  else rm -rf "$APP/build"; cp -a "$SRC/build" "$APP/build"; fi
  ok "images/outline/app/build updated"
else
  warn "Build skipped: the running Outline is unchanged."; exit 0
fi

# --- 4. image -----------------------------------------------------------------
section "4. Docker image $IMG_OUTLINE"
dk buildx version >/dev/null 2>&1 || export DOCKER_BUILDKIT=0
dk build --network host -t "$IMG_OUTLINE" "$KMS/images/outline" || fail "docker build failed."
if [[ -f $APP/.kms-patches ]]; then cp -f "$APP/.kms-patches" "$KMS/images/outline/.kms-patches-image"; fi
ok "Image $IMG_OUTLINE rebuilt"

# --- 5. restart ---------------------------------------------------------------
section "5. Restart outline"
dc up -d --no-deps --pull never --force-recreate outline >/dev/null || fail "Could not start outline."
end=$((SECONDS + 900)); code=000
while ((SECONDS < end)); do
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 http://127.0.0.1:3000/_health || true)"
  [[ $code == 200 ]] && break
  [[ $(dk inspect -f '{{.State.Status}}' kms-outline 2>/dev/null || echo missing) == running ]] || { dc logs --tail 60 outline; fail "outline stopped (logs above)."; }
  sleep 5
done
[[ $code == 200 ]] || { dc logs --tail 60 outline; fail "Outline did not become healthy (logs above)."; }
ok "outline is running and healthy"

# --- 6. verify ----------------------------------------------------------------
section "6. Verify"
if ((REMOVE)); then
  if dk exec kms-outline test ! -e "build/plugins/$PLUGIN_ID"; then ok "Plugin is gone from the running Outline"; else warn "build/plugins/$PLUGIN_ID still exists in the container"; fi
  printf '\n  Detached. ssozia keeps its users and organization chart.\n'
  exit 0
fi
if dk exec kms-outline test -f "build/plugins/$PLUGIN_ID/server/index.js"; then ok "Plugin is in the running Outline"; else fail "Plugin is not in the container."; fi
if dc logs --since 15m outline 2>/dev/null | grep -qi "Failed to load plugin.*$PLUGIN_ID"; then
  dc logs --since 15m outline | grep -i -A5 "$PLUGIN_ID" | tail -20; fail "Outline could not load the plugin (log above)."
fi
ok "No plugin load errors in the Outline log"
printf '\n  Done. Sign in as an admin (who is also an ssozia admin): the sidebar shows «مدیریت کاربران»\n'
printf '  (/ssozia-users, /ssozia-users/org); Settings -> مدیریت کاربران shows the ssozia connection.\n'
printf '  Log: %s\n' "$LOG"
