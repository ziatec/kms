// ssozia-users plugin v1.0.0
// Outline API endpoints (admins only) that forward to the ssozia admin API.
import Router from "@koa/router";
import { z } from "zod";
import { UserRole } from "@shared/types";
import { InvalidRequestError, ValidationError } from "@server/errors";
import auth from "@server/middlewares/authentication";
import validate from "@server/middlewares/validate";
import { transaction } from "@server/middlewares/transaction";
import { User } from "@server/models";
import { can } from "@server/policies";
import { BaseSchema } from "@server/routes/api/schema";
import type { APIContext } from "@server/types";
import { ssozia, SsoziaError, ssoziaUrl } from "../ssozia";

export const VERSION = "1.0.0";

const router = new Router();
const admin = () => auth({ role: UserRole.Admin });

/** Forwards to ssozia as the signed-in Outline admin. */
function forward<C extends APIContext>(
  method: "GET" | "POST",
  path: (ctx: C) => string,
  body?: (ctx: C) => unknown
) {
  return async (ctx: C) => {
    const { user } = ctx.state.auth;
    try {
      ctx.body = {
        data: await ssozia(user.email ?? "", method, path(ctx), body?.(ctx)),
      };
    } catch (err) {
      if (err instanceof SsoziaError) {
        throw err.status >= 500 ? InvalidRequestError(err.message) : ValidationError(err.message);
      }
      throw err;
    }
  };
}

const id = z.string().regex(/^[A-Za-z0-9_-]{1,64}$/);
const enc = encodeURIComponent;

router.post("ssoziaUsers.status", admin(), async (ctx: APIContext) => {
  const { user } = ctx.state.auth;
  let connection: { ok: boolean; error?: string; users?: number; positions?: number };
  try {
    const [users, org] = await Promise.all([
      ssozia<unknown[]>(user.email ?? "", "GET", "/users"),
      ssozia<{ positions: unknown[] }>(user.email ?? "", "GET", "/org"),
    ]);
    connection = { ok: true, users: users.length, positions: org.positions.length };
  } catch (err) {
    connection = { ok: false, error: (err as Error).message };
  }
  ctx.body = {
    data: {
      version: VERSION,
      ssoziaUrl: ssoziaUrl(),
      clientId: process.env.OIDC_CLIENT_ID,
      actor: user.email,
      connection,
    },
  };
});

router.post("ssoziaUsers.users.list", admin(), forward("GET", () => "/users"));

const UserSchema = BaseSchema.extend({
  body: z.object({
    id: id.optional(),
    email: z.string().max(254),
    name: z.string().max(128),
    preferred_username: z.string().max(64),
    password: z.string().max(256).optional(),
    is_admin: z.boolean().optional(),
    disabled: z.boolean().optional(),
  }),
});
type UserReq = z.infer<typeof UserSchema>;

router.post(
  "ssoziaUsers.users.create",
  admin(),
  validate(UserSchema),
  forward<APIContext<UserReq>>("POST", () => "/users", (ctx) => ctx.input.body)
);

router.post(
  "ssoziaUsers.users.update",
  admin(),
  validate(UserSchema),
  forward<APIContext<UserReq>>(
    "POST",
    (ctx) => `/users/${enc(ctx.input.body.id ?? "")}`,
    (ctx) => ctx.input.body
  )
);

const PasswordSchema = BaseSchema.extend({
  body: z.object({ id, password: z.string().min(1).max(256) }),
});
router.post(
  "ssoziaUsers.users.password",
  admin(),
  validate(PasswordSchema),
  forward<APIContext<z.infer<typeof PasswordSchema>>>(
    "POST",
    (ctx) => `/users/${enc(ctx.input.body.id)}/password`,
    (ctx) => ({ password: ctx.input.body.password })
  )
);

const StatusSchema = BaseSchema.extend({
  body: z.object({ id, disabled: z.boolean() }),
});
/**
 * Enable / disable in ssozia, and suspend / activate the Outline account with
 * the same email, so a disabled user is also signed out of Outline (Outline
 * keeps its own session after the SSO sign-in).
 */
router.post(
  "ssoziaUsers.users.status",
  admin(),
  validate(StatusSchema),
  transaction(),
  async (ctx: APIContext<z.infer<typeof StatusSchema>>) => {
    const actor = ctx.state.auth.user;
    const { id: userId, disabled } = ctx.input.body;
    let data: { email: string } & Record<string, unknown>;
    try {
      data = await ssozia(actor.email ?? "", "POST", `/users/${enc(userId)}/status`, { disabled });
    } catch (err) {
      if (err instanceof SsoziaError) {
        throw err.status >= 500 ? InvalidRequestError(err.message) : ValidationError(err.message);
      }
      throw err;
    }
    let outline: "suspended" | "activated" | "unchanged" | "notFound" | "notAllowed" = "notFound";
    const member = await User.findOne({
      where: { teamId: actor.teamId, email: data.email.toLowerCase() },
      transaction: ctx.state.transaction,
    });
    if (member && member.id !== actor.id) {
      if (disabled && !member.isSuspended) {
        if (can(actor, "suspend", member)) {
          await member.updateWithCtx(ctx, { suspendedById: actor.id, suspendedAt: new Date() }, { name: "suspend" });
          outline = "suspended";
        } else {
          outline = "notAllowed";
        }
      } else if (!disabled && member.isSuspended) {
        if (can(actor, "activate", member)) {
          await member.updateWithCtx(ctx, { suspendedById: null, suspendedAt: null }, { name: "activate" });
          outline = "activated";
        } else {
          outline = "notAllowed";
        }
      } else {
        outline = "unchanged";
      }
    }
    ctx.body = { data: { ...data, outline } };
  }
);

router.post("ssoziaUsers.org.get", admin(), forward("GET", () => "/org"));

const PositionSchema = BaseSchema.extend({
  body: z.object({
    id: id.optional(),
    title: z.string().max(200),
    parent_id: id.nullish(),
    unit: z.string().max(200).optional(),
    description: z.string().max(2000).optional(),
    sort: z.number().int().optional(),
  }),
});
type PositionReq = z.infer<typeof PositionSchema>;

router.post(
  "ssoziaUsers.org.positionCreate",
  admin(),
  validate(PositionSchema),
  forward<APIContext<PositionReq>>("POST", () => "/org/positions", (ctx) => ctx.input.body)
);

router.post(
  "ssoziaUsers.org.positionUpdate",
  admin(),
  validate(PositionSchema),
  forward<APIContext<PositionReq>>(
    "POST",
    (ctx) => `/org/positions/${enc(ctx.input.body.id ?? "")}`,
    (ctx) => ctx.input.body
  )
);

const IdSchema = BaseSchema.extend({ body: z.object({ id }) });
router.post(
  "ssoziaUsers.org.positionDelete",
  admin(),
  validate(IdSchema),
  forward<APIContext<z.infer<typeof IdSchema>>>(
    "POST",
    (ctx) => `/org/positions/${enc(ctx.input.body.id)}/delete`
  )
);

const AssignSchema = BaseSchema.extend({
  body: z.object({ position_id: id, user_id: id, primary: z.boolean().optional() }),
});
type AssignReq = z.infer<typeof AssignSchema>;

router.post(
  "ssoziaUsers.org.assign",
  admin(),
  validate(AssignSchema),
  forward<APIContext<AssignReq>>("POST", () => "/org/assign", (ctx) => ctx.input.body)
);

router.post(
  "ssoziaUsers.org.unassign",
  admin(),
  validate(AssignSchema),
  forward<APIContext<AssignReq>>("POST", () => "/org/unassign", (ctx) => ctx.input.body)
);

export default router;
