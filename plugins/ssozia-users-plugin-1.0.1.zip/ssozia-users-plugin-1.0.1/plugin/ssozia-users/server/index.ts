// ssozia-users plugin v1.0.0
// On whenever Outline signs in through OIDC (ssozia), unless
// SSOZIA_USERS_ENABLED=false. Users and the chart live in ssozia itself.
import { PluginManager, Hook } from "@server/utils/PluginManager";
import config from "../plugin.json";

const enabled =
  process.env.SSOZIA_USERS_ENABLED !== "false" &&
  !!process.env.OIDC_ISSUER_URL &&
  !!process.env.OIDC_CLIENT_ID &&
  !!process.env.OIDC_CLIENT_SECRET;

if (enabled) {
  // oxlint-disable-next-line typescript/no-require-imports -- load only when enabled
  const router = require("./api/router").default;
  PluginManager.add({
    ...config,
    type: Hook.API,
    value: router,
  });
}
