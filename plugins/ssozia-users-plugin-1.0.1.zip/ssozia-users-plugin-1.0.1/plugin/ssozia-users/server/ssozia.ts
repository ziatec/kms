// ssozia-users plugin v1.0.0
// Client of the ssozia admin API (/admin/api/*), ssozia 0.2.0+. Outline's own
// OIDC client credentials authenticate Outline; the acting Outline admin is
// named in X-Ssozia-Actor and must be an active ssozia admin.

export class SsoziaError extends Error {
  status: number;

  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

export const ssoziaUrl = () =>
  (process.env.SSOZIA_ADMIN_URL || process.env.OIDC_ISSUER_URL || "").replace(/\/+$/, "");

const basicAuth = () => {
  const id = encodeURIComponent(process.env.OIDC_CLIENT_ID || "");
  const secret = encodeURIComponent(process.env.OIDC_CLIENT_SECRET || "");
  return `Basic ${Buffer.from(`${id}:${secret}`).toString("base64")}`;
};

/**
 * Calls ssozia and returns its `data`.
 *
 * @param actorEmail email of the Outline admin making the change.
 * @param method HTTP method.
 * @param path path under /admin/api, e.g. "/users".
 * @param body JSON body for POST.
 */
export async function ssozia<T>(
  actorEmail: string,
  method: "GET" | "POST",
  path: string,
  body?: unknown
): Promise<T> {
  const url = `${ssoziaUrl()}/admin/api${path}`;
  let res: Awaited<ReturnType<typeof fetch>>;
  try {
    res = await fetch(url, {
      method,
      headers: {
        Authorization: basicAuth(),
        "X-Ssozia-Actor": actorEmail,
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: method === "POST" ? JSON.stringify(body ?? {}) : undefined,
      signal: AbortSignal.timeout(15000),
    });
  } catch (err) {
    throw new SsoziaError(`ssozia در دسترس نیست (${url}): ${(err as Error).message}`, 502);
  }
  const text = await res.text();
  let json: { data?: T; error?: string } = {};
  try {
    json = text ? JSON.parse(text) : {};
  } catch {
    json = {};
  }
  if (!res.ok) {
    const message =
      res.status === 404
        ? "این نسخه از ssozia API مدیریت ندارد؛ ssozia را به نسخه ۰٫۲٫۰ یا بالاتر به‌روز کنید."
        : json.error || `ssozia: HTTP ${res.status}`;
    throw new SsoziaError(message, res.status);
  }
  return json.data as T;
}
