// ssozia-users plugin v1.0.0
type Props = { size?: number; color?: string };

export default function UsersIcon({ size = 24, color = "currentColor" }: Props) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M9 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm0 2c-3.3 0-6 1.8-6 4v2h12v-2c0-2.2-2.7-4-6-4Zm7.5-2a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm.5 2c-.6 0-1.2.1-1.7.2 1.1.9 1.7 2.1 1.7 3.8v2h4v-2c0-2.2-1.8-4-4-4Z"
        fill={color}
      />
    </svg>
  );
}
