// ssozia-users plugin v1.0.0
import { createLazyComponent } from "~/components/LazyLoad";
import { Hook, PluginManager } from "~/utils/PluginManager";
import config from "../plugin.json";
import { availability, BASE_PATH, checkAvailability } from "./api";
import Icon from "./Icon";

/** Admins only, and only where the server side of the plugin is enabled. */
const enabled = (_team: unknown, user: { isAdmin: boolean }) => {
  if (!user.isAdmin) {
    return false;
  }
  const available = availability.get();
  if (available === null) {
    void checkAvailability();
  }
  return available === true;
};

PluginManager.add([
  {
    ...config,
    name: "مدیریت کاربران",
    type: Hook.Settings,
    value: {
      group: "Workspace",
      icon: Icon,
      description: "کاربران ssozia و چارت سازمانی.",
      component: createLazyComponent(() => import("./Settings")),
      enabled: (team, user) => enabled(team, user),
    },
  },
  {
    ...config,
    type: Hook.Route,
    value: {
      path: `${BASE_PATH}/:tab?`,
      component: createLazyComponent(() => import("./App")),
      enabled,
    },
  },
  {
    ...config,
    type: Hook.SidebarLink,
    value: {
      label: "مدیریت کاربران",
      icon: Icon,
      path: BASE_PATH,
      enabled,
    },
  },
]);
