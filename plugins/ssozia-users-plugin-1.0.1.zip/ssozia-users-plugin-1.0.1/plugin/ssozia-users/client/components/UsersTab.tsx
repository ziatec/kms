// ssozia-users plugin v1.0.0
// Users of ssozia: create, edit, set password, enable/disable, positions.
import * as React from "react";
import { toast } from "sonner";
import Button from "~/components/Button";
import {
  api,
  errorMessage,
  faDate,
  faNum,
  type OrgChart,
  type SsoziaUser,
  type UserInput,
} from "../api";
import {
  Actions,
  Badge,
  Card,
  CardTitle,
  FormGrid,
  Hint,
  Input,
  Label,
  LinkButton,
  Muted,
  Select,
  Stat,
  Stats,
  Table,
  TableWrap,
} from "./ui";

type Props = {
  users: SsoziaUser[];
  org: OrgChart;
  creating: boolean;
  onCloseCreate: () => void;
  onChange: () => Promise<void>;
};

export default function UsersTab({ users, org, creating, onCloseCreate, onChange }: Props) {
  const [query, setQuery] = React.useState("");
  const [filter, setFilter] = React.useState<"all" | "active" | "disabled" | "admin">("all");
  const [editing, setEditing] = React.useState<string | null>(null);

  const q = query.trim().toLowerCase();
  const rows = users.filter((u) => {
    if (filter === "active" && u.disabled) {
      return false;
    }
    if (filter === "disabled" && !u.disabled) {
      return false;
    }
    if (filter === "admin" && !u.is_admin) {
      return false;
    }
    return (
      !q ||
      [u.name, u.preferred_username, u.email, ...u.positions.map((p) => p.title)]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  });

  const toggle = async (u: SsoziaUser) => {
    if (!window.confirm(u.disabled ? `«${u.name}» فعال شود؟` : `«${u.name}» غیرفعال شود؟ دیگر نمی‌تواند وارد شود.`)) {
      return;
    }
    try {
      const res = await api.setDisabled(u.id, !u.disabled);
      const outline = {
        suspended: "؛ حساب اوت‌لاین او هم تعلیق شد",
        activated: "؛ حساب اوت‌لاین او هم فعال شد",
        unchanged: "",
        notFound: "",
        notAllowed: "؛ وضعیت حساب اوت‌لاین تغییر نکرد",
      }[res.outline];
      toast.success((u.disabled ? "کاربر فعال شد" : "کاربر غیرفعال شد") + outline);
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  const setPassword = async (u: SsoziaUser) => {
    const p1 = window.prompt(`رمز عبور جدید برای «${u.name}» (حداقل ۸ نویسه):`, "");
    if (!p1) {
      return;
    }
    const p2 = window.prompt("تکرار رمز عبور:", "");
    if (p1 !== p2) {
      toast.error("دو رمز یکسان نیستند");
      return;
    }
    try {
      await api.setPassword(u.id, p1);
      toast.success("رمز عبور تعیین شد");
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <>
      <Stats>
        <Stat label="کاربران" value={faNum(users.length)} />
        <Stat label="فعال" value={faNum(users.filter((u) => !u.disabled).length)} />
        <Stat label="غیرفعال" value={faNum(users.filter((u) => u.disabled).length)} />
        <Stat label="مدیر" value={faNum(users.filter((u) => u.is_admin).length)} />
        <Stat label="بدون پست" value={faNum(users.filter((u) => !u.positions.length).length)} />
      </Stats>

      {creating && (
        <Card $accent>
          <CardTitle>کاربر جدید</CardTitle>
          <UserForm
            onCancel={onCloseCreate}
            onSaved={async () => {
              onCloseCreate();
              await onChange();
            }}
          />
        </Card>
      )}

      <Card>
        <CardTitle>
          کاربران ssozia
          <Input
            style={{ maxWidth: 260, marginInlineStart: "auto" }}
            placeholder="جستجو: نام، نام کاربری، ایمیل، پست…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <Select
            style={{ maxWidth: 140 }}
            value={filter}
            onChange={(e) => setFilter(e.target.value as typeof filter)}
          >
            <option value="all">همه</option>
            <option value="active">فعال</option>
            <option value="disabled">غیرفعال</option>
            <option value="admin">مدیر</option>
          </Select>
        </CardTitle>
        <TableWrap>
          <Table>
            <thead>
              <tr>
                <th>#</th>
                <th>نام</th>
                <th>نام کاربری</th>
                <th>ایمیل</th>
                <th>پست‌ها</th>
                <th>نقش</th>
                <th>وضعیت</th>
                <th>ثبت</th>
                <th>عملیات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((u, i) => (
                <React.Fragment key={u.id}>
                  <tr>
                    <td>{faNum(i + 1)}</td>
                    <td>{u.name}</td>
                    <td dir="auto">{u.preferred_username}</td>
                    <td className="mono">{u.email}</td>
                    <td style={{ whiteSpace: "normal" }}>
                      {u.positions.length
                        ? u.positions.map((p) => (
                            <Badge key={p.id} $tone={p.primary ? "accent" : "textTertiary"} style={{ marginInlineEnd: 4 }}>
                              {p.title}
                            </Badge>
                          ))
                        : "—"}
                    </td>
                    <td>{u.is_admin ? <Badge $tone="warning">مدیر</Badge> : "کاربر"}</td>
                    <td>
                      <Badge $tone={u.disabled ? "danger" : "success"}>{u.disabled ? "غیرفعال" : "فعال"}</Badge>
                    </td>
                    <td>{u.source === "file" ? <Muted>users.toml</Muted> : faDate(u.created_at)}</td>
                    <td>
                      {u.source === "file" ? (
                        <Muted title="در users.toml تعریف شده؛ از اینجا قابل تغییر نیست">فقط‌خواندنی</Muted>
                      ) : (
                        <Actions style={{ marginTop: 0, flexWrap: "nowrap" }}>
                          <LinkButton onClick={() => setEditing(editing === u.id ? null : u.id)}>ویرایش</LinkButton>
                          <LinkButton onClick={() => setPassword(u)}>رمز</LinkButton>
                          <LinkButton $danger={!u.disabled} onClick={() => toggle(u)}>
                            {u.disabled ? "فعال‌سازی" : "غیرفعال‌سازی"}
                          </LinkButton>
                        </Actions>
                      )}
                    </td>
                  </tr>
                  {editing === u.id && (
                    <tr className="details">
                      <td colSpan={9}>
                        <UserForm
                          user={u}
                          onCancel={() => setEditing(null)}
                          onSaved={async () => {
                            setEditing(null);
                            await onChange();
                          }}
                        />
                        <UserPositions user={u} org={org} onChange={onChange} />
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </Table>
        </TableWrap>
        {!rows.length && <Muted>موردی پیدا نشد.</Muted>}
      </Card>
    </>
  );
}

function UserForm({
  user,
  onSaved,
  onCancel,
}: {
  user?: SsoziaUser;
  onSaved: () => Promise<void>;
  onCancel: () => void;
}) {
  const [form, setForm] = React.useState({
    name: user?.name ?? "",
    preferred_username: user?.preferred_username ?? "",
    email: user?.email ?? "",
    password: "",
    password2: "",
    is_admin: user?.is_admin ?? false,
  });
  const [busy, setBusy] = React.useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user && form.password !== form.password2) {
      toast.error("دو رمز یکسان نیستند");
      return;
    }
    const input: UserInput = {
      name: form.name,
      preferred_username: form.preferred_username,
      email: form.email,
      is_admin: form.is_admin,
      ...(user ? {} : { password: form.password }),
    };
    setBusy(true);
    try {
      if (user) {
        await api.updateUser(user.id, input);
      } else {
        await api.createUser(input);
      }
      toast.success(user ? "کاربر ذخیره شد" : "کاربر ساخته شد");
      await onSaved();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={save}>
      <FormGrid>
        <Label>
          نام و نام خانوادگی *
          <Input value={form.name} onChange={set("name")} autoFocus required />
        </Label>
        <Label>
          نام کاربری * (فارسی یا انگلیسی)
          <Input dir="auto" value={form.preferred_username} onChange={set("preferred_username")} required />
          <Hint>۲ تا ۶۴ نویسه، بدون فاصله؛ «.»، «_»، «-» و نیم‌فاصله مجاز است.</Hint>
        </Label>
        <Label>
          ایمیل * (برای ورود به اوت‌لاین لازم است)
          <Input dir="ltr" type="email" value={form.email} onChange={set("email")} required />
        </Label>
        {!user && (
          <>
            <Label>
              رمز عبور *
              <Input dir="ltr" type="password" autoComplete="new-password" value={form.password} onChange={set("password")} required minLength={8} />
            </Label>
            <Label>
              تکرار رمز عبور *
              <Input dir="ltr" type="password" autoComplete="new-password" value={form.password2} onChange={set("password2")} required minLength={8} />
            </Label>
          </>
        )}
        <Label style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <input type="checkbox" checked={form.is_admin} onChange={set("is_admin")} />
          مدیر ssozia (مدیریت کاربران و سیستم‌های متصل)
        </Label>
      </FormGrid>
      <Actions>
        <Button type="submit" disabled={busy}>
          {busy ? "در حال ذخیره…" : "ذخیره"}
        </Button>
        <Button neutral onClick={onCancel}>
          انصراف
        </Button>
      </Actions>
    </form>
  );
}

function UserPositions({
  user,
  org,
  onChange,
}: {
  user: SsoziaUser;
  org: OrgChart;
  onChange: () => Promise<void>;
}) {
  const [positionId, setPositionId] = React.useState("");
  const [primary, setPrimary] = React.useState(user.positions.length === 0);
  const held = new Set(user.positions.map((p) => p.id));

  const run = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <div style={{ marginTop: 12 }}>
      <b>پست‌های سازمانی</b>
      <div style={{ margin: "6px 0" }}>
        {user.positions.length
          ? user.positions.map((p) => (
              <Badge key={p.id} $tone={p.primary ? "accent" : "textTertiary"} style={{ marginInlineEnd: 6 }}>
                {p.title}
                {p.primary ? " (اصلی)" : ""}{" "}
                {!p.primary && (
                  <LinkButton style={{ color: "inherit" }} title="پست اصلی" onClick={() => run(() => api.assign(p.id, user.id, true))}>
                    ★
                  </LinkButton>
                )}{" "}
                <LinkButton style={{ color: "inherit" }} title="برداشتن" onClick={() => run(() => api.unassign(p.id, user.id))}>
                  ×
                </LinkButton>
              </Badge>
            ))
          : <Muted>بدون پست</Muted>}
      </div>
      <Actions style={{ marginTop: 4 }}>
        <Select style={{ maxWidth: 320 }} value={positionId} onChange={(e) => setPositionId(e.target.value)}>
          <option value="">— انتخاب پست —</option>
          {org.positions
            .filter((p) => !held.has(p.id))
            .map((p) => (
              <option key={p.id} value={p.id}>
                {pathOf(org, p.id)}
              </option>
            ))}
        </Select>
        <label>
          <input type="checkbox" checked={primary} onChange={(e) => setPrimary(e.target.checked)} /> پست اصلی
        </label>
        <Button
          neutral
          disabled={!positionId}
          onClick={() =>
            run(async () => {
              await api.assign(positionId, user.id, primary);
              setPositionId("");
            })
          }
        >
          تخصیص پست
        </Button>
      </Actions>
    </div>
  );
}

/** "مدیرعامل › معاون فنی › کارشناس" */
export function pathOf(org: OrgChart, id: string) {
  const names: string[] = [];
  let cur = org.positions.find((p) => p.id === id);
  for (let i = 0; cur && i < 50; i++) {
    names.unshift(cur.title);
    const parent = cur.parent_id;
    cur = parent ? org.positions.find((p) => p.id === parent) : undefined;
  }
  return names.join(" › ");
}
