// ssozia-users plugin v1.0.0
// Organization chart: a tree of positions, each with its holders.
import * as React from "react";
import { toast } from "sonner";
import styled from "styled-components";
import { s } from "@shared/styles";
import Button from "~/components/Button";
import {
  api,
  errorMessage,
  faNum,
  type OrgChart,
  type Position,
  type PositionInput,
  type SsoziaUser,
} from "../api";
import { pathOf } from "./UsersTab";
import { Actions, Badge, Card, CardTitle, FormGrid, Input, Label, LinkButton, Muted, Select, Stat, Stats } from "./ui";

type Props = {
  users: SsoziaUser[];
  org: OrgChart;
  onChange: () => Promise<void>;
};

export default function OrgTab({ users, org, onChange }: Props) {
  const [adding, setAdding] = React.useState<string | null | undefined>(undefined);
  const roots = children(org, null);
  const holders = new Set(org.assignments.map((a) => a.user_id));

  return (
    <>
      <Stats>
        <Stat label="پست‌ها" value={faNum(org.positions.length)} />
        <Stat label="تخصیص‌ها" value={faNum(org.assignments.length)} />
        <Stat label="پست بدون متصدی" value={faNum(org.positions.filter((p) => !org.assignments.some((a) => a.position_id === p.id)).length)} />
        <Stat label="کاربر بدون پست" value={faNum(users.filter((u) => !holders.has(u.id)).length)} />
      </Stats>
      <Card>
        <CardTitle>
          چارت سازمانی
          <Button style={{ marginInlineStart: "auto" }} onClick={() => setAdding(null)}>
            پست ریشه
          </Button>
        </CardTitle>
        {adding === null && (
          <PositionForm
            org={org}
            parentId={null}
            onCancel={() => setAdding(undefined)}
            onSaved={async () => {
              setAdding(undefined);
              await onChange();
            }}
          />
        )}
        {roots.length ? (
          <Tree>
            {roots.map((p) => (
              <Node key={p.id} position={p} org={org} users={users} onChange={onChange} />
            ))}
          </Tree>
        ) : (
          <Muted>هنوز پستی تعریف نشده است. با «پست ریشه» شروع کنید (مثلاً مدیرعامل).</Muted>
        )}
      </Card>
    </>
  );
}

function children(org: OrgChart, parent: string | null) {
  return org.positions
    .filter((p) => (p.parent_id ?? null) === parent)
    .sort((a, b) => a.sort - b.sort || a.title.localeCompare(b.title, "fa"));
}

function Node({
  position,
  org,
  users,
  onChange,
}: {
  position: Position;
  org: OrgChart;
  users: SsoziaUser[];
  onChange: () => Promise<void>;
}) {
  const [mode, setMode] = React.useState<"none" | "edit" | "child">("none");
  const [userId, setUserId] = React.useState("");
  const [primary, setPrimary] = React.useState(false);
  const kids = children(org, position.id);
  const assigned = org.assignments.filter((a) => a.position_id === position.id);
  const assignedIds = new Set(assigned.map((a) => a.user_id));

  const run = async (fn: () => Promise<unknown>, done?: string) => {
    try {
      await fn();
      if (done) {
        toast.success(done);
      }
      await onChange();
    } catch (err) {
      toast.error(errorMessage(err));
    }
  };

  return (
    <li>
      <Box>
        <div>
          <b>{position.title}</b>
          {position.unit && <Muted> · {position.unit}</Muted>}
        </div>
        {position.description && <Muted style={{ display: "block", fontSize: 12 }}>{position.description}</Muted>}
        <div style={{ margin: "6px 0" }}>
          {assigned.length ? (
            assigned.map((a) => {
              const u = users.find((x) => x.id === a.user_id);
              return (
                <Badge key={a.user_id} $tone={u?.disabled ? "danger" : a.primary ? "accent" : "textTertiary"} style={{ marginInlineEnd: 6 }}>
                  {u ? u.name : a.user_id}
                  {a.primary ? " ★" : ""}{" "}
                  <LinkButton style={{ color: "inherit" }} title="برداشتن از این پست" onClick={() => run(() => api.unassign(position.id, a.user_id))}>
                    ×
                  </LinkButton>
                </Badge>
              );
            })
          ) : (
            <Muted>بدون متصدی</Muted>
          )}
        </div>
        <Actions style={{ marginTop: 4 }}>
          <Select style={{ maxWidth: 220 }} value={userId} onChange={(e) => setUserId(e.target.value)}>
            <option value="">— افزودن کاربر —</option>
            {users
              .filter((u) => !assignedIds.has(u.id))
              .map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.preferred_username})
                  {u.disabled ? " — غیرفعال" : ""}
                </option>
              ))}
          </Select>
          <label style={{ fontSize: 12 }}>
            <input type="checkbox" checked={primary} onChange={(e) => setPrimary(e.target.checked)} /> اصلی
          </label>
          <Button
            neutral
            disabled={!userId}
            onClick={() =>
              run(async () => {
                await api.assign(position.id, userId, primary);
                setUserId("");
              }, "کاربر به پست تخصیص یافت")
            }
          >
            تخصیص
          </Button>
          <LinkButton onClick={() => setMode(mode === "child" ? "none" : "child")}>زیرمجموعه</LinkButton>
          <LinkButton onClick={() => setMode(mode === "edit" ? "none" : "edit")}>ویرایش</LinkButton>
          <LinkButton
            $danger
            onClick={() => {
              if (window.confirm(`پست «${position.title}» حذف شود؟ تخصیص‌های آن هم حذف می‌شود.`)) {
                void run(() => api.deletePosition(position.id), "پست حذف شد");
              }
            }}
          >
            حذف
          </LinkButton>
        </Actions>
        {mode !== "none" && (
          <PositionForm
            org={org}
            position={mode === "edit" ? position : undefined}
            parentId={mode === "edit" ? position.parent_id : position.id}
            onCancel={() => setMode("none")}
            onSaved={async () => {
              setMode("none");
              await onChange();
            }}
          />
        )}
      </Box>
      {kids.length > 0 && (
        <Tree>
          {kids.map((k) => (
            <Node key={k.id} position={k} org={org} users={users} onChange={onChange} />
          ))}
        </Tree>
      )}
    </li>
  );
}

function PositionForm({
  org,
  position,
  parentId,
  onSaved,
  onCancel,
}: {
  org: OrgChart;
  position?: Position;
  parentId: string | null;
  onSaved: () => Promise<void>;
  onCancel: () => void;
}) {
  const [form, setForm] = React.useState<PositionInput>({
    title: position?.title ?? "",
    parent_id: parentId,
    unit: position?.unit ?? "",
    description: position?.description ?? "",
    sort: position?.sort ?? 0,
  });
  const [busy, setBusy] = React.useState(false);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (position) {
        await api.updatePosition(position.id, form);
      } else {
        await api.createPosition(form);
      }
      toast.success("پست ذخیره شد");
      await onSaved();
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={save} style={{ marginTop: 8 }}>
      <FormGrid>
        <Label>
          عنوان پست *
          <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} autoFocus required />
        </Label>
        <Label>
          واحد سازمانی
          <Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
        </Label>
        <Label>
          پست بالادست
          <Select
            value={form.parent_id ?? ""}
            onChange={(e) => setForm({ ...form, parent_id: e.target.value || null })}
          >
            <option value="">— ریشه —</option>
            {org.positions
              .filter((p) => p.id !== position?.id)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {pathOf(org, p.id)}
                </option>
              ))}
          </Select>
        </Label>
        <Label>
          ترتیب
          <Input
            type="number"
            dir="ltr"
            value={form.sort}
            onChange={(e) => setForm({ ...form, sort: Number(e.target.value) || 0 })}
          />
        </Label>
      </FormGrid>
      <Label>
        شرح وظایف
        <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      </Label>
      <Actions>
        <Button type="submit" disabled={busy}>
          ذخیره
        </Button>
        <Button neutral onClick={onCancel}>
          انصراف
        </Button>
      </Actions>
    </form>
  );
}

const Tree = styled.ul`
  list-style: none;
  margin: 0;
  padding: 0 22px 0 0;
  border-right: 2px solid ${s("divider")};

  & > li {
    position: relative;
    margin: 10px 0;
  }
  & > li::before {
    content: "";
    position: absolute;
    right: -22px;
    top: 22px;
    width: 18px;
    border-top: 2px solid ${s("divider")};
  }
`;

const Box = styled.div`
  padding: 10px 12px;
  border-radius: 8px;
  border: 1px solid ${s("divider")};
  background: ${s("backgroundSecondary")};
`;
