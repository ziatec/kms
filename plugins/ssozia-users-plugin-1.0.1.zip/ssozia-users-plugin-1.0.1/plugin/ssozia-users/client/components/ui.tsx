// ssozia-users plugin v1.0.0
import styled, { css } from "styled-components";
import { s } from "@shared/styles";
type Health = "none" | "active" | "warning" | "expired" | "revoked";

export const Page = styled.div`
  direction: rtl;
  text-align: right;
  font-size: 14px;
  padding-bottom: 48px;

  .mono {
    font-family: ${s("fontFamilyMono")};
    font-size: 12px;
    direction: ltr;
    unicode-bidi: isolate;
  }
`;

export const Card = styled.section<{ $accent?: boolean }>`
  padding: 14px 16px;
  margin: 12px 0;
  border-radius: 10px;
  background: ${s("background")};
  border: 1px solid ${(p) => (p.$accent ? p.theme.accent : p.theme.divider)};
`;

export const CardTitle = styled.h3`
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
  font-size: 15px;
  font-weight: 600;
  margin: 0 0 10px;
`;

export const Stats = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
  gap: 8px;
  margin: 12px 0;
`;

const StatBox = styled.div`
  padding: 8px 12px;
  border-radius: 8px;
  border: 1px solid ${s("divider")};
  background: ${s("backgroundSecondary")};
  display: flex;
  flex-direction: column;

  span {
    color: ${s("textTertiary")};
    font-size: 12px;
  }
  b {
    font-size: 16px;
  }
`;

export function Stat({ label, value, mono }: { label: string; value: string; mono?: boolean }) {
  return (
    <StatBox>
      <span>{label}</span>
      <b className={mono ? "mono" : undefined}>{value}</b>
    </StatBox>
  );
}

export const InfoGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  gap: 8px 16px;
`;

const FieldLabel = styled.div`
  color: ${s("textTertiary")};
  font-size: 12px;
`;

const FieldValue = styled.div`
  word-break: break-word;
  white-space: pre-wrap;
`;

export function Field({
  label,
  value,
  mono,
}: {
  label: string;
  value?: string | null;
  mono?: boolean;
}) {
  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <FieldValue className={mono && value ? "mono" : undefined}>{value || "—"}</FieldValue>
    </div>
  );
}

export const FormGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
  gap: 8px 12px;
  margin-bottom: 8px;
`;

export const Label = styled.label`
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 12px;
  color: ${s("textSecondary")};
`;

const inputCss = css`
  font: inherit;
  font-size: 14px;
  color: ${s("text")};
  background: ${s("background")};
  border: 1px solid ${s("inputBorder")};
  border-radius: 6px;
  padding: 6px 8px;
  width: 100%;
  box-sizing: border-box;

  &:disabled {
    opacity: 0.6;
  }
  &:focus {
    outline: none;
    border-color: ${s("accent")};
  }
`;

export const Input = styled.input`
  ${inputCss}
`;

export const Select = styled.select`
  ${inputCss}
`;

export const TextArea = styled.textarea<{ $mono?: boolean }>`
  ${inputCss}
  resize: vertical;
  ${(p) =>
    p.$mono &&
    css`
      direction: ltr;
      font-family: ${s("fontFamilyMono")};
      font-size: 12px;
    `}
`;

export const Hint = styled.span`
  color: ${s("textTertiary")};
  font-size: 12px;
`;

export const Actions = styled.div`
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  align-items: center;
  margin-top: 10px;
`;

export const LinkButton = styled.button<{ $danger?: boolean }>`
  border: 0;
  background: none;
  padding: 0;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  color: ${(p) => (p.$danger ? p.theme.danger : p.theme.accent)};

  &:disabled {
    opacity: 0.5;
    cursor: default;
  }
`;

export const Muted = styled.span`
  color: ${s("textTertiary")};
`;

export const Warn = styled.div`
  margin: 8px 0;
  padding: 8px 10px;
  border-radius: 6px;
  background: ${s("noticeWarningBackground")};
  color: ${s("noticeWarningText")};
`;

export const TableWrap = styled.div`
  overflow-x: auto;
  margin-top: 8px;
`;

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;

  th,
  td {
    padding: 7px 8px;
    border-bottom: 1px solid ${s("divider")};
    text-align: right;
    white-space: nowrap;
    vertical-align: top;
  }
  th {
    color: ${s("textTertiary")};
    font-weight: 500;
    position: sticky;
    top: 0;
    background: ${s("background")};
  }
  tbody tr.clickable {
    cursor: pointer;
  }
  tbody tr.clickable:hover {
    background: ${s("backgroundSecondary")};
  }
  tr.details td {
    white-space: normal;
    background: ${s("backgroundSecondary")};
  }
`;

const healthColor: Record<Health, "success" | "warning" | "danger" | "textTertiary"> = {
  none: "textTertiary",
  active: "success",
  warning: "warning",
  expired: "danger",
  revoked: "danger",
};

type Tone = "accent" | "success" | "warning" | "danger" | "textTertiary";

export const Badge = styled.span<{ $health?: Health; $tone?: Tone }>`
  display: inline-block;
  padding: 1px 8px;
  border-radius: 10px;
  font-size: 12px;
  color: ${(p) => p.theme.white};
  background: ${(p) =>
    p.theme[p.$tone ?? healthColor[p.$health ?? "none"]]};
`;

export const Timeline = styled.ol`
  list-style: none;
  margin: 0;
  padding: 0;

  li {
    position: relative;
    padding: 0 18px 12px 0;
    border-right: 2px solid ${s("divider")};
  }
  li::before {
    content: "";
    position: absolute;
    right: -6px;
    top: 4px;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: ${s("accent")};
  }
  .meta {
    color: ${s("textTertiary")};
    font-size: 12px;
  }
  .body {
    white-space: pre-wrap;
    color: ${s("textSecondary")};
  }
`;
