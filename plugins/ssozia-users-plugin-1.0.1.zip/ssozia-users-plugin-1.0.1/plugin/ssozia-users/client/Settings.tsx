// ssozia-users plugin v1.0.0
import * as React from "react";
import { Link } from "react-router-dom";
import Button from "~/components/Button";
import Heading from "~/components/Heading";
import Scene from "~/components/Scene";
import Text from "~/components/Text";
import { api, BASE_PATH, errorMessage, faNum, PLUGIN_VERSION, type Status } from "./api";
import { Card, CardTitle, Field, InfoGrid, Muted, Page, Warn } from "./components/ui";
import Icon from "./Icon";

export default function SsoziaUsersSettings() {
  const [status, setStatus] = React.useState<Status | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    api
      .status()
      .then(setStatus)
      .catch((err) => setError(errorMessage(err)));
  }, []);

  return (
    <Scene title="مدیریت کاربران" icon={<Icon />}>
      <Page dir="rtl">
        <Heading>مدیریت کاربران و چارت سازمانی</Heading>
        <Text as="p" type="secondary">
          کاربران ssozia (ورود یکپارچه) را تعریف، فعال یا غیرفعال کنید، رمز عبور
          بگذارید و در چارت سازمانی به پست‌ها تخصیص دهید. داده‌ها در خود ssozia
          نگه داشته می‌شود. نسخه افزونه: {faNum(PLUGIN_VERSION)}
        </Text>
        {error ? (
          <Warn>{error}</Warn>
        ) : !status ? (
          <Muted>در حال بارگذاری…</Muted>
        ) : (
          <Card>
            <CardTitle>
              اتصال به ssozia
              <Button as={Link} to={BASE_PATH}>
                باز کردن مدیریت کاربران
              </Button>
            </CardTitle>
            {!status.connection.ok && <Warn>{status.connection.error}</Warn>}
            <InfoGrid>
              <Field label="نشانی ssozia" value={status.ssoziaUrl} mono />
              <Field label="شناسه سیستم (client)" value={status.clientId} mono />
              <Field label="مدیر فعلی (X-Ssozia-Actor)" value={status.actor} mono />
              <Field
                label="کاربران / پست‌ها"
                value={
                  status.connection.ok
                    ? `${faNum(status.connection.users ?? 0)} / ${faNum(status.connection.positions ?? 0)}`
                    : "—"
                }
              />
            </InfoGrid>
            <Text as="p" type="tertiary" size="small">
              مدیر اوت‌لاین باید در ssozia هم مدیر (is_admin) و فعال باشد. ssozia
              نسخه ۰٫۲٫۰ یا بالاتر لازم است.
            </Text>
          </Card>
        )}
      </Page>
    </Scene>
  );
}
