// ssozia-users plugin v1.0.0
import { observable, runInAction } from "mobx";
import { client } from "~/utils/ApiClient";

export const PLUGIN_VERSION = "1.0.0";
export const BASE_PATH = "/ssozia-users";

export type SsoziaUser = {
  id: string;
  email: string;
  name: string;
  preferred_username: string;
  is_admin: boolean;
  disabled: boolean;
  /** "file" = users.toml (read-only), "managed" = created here. */
  source: "file" | "managed";
  created_at: number;
  updated_at: number;
  positions: { id: string; title: string; unit: string; primary: boolean }[];
};

export type Position = {
  id: string;
  title: string;
  parent_id: string | null;
  unit: string;
  description: string;
  sort: number;
};

export type Assignment = {
  position_id: string;
  user_id: string;
  primary: boolean;
  since: number;
};

export type OrgChart = { positions: Position[]; assignments: Assignment[] };

export type Status = {
  version: string;
  ssoziaUrl: string;
  clientId: string;
  actor: string;
  connection: { ok: boolean; error?: string; users?: number; positions?: number };
};

const post = async <R>(method: string, body: Record<string, unknown> = {}) =>
  (await client.post<{ data: R }>(`/ssoziaUsers.${method}`, body as never)).data;

/** Whether the server side of the plugin exists (null = not checked yet). */
export const availability = observable.box<boolean | null>(null);
let checking: Promise<void> | null = null;

export function checkAvailability() {
  if (!checking) {
    checking = post<Status>("status")
      .then(() => runInAction(() => availability.set(true)))
      .catch(() => runInAction(() => availability.set(false)));
  }
  return checking;
}

export type UserInput = {
  email: string;
  name: string;
  preferred_username: string;
  password?: string;
  is_admin: boolean;
  disabled?: boolean;
};

export type PositionInput = {
  title: string;
  parent_id: string | null;
  unit: string;
  description: string;
  sort: number;
};

export const api = {
  status: () => post<Status>("status"),
  users: () => post<SsoziaUser[]>("users.list"),
  createUser: (u: UserInput) => post<SsoziaUser>("users.create", u),
  updateUser: (id: string, u: UserInput) => post<SsoziaUser>("users.update", { id, ...u }),
  setPassword: (id: string, password: string) =>
    post<SsoziaUser>("users.password", { id, password }),
  /** `outline`: what happened to the Outline account with the same email. */
  setDisabled: (id: string, disabled: boolean) =>
    post<SsoziaUser & { outline: "suspended" | "activated" | "unchanged" | "notFound" | "notAllowed" }>(
      "users.status",
      { id, disabled }
    ),
  org: () => post<OrgChart>("org.get"),
  createPosition: (p: PositionInput) => post<Position>("org.positionCreate", p),
  updatePosition: (id: string, p: PositionInput) =>
    post<Position>("org.positionUpdate", { id, ...p }),
  deletePosition: (id: string) => post<unknown>("org.positionDelete", { id }),
  assign: (position_id: string, user_id: string, primary: boolean) =>
    post<unknown>("org.assign", { position_id, user_id, primary }),
  unassign: (position_id: string, user_id: string) =>
    post<unknown>("org.unassign", { position_id, user_id }),
};

export const errorMessage = (err: unknown) =>
  err instanceof Error ? err.message : "خطای ناشناخته";

const faDigits = "۰۱۲۳۴۵۶۷۸۹";
export const faNum = (n: number | string) =>
  String(n).replace(/\d/g, (d) => faDigits[Number(d)]);

const dateFmt = new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  timeZone: "Asia/Tehran",
});
export const faDate = (unix?: number) => (unix ? dateFmt.format(new Date(unix * 1000)) : "—");
