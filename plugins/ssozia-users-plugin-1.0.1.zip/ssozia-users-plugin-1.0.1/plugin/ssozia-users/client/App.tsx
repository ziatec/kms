// ssozia-users plugin v1.0.0
// Full page app at /ssozia-users and /ssozia-users/org.
import { observer } from "mobx-react";
import { PlusIcon } from "outline-icons";
import * as React from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import { Action } from "~/components/Actions";
import Button from "~/components/Button";
import Scene from "~/components/Scene";
import useCurrentUser from "~/hooks/useCurrentUser";
import { settingsPath } from "~/utils/routeHelpers";
import { api, BASE_PATH, errorMessage, faNum, PLUGIN_VERSION, type OrgChart, type SsoziaUser } from "./api";
import OrgTab from "./components/OrgTab";
import UsersTab from "./components/UsersTab";
import { Muted, Page, Warn } from "./components/ui";
import Icon from "./Icon";

function SsoziaUsersApp() {
  const user = useCurrentUser();
  const { tab } = useParams<{ tab?: string }>();
  const [users, setUsers] = React.useState<SsoziaUser[] | null>(null);
  const [org, setOrg] = React.useState<OrgChart | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [creating, setCreating] = React.useState(false);
  const isOrg = tab === "org";

  const load = React.useCallback(async () => {
    try {
      const [u, o] = await Promise.all([api.users(), api.org()]);
      setUsers(u);
      setOrg(o);
      setError(null);
    } catch (err) {
      setError(errorMessage(err));
      toast.error(errorMessage(err));
    }
  }, []);

  React.useEffect(() => {
    if (user.isAdmin) {
      void load();
    }
  }, [load, user.isAdmin]);

  if (!user.isAdmin) {
    return (
      <Scene title="مدیریت کاربران" icon={<Icon />}>
        <Page>
          <Muted>این بخش فقط برای مدیران سامانه است.</Muted>
        </Page>
      </Scene>
    );
  }

  return (
    <Scene
      wide
      icon={<Icon />}
      title={
        <>
          <Link to={BASE_PATH} style={{ fontWeight: isOrg ? 400 : 600 }}>
            کاربران
          </Link>
          &nbsp;|&nbsp;
          <Link to={`${BASE_PATH}/org`} style={{ fontWeight: isOrg ? 600 : 400 }}>
            چارت سازمانی
          </Link>
        </>
      }
      textTitle={isOrg ? "چارت سازمانی" : "مدیریت کاربران"}
      actions={
        <>
          {!isOrg && (
            <Action>
              <Button icon={<PlusIcon />} onClick={() => setCreating(true)}>
                کاربر جدید
              </Button>
            </Action>
          )}
          <Action>
            <Button neutral as={Link} to={settingsPath("ssozia-users")}>
              تنظیمات
            </Button>
          </Action>
        </>
      }
    >
      <Page dir="rtl" data-ssozia-users-version={PLUGIN_VERSION}>
        {error && <Warn>{error}</Warn>}
        {!users || !org ? (
          !error && <Muted>در حال بارگذاری…</Muted>
        ) : isOrg ? (
          <OrgTab users={users} org={org} onChange={load} />
        ) : (
          <UsersTab
            users={users}
            org={org}
            creating={creating}
            onCloseCreate={() => setCreating(false)}
            onChange={load}
          />
        )}
        <Muted style={{ fontSize: 12 }}>
          افزونه مدیریت کاربران ssozia · نسخه {faNum(PLUGIN_VERSION)} · داده‌ها در خود ssozia ذخیره می‌شوند
        </Muted>
      </Page>
    </Scene>
  );
}

export default observer(SsoziaUsersApp);
