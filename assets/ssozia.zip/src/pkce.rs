//! PKCE (RFC 7636), S256 only. "plain" is never accepted.

use sha2::{Digest, Sha256};

use crate::util::{b64url, ct_eq};

/// code_verifier: 43..=128 chars from the unreserved set.
pub fn is_valid_verifier(v: &str) -> bool {
    (43..=128).contains(&v.len())
        && v.bytes()
            .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'-' | b'.' | b'_' | b'~'))
}

/// code_challenge for S256 is the base64url (no padding) of a SHA-256
/// digest, which is always exactly 43 characters.
pub fn is_valid_challenge(c: &str) -> bool {
    c.len() == 43
        && c.bytes()
            .all(|b| b.is_ascii_alphanumeric() || matches!(b, b'-' | b'_'))
}

pub fn challenge_for(verifier: &str) -> String {
    b64url(&Sha256::digest(verifier.as_bytes()))
}

/// True when `verifier` hashes (S256) to `challenge`.
pub fn verify_s256(verifier: &str, challenge: &str) -> bool {
    if !is_valid_verifier(verifier) {
        return false;
    }
    ct_eq(challenge_for(verifier).as_bytes(), challenge.as_bytes())
}

#[cfg(test)]
mod tests {
    use super::*;

    // Test vector from RFC 7636, appendix B.
    const VERIFIER: &str = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";
    const CHALLENGE: &str = "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM";

    #[test]
    fn correct_verifier_is_accepted() {
        assert_eq!(challenge_for(VERIFIER), CHALLENGE);
        assert!(verify_s256(VERIFIER, CHALLENGE));
    }

    #[test]
    fn wrong_verifier_is_rejected() {
        assert!(!verify_s256("wrong-verifier-wrong-verifier-wrong-verifier-0123", CHALLENGE));
        assert!(!verify_s256(VERIFIER, "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cX"));
    }

    #[test]
    fn malformed_values_are_rejected() {
        assert!(!verify_s256("short", &challenge_for("short")));
        assert!(!is_valid_challenge("plain"));
        assert!(is_valid_challenge(CHALLENGE));
    }
}
