//! Rendering of the (plain HTML, Persian, RTL) login and message pages.

use crate::util::html_escape;

const LOGIN_TEMPLATE: &str = include_str!("../templates/login.html");
const MESSAGE_TEMPLATE: &str = include_str!("../templates/message.html");

/// Single-pass `{{key}}` substitution. Inserted values are never rescanned,
/// so user-controlled text cannot inject further placeholders.
fn fill(template: &str, vars: &[(&str, &str)]) -> String {
    let mut out = String::with_capacity(template.len() + 256);
    let mut rest = template;
    while let Some(start) = rest.find("{{") {
        out.push_str(&rest[..start]);
        let after = &rest[start + 2..];
        match after.find("}}") {
            Some(end) => {
                let key = &after[..end];
                if let Some((_, value)) = vars.iter().find(|(k, _)| *k == key) {
                    out.push_str(value);
                }
                rest = &after[end + 2..];
            }
            None => {
                out.push_str(&rest[start..]);
                rest = "";
                break;
            }
        }
    }
    out.push_str(rest);
    out
}

/// The login form. `authorize_query` is the original /authorize query
/// string, carried in a hidden field so the flow continues after login.
pub fn render_login(
    base_url: &str,
    authorize_query: &str,
    error: Option<&str>,
    email: &str,
) -> String {
    let action = html_escape(&format!("{base_url}/login"));
    let query = html_escape(authorize_query);
    let email = html_escape(email);
    let error_block = match error {
        Some(msg) => format!(r#"<p class="error" role="alert">{}</p>"#, html_escape(msg)),
        None => String::new(),
    };
    fill(
        LOGIN_TEMPLATE,
        &[
            ("action", &action),
            ("authorize_query", &query),
            ("email", &email),
            ("error_block", &error_block),
        ],
    )
}

/// A simple message page (logged out, errors). `detail` is an optional
/// technical hint shown left-to-right below the Persian text.
pub fn render_message(title: &str, message: &str, detail: Option<&str>) -> String {
    let detail_block = match detail {
        Some(d) => format!(r#"<p class="detail" dir="ltr">{}</p>"#, html_escape(d)),
        None => String::new(),
    };
    fill(
        MESSAGE_TEMPLATE,
        &[
            ("title", &html_escape(title)),
            ("message", &html_escape(message)),
            ("detail_block", &detail_block),
        ],
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn login_page_is_persian_rtl_with_absolute_action() {
        let html = render_login("http://sso.imamreza.ir", "client_id=outline&state=a\"b", None, "");
        assert!(html.contains(r#"<html dir="rtl" lang="fa">"#));
        assert!(html.contains(r#"action="http://sso.imamreza.ir/login""#));
        assert!(html.contains(r#"dir="ltr""#));
        // hidden field carries the (escaped) original query
        assert!(html.contains(r#"name="authorize_query" value="client_id=outline&amp;state=a&quot;b""#));
        assert!(!html.contains("{{"));
    }

    #[test]
    fn no_invisible_bidi_control_characters() {
        let bidi = [
            '\u{200E}', '\u{200F}', '\u{202A}', '\u{202B}', '\u{202C}', '\u{202D}', '\u{202E}',
            '\u{2066}', '\u{2067}', '\u{2068}', '\u{2069}', '\u{061C}',
        ];
        let pages = [
            LOGIN_TEMPLATE.to_string(),
            MESSAGE_TEMPLATE.to_string(),
            render_login("http://sso.imamreza.ir", "", Some("خطا"), ""),
        ];
        for page in pages {
            assert!(!page.chars().any(|c| bidi.contains(&c)));
        }
    }

    #[test]
    fn error_and_email_are_escaped_and_not_reinterpreted() {
        let html = render_login(
            "http://sso.imamreza.ir",
            "",
            Some("<b>x</b>"),
            "{{authorize_query}}\"><script>",
        );
        assert!(html.contains("&lt;b&gt;x&lt;/b&gt;"));
        assert!(!html.contains("<script>"));
        assert!(html.contains("{{authorize_query}}"));
    }
}
