//! Configuration from environment variables.
//! VERSION: ssozia 0.2.0 (2026-10-12) - ADMIN_API_CLIENTS

use std::path::PathBuf;

#[derive(Debug, Clone)]
pub struct Config {
    /// Public base URL, without a trailing slash. Also the OIDC issuer.
    pub public_base_url: String,
    pub bind_addr: String,
    pub users_file: PathBuf,
    pub clients_file: PathBuf,
    pub data_dir: PathBuf,
    pub cookie_secure: bool,
    pub cookie_name: String,
    /// Client ids allowed to call the admin API (in addition to clients with
    /// `admin_api = true`). ADMIN_API_CLIENTS, comma separated, default "outline".
    pub admin_api_clients: Vec<String>,
}

fn parse_bool(name: &str, value: &str) -> Result<bool, String> {
    match value.trim().to_ascii_lowercase().as_str() {
        "true" | "1" | "yes" | "on" => Ok(true),
        "false" | "0" | "no" | "off" | "" => Ok(false),
        other => Err(format!("{name}: expected true/false, got '{other}'")),
    }
}

impl Config {
    /// Where clients created in /admin are persisted.
    pub fn admin_clients_file(&self) -> PathBuf {
        self.data_dir.join("clients-admin.json")
    }

    /// Where users created through the admin API are persisted.
    pub fn admin_users_file(&self) -> PathBuf {
        self.data_dir.join("users-admin.json")
    }

    /// The organization chart.
    pub fn org_file(&self) -> PathBuf {
        self.data_dir.join("orgchart.json")
    }

    pub fn from_env() -> Result<Self, String> {
        Self::from_lookup(|k| std::env::var(k).ok())
    }

    pub fn from_lookup(get: impl Fn(&str) -> Option<String>) -> Result<Self, String> {
        let or = |name: &str, default: &str| get(name).unwrap_or_else(|| default.to_string());

        let public_base_url = or("PUBLIC_BASE_URL", "http://sso.imamreza.ir")
            .trim()
            .trim_end_matches('/')
            .to_string();
        if !(public_base_url.starts_with("http://") || public_base_url.starts_with("https://")) {
            return Err(format!(
                "PUBLIC_BASE_URL must start with http:// or https://, got '{public_base_url}'"
            ));
        }

        let cookie_name = or("COOKIE_NAME", "ssozia_session");
        if cookie_name.is_empty()
            || !cookie_name
                .bytes()
                .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'-')
        {
            return Err("COOKIE_NAME may only contain letters, digits, '_' and '-'".to_string());
        }

        Ok(Self {
            public_base_url,
            bind_addr: or("BIND_ADDR", "0.0.0.0:4000"),
            users_file: PathBuf::from(or("USERS_FILE", "./users.toml")),
            clients_file: PathBuf::from(or("CLIENTS_FILE", "./clients.toml")),
            data_dir: PathBuf::from(or("DATA_DIR", "./data")),
            cookie_secure: parse_bool("COOKIE_SECURE", &or("COOKIE_SECURE", "false"))?,
            cookie_name,
            admin_api_clients: or("ADMIN_API_CLIENTS", "outline")
                .split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn defaults() {
        let c = Config::from_lookup(|_| None).unwrap();
        assert_eq!(c.public_base_url, "http://sso.imamreza.ir");
        assert_eq!(c.bind_addr, "0.0.0.0:4000");
        assert_eq!(c.cookie_name, "ssozia_session");
        assert!(!c.cookie_secure);
        assert_eq!(c.admin_api_clients, vec!["outline".to_string()]);
    }

    #[test]
    fn trailing_slash_is_trimmed_and_bool_parsed() {
        let c = Config::from_lookup(|k| match k {
            "PUBLIC_BASE_URL" => Some("https://sso.example.org/".to_string()),
            "COOKIE_SECURE" => Some("true".to_string()),
            _ => None,
        })
        .unwrap();
        assert_eq!(c.public_base_url, "https://sso.example.org");
        assert!(c.cookie_secure);
    }

    #[test]
    fn bad_values_are_errors() {
        assert!(Config::from_lookup(|k| (k == "PUBLIC_BASE_URL").then(|| "sso".to_string())).is_err());
        assert!(Config::from_lookup(|k| (k == "COOKIE_SECURE").then(|| "maybe".to_string())).is_err());
    }
}
