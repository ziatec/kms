//! Authorization-code grant logic: issuing codes and redeeming them.

use crate::pkce;
use crate::stores::{AuthCode, Client, CodeStore};
use crate::util;

/// Authorization codes live for 60 seconds.
pub const CODE_TTL_SECS: i64 = 60;

/// Why a code could not be redeemed. The message is safe to show to the
/// client as `error_description` (the OAuth error code is always
/// `invalid_grant`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GrantError(pub &'static str);

/// Exact, byte-for-byte match against the registered list. No trailing
/// slash handling, no case folding, no normalisation of any kind.
pub fn redirect_uri_matches(registered: &[String], candidate: &str) -> bool {
    registered.iter().any(|r| r.as_bytes() == candidate.as_bytes())
}

/// Store a new code and return its value.
pub async fn issue_code(codes: &dyn CodeStore, grant: AuthCode) -> String {
    let code = util::random_token(32);
    codes.put(&code, grant).await;
    code
}

/// Build the grant record for a freshly authorised request.
pub fn new_grant(
    client_id: &str,
    redirect_uri: &str,
    user_id: &str,
    code_challenge: Option<String>,
    nonce: Option<String>,
    scope: &str,
    auth_time: i64,
    now: i64,
) -> AuthCode {
    AuthCode {
        client_id: client_id.to_string(),
        redirect_uri: redirect_uri.to_string(),
        user_id: user_id.to_string(),
        code_challenge,
        nonce,
        scope: scope.to_string(),
        auth_time,
        expires_at: now + CODE_TTL_SECS,
    }
}

/// Redeem a code. The code is consumed on the FIRST attempt, whether or not
/// the remaining checks pass, so it can never be tried twice.
pub async fn redeem_code(
    codes: &dyn CodeStore,
    code: &str,
    client: &Client,
    redirect_uri: &str,
    code_verifier: Option<&str>,
    now: i64,
) -> Result<AuthCode, GrantError> {
    let grant = codes
        .take(code)
        .await
        .ok_or(GrantError("authorization code is invalid or was already used"))?;

    if now >= grant.expires_at {
        return Err(GrantError("authorization code has expired"));
    }
    if grant.client_id != client.client_id {
        return Err(GrantError("authorization code was issued to another client"));
    }
    if grant.redirect_uri.as_bytes() != redirect_uri.as_bytes() {
        return Err(GrantError("redirect_uri does not match the authorization request"));
    }
    match &grant.code_challenge {
        Some(challenge) => {
            let verifier = code_verifier.ok_or(GrantError("code_verifier is required"))?;
            if !pkce::verify_s256(verifier, challenge) {
                return Err(GrantError("code_verifier does not match code_challenge"));
            }
        }
        None => {
            if client.require_pkce {
                return Err(GrantError("PKCE is required for this client"));
            }
        }
    }
    Ok(grant)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::test_support::*;
    use crate::stores::InMemoryCodeStore;

    fn sample(challenge: Option<String>, now: i64) -> AuthCode {
        new_grant(
            TEST_CLIENT_ID,
            TEST_REDIRECT_URI,
            "u_1",
            challenge,
            None,
            "openid profile email",
            now,
            now,
        )
    }

    #[tokio::test]
    async fn code_is_single_use() {
        let store = InMemoryCodeStore::new();
        let client = test_client();
        let (verifier, challenge) = pkce_pair();
        let now = util::now_secs();
        let code = issue_code(&store, sample(Some(challenge), now)).await;

        let first = redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&verifier), now).await;
        assert!(first.is_ok());
        let second = redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&verifier), now).await;
        assert!(second.is_err(), "second use of the same code must be rejected");
    }

    #[tokio::test]
    async fn code_expires_after_60_seconds() {
        let store = InMemoryCodeStore::new();
        let client = test_client();
        let (verifier, challenge) = pkce_pair();
        let now = util::now_secs();

        let code = issue_code(&store, sample(Some(challenge.clone()), now)).await;
        let ok = redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&verifier), now + 59).await;
        assert!(ok.is_ok(), "still valid at 59 seconds");

        let code = issue_code(&store, sample(Some(challenge), now)).await;
        let err = redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&verifier), now + 61)
            .await
            .unwrap_err();
        assert_eq!(err, GrantError("authorization code has expired"));
    }

    #[tokio::test]
    async fn wrong_or_missing_verifier_is_rejected_and_burns_the_code() {
        let store = InMemoryCodeStore::new();
        let client = test_client();
        let (verifier, challenge) = pkce_pair();
        let now = util::now_secs();

        let code = issue_code(&store, sample(Some(challenge.clone()), now)).await;
        let bad = "x".repeat(64);
        assert!(redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&bad), now).await.is_err());
        // the code is gone, even the right verifier no longer works
        assert!(redeem_code(&store, &code, &client, TEST_REDIRECT_URI, Some(&verifier), now).await.is_err());

        let code = issue_code(&store, sample(Some(challenge), now)).await;
        assert!(redeem_code(&store, &code, &client, TEST_REDIRECT_URI, None, now).await.is_err());
    }

    #[tokio::test]
    async fn redirect_uri_and_client_must_match_at_redemption() {
        let store = InMemoryCodeStore::new();
        let client = test_client();
        let (verifier, challenge) = pkce_pair();
        let now = util::now_secs();

        let code = issue_code(&store, sample(Some(challenge.clone()), now)).await;
        let other = format!("{TEST_REDIRECT_URI}/");
        assert!(redeem_code(&store, &code, &client, &other, Some(&verifier), now).await.is_err());

        let code = issue_code(&store, sample(Some(challenge), now)).await;
        let mut other_client = test_client();
        other_client.client_id = "someone-else".to_string();
        assert!(redeem_code(&store, &code, &other_client, TEST_REDIRECT_URI, Some(&verifier), now)
            .await
            .is_err());
    }

    #[test]
    fn redirect_uri_exact_match() {
        let registered = vec![TEST_REDIRECT_URI.to_string()];
        assert!(redirect_uri_matches(&registered, "http://kms.imamreza.ir/auth/oidc.callback"));
        // anything else fails, byte for byte
        for bad in [
            "http://kms.imamreza.ir/auth/oidc.callback/",
            "http://kms.imamreza.ir/auth/oidc.callback?x=1",
            "http://kms.imamreza.ir/auth/oidc.callback#f",
            "HTTP://kms.imamreza.ir/auth/oidc.callback",
            "http://KMS.imamreza.ir/auth/oidc.callback",
            "https://kms.imamreza.ir/auth/oidc.callback",
            "http://kms.imamreza.ir:80/auth/oidc.callback",
            "http://kms.imamreza.ir/auth/oidc.callback ",
            "http://kms.imamreza.ir/auth/oidc.callbac",
            "http://evil.example/auth/oidc.callback",
            "",
        ] {
            assert!(!redirect_uri_matches(&registered, bad), "must reject {bad:?}");
        }
    }
}
