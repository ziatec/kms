//! ssozia: a minimal OIDC provider (step 1).
//! VERSION: ssozia 0.2.0 (2026-10-12) - users and organization chart managed
//! through the admin API (used by the Outline plugin "ssozia-users").

mod admin_page;
mod auth;
mod cli;
mod config;
mod grant;
mod handlers;
mod keys;
mod login_page;
mod org;
mod pkce;
mod ratelimit;
mod state;
mod stores;
mod tokens;
mod util;

use std::net::SocketAddr;
use std::process::ExitCode;
use std::sync::Arc;

use clap::Parser;
use tracing_subscriber::EnvFilter;

use crate::cli::{Cli, Command};
use crate::config::Config;
use crate::keys::SigningKeys;
use crate::ratelimit::RateLimiter;
use crate::state::AppState;
use crate::stores::{InMemoryCodeStore, InMemorySessionStore};

#[tokio::main]
async fn main() -> ExitCode {
    let cli = Cli::parse();
    let result = match cli.command.unwrap_or(Command::Serve) {
        Command::HashPassword { password } => hash_password(password),
        Command::Serve => serve().await,
    };
    match result {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            ExitCode::FAILURE
        }
    }
}

/// `ssozia hash-password`: never logs the password or the hash input.
fn hash_password(password: Option<String>) -> Result<(), String> {
    let password = match password {
        Some(p) => p,
        None => cli::read_password_from_stdin()?,
    };
    if password.is_empty() {
        return Err("empty password".to_string());
    }
    println!("{}", auth::hash_password(&password)?);
    Ok(())
}

async fn serve() -> Result<(), String> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")))
        .init();

    let config = Config::from_env()?;
    let users = stores::load_users(&config.users_file, &config.admin_users_file())?;
    let org = org::OrgStore::load(&config.org_file())?;
    let clients = stores::load_clients(&config.clients_file, &config.admin_clients_file())?;
    let keys = SigningKeys::load_or_create(&config.data_dir)?;

    tracing::info!(
        issuer = %config.public_base_url,
        kid = %keys.kid,
        cookie_secure = config.cookie_secure,
        "ssozia starting"
    );

    let bind_addr = config.bind_addr.clone();
    let state = AppState {
        config: Arc::new(config),
        users: Arc::new(users),
        clients: Arc::new(clients),
        codes: Arc::new(InMemoryCodeStore::new()),
        sessions: Arc::new(InMemorySessionStore::new()),
        org: Arc::new(org),
        keys: Arc::new(keys),
        limiter: Arc::new(RateLimiter::standard()),
        csrf_secret: Arc::new(util::random_token(32)),
    };

    let app = handlers::router(state);
    let listener = tokio::net::TcpListener::bind(&bind_addr)
        .await
        .map_err(|e| format!("cannot bind {bind_addr}: {e}"))?;
    tracing::info!(addr = %bind_addr, "listening");

    axum::serve(
        listener,
        app.into_make_service_with_connect_info::<SocketAddr>(),
    )
    .with_graceful_shutdown(shutdown_signal())
    .await
    .map_err(|e| format!("server error: {e}"))
}

async fn shutdown_signal() {
    let ctrl_c = async {
        let _ = tokio::signal::ctrl_c().await;
    };

    #[cfg(unix)]
    let terminate = async {
        match tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()) {
            Ok(mut s) => {
                s.recv().await;
            }
            Err(_) => std::future::pending::<()>().await,
        }
    };
    #[cfg(not(unix))]
    let terminate = std::future::pending::<()>();

    tokio::select! {
        _ = ctrl_c => {},
        _ = terminate => {},
    }
    tracing::info!("shutting down");
}
