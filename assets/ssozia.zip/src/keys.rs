//! RSA signing key: generated on first start, persisted as PEM, stable kid.

use std::fs;
use std::path::Path;

use jsonwebtoken::{Algorithm, DecodingKey, EncodingKey, Header};
use rsa::pkcs1::{DecodeRsaPrivateKey, EncodeRsaPrivateKey, EncodeRsaPublicKey};
use rsa::pkcs8::{DecodePrivateKey, LineEnding};
use rsa::traits::PublicKeyParts;
use rsa::{RsaPrivateKey, RsaPublicKey};
use serde::Serialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};

use crate::util::b64url;

const KEY_FILE: &str = "signing-key.pem";
const KEY_BITS: usize = 2048;

pub struct SigningKeys {
    pub kid: String,
    encoding: EncodingKey,
    decoding: DecodingKey,
    jwks: Value,
}

impl SigningKeys {
    /// Load `<dir>/signing-key.pem`, or generate and persist it.
    /// The key itself is never logged.
    pub fn load_or_create(dir: &Path) -> Result<Self, String> {
        let path = dir.join(KEY_FILE);
        if path.exists() {
            let pem = fs::read_to_string(&path)
                .map_err(|e| format!("cannot read {}: {e}", path.display()))?;
            let key = RsaPrivateKey::from_pkcs1_pem(&pem)
                .or_else(|_| RsaPrivateKey::from_pkcs8_pem(&pem))
                .map_err(|_| format!("{} is not a valid RSA private key PEM", path.display()))?;
            return Self::from_private_key(&key);
        }

        tracing::info!("no signing key found, generating a new RSA-{KEY_BITS} key");
        let key = RsaPrivateKey::new(&mut rand::rngs::OsRng, KEY_BITS)
            .map_err(|e| format!("RSA key generation failed: {e}"))?;
        let pem = key
            .to_pkcs1_pem(LineEnding::LF)
            .map_err(|e| format!("cannot encode private key: {e}"))?;
        fs::create_dir_all(dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
        write_private_file(&path, pem.as_bytes())
            .map_err(|e| format!("cannot write {}: {e}", path.display()))?;
        Self::from_private_key(&key)
    }

    pub fn from_private_key(key: &RsaPrivateKey) -> Result<Self, String> {
        let pem = key
            .to_pkcs1_pem(LineEnding::LF)
            .map_err(|e| format!("cannot encode private key: {e}"))?;
        let encoding = EncodingKey::from_rsa_pem(pem.as_bytes())
            .map_err(|e| format!("cannot load signing key: {e}"))?;

        let public = RsaPublicKey::from(key);
        let der = public
            .to_pkcs1_der()
            .map_err(|e| format!("cannot encode public key: {e}"))?;
        let kid: String = b64url(&Sha256::digest(der.as_bytes())).chars().take(16).collect();

        let n = b64url(&public.n().to_bytes_be());
        let e = b64url(&public.e().to_bytes_be());
        let decoding = DecodingKey::from_rsa_components(&n, &e)
            .map_err(|e| format!("cannot build verification key: {e}"))?;
        let jwks = json!({
            "keys": [{
                "kty": "RSA",
                "use": "sig",
                "alg": "RS256",
                "kid": kid,
                "n": n,
                "e": e,
            }]
        });

        Ok(Self {
            kid,
            encoding,
            decoding,
            jwks,
        })
    }

    /// Sign claims as an RS256 JWT with our `kid` in the header.
    pub fn sign<T: Serialize>(&self, claims: &T) -> Result<String, String> {
        let mut header = Header::new(Algorithm::RS256);
        header.kid = Some(self.kid.clone());
        jsonwebtoken::encode(&header, claims, &self.encoding).map_err(|e| e.to_string())
    }

    pub fn decoding_key(&self) -> &DecodingKey {
        &self.decoding
    }

    pub fn jwks(&self) -> &Value {
        &self.jwks
    }
}

#[cfg(unix)]
fn write_private_file(path: &Path, data: &[u8]) -> std::io::Result<()> {
    use std::io::Write;
    use std::os::unix::fs::OpenOptionsExt;
    let mut f = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .mode(0o600)
        .open(path)?;
    f.write_all(data)
}

#[cfg(not(unix))]
fn write_private_file(path: &Path, data: &[u8]) -> std::io::Result<()> {
    fs::write(path, data)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::test_support;

    #[test]
    fn kid_is_stable_for_the_same_key() {
        let key = test_support::test_rsa_key();
        let a = SigningKeys::from_private_key(key).unwrap();
        let b = SigningKeys::from_private_key(key).unwrap();
        assert_eq!(a.kid, b.kid);
        assert_eq!(a.kid.len(), 16);
    }

    #[test]
    fn key_is_persisted_and_reloaded() {
        let dir = std::env::temp_dir().join(format!("ssozia-keytest-{}", crate::util::random_token(8)));
        let first = SigningKeys::load_or_create(&dir).unwrap();
        let second = SigningKeys::load_or_create(&dir).unwrap();
        assert_eq!(first.kid, second.kid);
        let _ = fs::remove_dir_all(&dir);
    }
}
