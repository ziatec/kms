//! Small shared helpers: time, random tokens, query handling, cookies and
//! HTTP response builders.

use std::collections::HashMap;
use std::time::{SystemTime, UNIX_EPOCH};

use axum::body::Body;
use axum::http::{header, HeaderMap, HeaderValue, StatusCode};
use axum::response::{IntoResponse, Response};
use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use rand::RngCore;


pub fn now_secs() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0)
}

/// `num_bytes` of OS randomness, base64url (no padding) encoded.
pub fn random_token(num_bytes: usize) -> String {
    let mut buf = vec![0u8; num_bytes];
    rand::rngs::OsRng.fill_bytes(&mut buf);
    URL_SAFE_NO_PAD.encode(buf)
}

/// `num_bytes` of OS randomness as lowercase hex (like `openssl rand -hex`).
pub fn random_hex(num_bytes: usize) -> String {
    let mut buf = vec![0u8; num_bytes];
    rand::rngs::OsRng.fill_bytes(&mut buf);
    buf.iter().map(|b| format!("{b:02x}")).collect()
}

pub fn b64url(data: &[u8]) -> String {
    URL_SAFE_NO_PAD.encode(data)
}

/// Constant-time equality for secrets and challenges.
pub fn ct_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    let mut diff = 0u8;
    for (x, y) in a.iter().zip(b.iter()) {
        diff |= x ^ y;
    }
    diff == 0
}

pub fn html_escape(s: &str) -> String {
    let mut out = String::with_capacity(s.len() + 8);
    for c in s.chars() {
        match c {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            '\'' => out.push_str("&#39;"),
            _ => out.push(c),
        }
    }
    out
}

/// Parse a query string / form body. First occurrence of a key wins.
pub fn parse_query(raw: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    for (k, v) in form_urlencoded::parse(raw.as_bytes()) {
        map.entry(k.into_owned()).or_insert_with(|| v.into_owned());
    }
    map
}

/// Re-encode a query string. Used so that whatever travels through the
/// login form's hidden field is always safely encoded again before it is
/// placed into a Location header.
pub fn normalize_query(raw: &str) -> String {
    let mut ser = form_urlencoded::Serializer::new(String::new());
    ser.extend_pairs(form_urlencoded::parse(raw.as_bytes()));
    ser.finish()
}

pub fn encode_query(pairs: &[(&str, &str)]) -> String {
    let mut ser = form_urlencoded::Serializer::new(String::new());
    for (k, v) in pairs {
        ser.append_pair(k, v);
    }
    ser.finish()
}

/// Append query parameters to a URL string WITHOUT re-parsing or normalising
/// the URL itself (so "http://kms.imamreza.ir" stays exactly that).
pub fn append_query(base: &str, pairs: &[(&str, &str)]) -> String {
    if pairs.is_empty() {
        return base.to_string();
    }
    let sep = if base.contains('?') { '&' } else { '?' };
    format!("{base}{sep}{}", encode_query(pairs))
}

pub fn get_cookie(headers: &HeaderMap, name: &str) -> Option<String> {
    for value in headers.get_all(header::COOKIE) {
        let Ok(s) = value.to_str() else { continue };
        for part in s.split(';') {
            if let Some((k, v)) = part.trim().split_once('=') {
                if k == name {
                    return Some(v.to_string());
                }
            }
        }
    }
    None
}

/// Build a Set-Cookie value for the session cookie.
pub fn cookie_header(name: &str, value: &str, secure: bool, max_age: i64) -> String {
    let mut c = format!("{name}={value}; Path=/; HttpOnly; SameSite=Lax; Max-Age={max_age}");
    if secure {
        c.push_str("; Secure");
    }
    c
}

fn add_cookie(resp: &mut Response, cookie: Option<&str>) {
    if let Some(c) = cookie {
        if let Ok(v) = HeaderValue::from_str(c) {
            resp.headers_mut().append(header::SET_COOKIE, v);
        }
    }
}

/// 302 Found with an optional Set-Cookie.
pub fn redirect(location: &str, cookie: Option<&str>) -> Response {
    let Ok(loc) = HeaderValue::from_str(location) else {
        return (StatusCode::INTERNAL_SERVER_ERROR, "invalid redirect target").into_response();
    };
    let mut resp = Response::new(Body::empty());
    *resp.status_mut() = StatusCode::FOUND;
    resp.headers_mut().insert(header::LOCATION, loc);
    resp.headers_mut()
        .insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    add_cookie(&mut resp, cookie);
    resp
}

pub fn html_response(status: StatusCode, body: String, cookie: Option<&str>) -> Response {
    let mut resp = Response::new(Body::from(body));
    *resp.status_mut() = status;
    let h = resp.headers_mut();
    h.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("text/html; charset=utf-8"),
    );
    h.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    h.insert(header::X_FRAME_OPTIONS, HeaderValue::from_static("DENY"));
    h.insert(
        header::CONTENT_SECURITY_POLICY,
        HeaderValue::from_static(
            "default-src 'none'; style-src 'unsafe-inline'; frame-ancestors 'none'",
        ),
    );
    h.insert(
        header::REFERRER_POLICY,
        HeaderValue::from_static("no-referrer"),
    );
    add_cookie(&mut resp, cookie);
    resp
}

pub fn json_response(status: StatusCode, value: &serde_json::Value) -> Response {
    let mut resp = Response::new(Body::from(value.to_string()));
    *resp.status_mut() = status;
    let h = resp.headers_mut();
    h.insert(
        header::CONTENT_TYPE,
        HeaderValue::from_static("application/json"),
    );
    h.insert(header::CACHE_CONTROL, HeaderValue::from_static("no-store"));
    h.insert(header::PRAGMA, HeaderValue::from_static("no-cache"));
    resp
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn append_query_keeps_base_untouched() {
        assert_eq!(
            append_query("http://kms.imamreza.ir", &[("state", "a b")]),
            "http://kms.imamreza.ir?state=a+b"
        );
        assert_eq!(
            append_query("http://x/cb?a=1", &[("code", "c")]),
            "http://x/cb?a=1&code=c"
        );
        assert_eq!(append_query("http://x/cb", &[]), "http://x/cb");
    }

    #[test]
    fn query_roundtrip() {
        let q = normalize_query("a=1&b=%20x&a=2");
        let m = parse_query(&q);
        assert_eq!(m.get("a").map(String::as_str), Some("1"));
        assert_eq!(m.get("b").map(String::as_str), Some(" x"));
    }

    #[test]
    fn cookie_parsing() {
        let mut h = HeaderMap::new();
        h.insert(
            header::COOKIE,
            HeaderValue::from_static("a=1; ssozia_session=abc; b=2"),
        );
        assert_eq!(get_cookie(&h, "ssozia_session").as_deref(), Some("abc"));
        assert_eq!(get_cookie(&h, "nope"), None);
    }

    #[test]
    fn ct_eq_works() {
        assert!(ct_eq(b"abc", b"abc"));
        assert!(!ct_eq(b"abc", b"abd"));
        assert!(!ct_eq(b"abc", b"ab"));
    }

    #[test]
    fn escape_html() {
        assert_eq!(
            html_escape("<a href=\"x\">&'"),
            "&lt;a href=&quot;x&quot;&gt;&amp;&#39;"
        );
    }
}
