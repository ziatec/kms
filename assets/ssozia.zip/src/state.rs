//! Shared application state. Handlers depend on the store TRAITS only.
//! VERSION: ssozia 0.2.0 (2026-10-12) - organization chart

use std::sync::Arc;

use crate::config::Config;
use crate::keys::SigningKeys;
use crate::org::OrgStore;
use crate::ratelimit::RateLimiter;
use crate::stores::{ClientStore, CodeStore, SessionStore, UserStore};

#[derive(Clone)]
pub struct AppState {
    pub config: Arc<Config>,
    pub users: Arc<dyn UserStore>,
    pub clients: Arc<dyn ClientStore>,
    pub codes: Arc<dyn CodeStore>,
    pub sessions: Arc<dyn SessionStore>,
    pub org: Arc<OrgStore>,
    pub keys: Arc<SigningKeys>,
    pub limiter: Arc<RateLimiter>,
    /// Random per-process secret used to derive CSRF tokens for /admin.
    pub csrf_secret: Arc<String>,
}

impl AppState {
    /// Public base URL (== issuer), no trailing slash.
    pub fn base_url(&self) -> &str {
        &self.config.public_base_url
    }
}

/// Fixtures shared by unit tests across modules.
#[cfg(test)]
pub mod test_support {
    use std::path::PathBuf;
    use std::sync::{Arc, OnceLock};

    use axum::body::Body;
    use axum::http::{HeaderMap, Request, StatusCode};
    use axum::Router;
    use http_body_util::BodyExt;
    use rsa::RsaPrivateKey;
    use tower::ServiceExt;

    use super::AppState;
    use crate::auth;
    use crate::config::Config;
    use crate::keys::SigningKeys;
    use crate::org::{OrgChart, OrgStore};
    use crate::pkce;
    use crate::ratelimit::RateLimiter;
    use crate::stores::*;

    pub const BASE: &str = "http://sso.imamreza.ir";
    pub const TEST_EMAIL: &str = "admin@example.com";
    pub const TEST_PASSWORD: &str = "correct horse battery staple";
    pub const TEST_CLIENT_ID: &str = "outline";
    pub const TEST_CLIENT_SECRET: &str = "0123456789abcdef0123456789abcdef";
    pub const TEST_REDIRECT_URI: &str = "http://kms.imamreza.ir/auth/oidc.callback";
    pub const TEST_POST_LOGOUT_URI: &str = "http://kms.imamreza.ir";
    pub const TEST_VERIFIER: &str = "dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk";

    struct Fixture {
        user_hash: String,
        client_hash: String,
        key: RsaPrivateKey,
    }

    fn fixture() -> &'static Fixture {
        static F: OnceLock<Fixture> = OnceLock::new();
        F.get_or_init(|| Fixture {
            user_hash: auth::hash_password(TEST_PASSWORD).unwrap(),
            client_hash: auth::hash_password(TEST_CLIENT_SECRET).unwrap(),
            key: RsaPrivateKey::new(&mut rand::rngs::OsRng, 2048).unwrap(),
        })
    }

    pub fn test_rsa_key() -> &'static RsaPrivateKey {
        &fixture().key
    }

    pub fn test_user() -> User {
        User {
            id: "u_1".to_string(),
            email: TEST_EMAIL.to_string(),
            name: "Admin".to_string(),
            preferred_username: "admin".to_string(),
            password_hash: fixture().user_hash.clone(),
            is_admin: true,
            disabled: false,
            created_at: 0,
            updated_at: 0,
            dynamic: false,
        }
    }

    pub fn test_client() -> Client {
        Client {
            client_id: TEST_CLIENT_ID.to_string(),
            name: "Outline".to_string(),
            client_secret_hash: fixture().client_hash.clone(),
            redirect_uris: vec![TEST_REDIRECT_URI.to_string()],
            post_logout_redirect_uris: vec![TEST_POST_LOGOUT_URI.to_string()],
            require_pkce: true,
            admin_api: false,
            dynamic: false,
        }
    }

    /// (verifier, challenge) using the RFC 7636 example values.
    pub fn pkce_pair() -> (String, String) {
        (TEST_VERIFIER.to_string(), pkce::challenge_for(TEST_VERIFIER))
    }

    pub fn test_state() -> AppState {
        test_state_with_client(test_client())
    }

    pub fn test_state_with_client(client: Client) -> AppState {
        test_state_custom(vec![test_user()], client)
    }

    pub fn test_state_custom(users: Vec<User>, client: Client) -> AppState {
        let config = Config {
            public_base_url: BASE.to_string(),
            bind_addr: "127.0.0.1:0".to_string(),
            users_file: PathBuf::from("unused"),
            clients_file: PathBuf::from("unused"),
            data_dir: PathBuf::from("unused"),
            cookie_secure: false,
            cookie_name: "ssozia_session".to_string(),
            admin_api_clients: vec![TEST_CLIENT_ID.to_string()],
        };
        AppState {
            config: Arc::new(config),
            users: Arc::new(InMemoryUserStore::new(users).unwrap()),
            clients: Arc::new(InMemoryClientStore::new(vec![client]).unwrap()),
            codes: Arc::new(InMemoryCodeStore::new()),
            sessions: Arc::new(InMemorySessionStore::new()),
            org: Arc::new(OrgStore::new(OrgChart::default())),
            keys: Arc::new(SigningKeys::from_private_key(test_rsa_key()).unwrap()),
            limiter: Arc::new(RateLimiter::standard()),
            csrf_secret: Arc::new("test-csrf-secret".to_string()),
        }
    }

    /// Call the router in-process and collect the whole response.
    pub async fn send(app: &Router, req: Request<Body>) -> (StatusCode, HeaderMap, Vec<u8>) {
        let resp = app.clone().oneshot(req).await.unwrap();
        let status = resp.status();
        let headers = resp.headers().clone();
        let body = resp.into_body().collect().await.unwrap().to_bytes().to_vec();
        (status, headers, body)
    }
}
