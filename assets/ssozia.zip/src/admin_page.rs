//! HTML for the /admin pages (Persian, RTL, no JavaScript).

use crate::stores::Client;
use crate::util::html_escape;

const STYLE: &str = "\
body{margin:0;background:#f3f4f6;color:#111827;font-family:Tahoma,'Segoe UI',system-ui,sans-serif}\
.wrap{max-width:920px;margin:0 auto;padding:20px 16px 48px}\
.card{background:#fff;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.08);padding:20px 22px;margin:16px 0}\
h1{font-size:22px;margin:8px 0}h2{font-size:17px;margin:0 0 12px}\
label{display:block;margin:12px 0 6px;font-size:14px}\
input[type=text],textarea{width:100%;box-sizing:border-box;padding:9px;font-size:14px;border:1px solid #d1d5db;border-radius:6px;font-family:inherit}\
textarea{min-height:64px}\
.code{font-family:ui-monospace,Menlo,Consolas,monospace;direction:ltr;text-align:left}\
button{padding:9px 16px;font-size:14px;color:#fff;background:#2563eb;border:0;border-radius:6px;cursor:pointer}\
button.danger{background:#b91c1c}button.warn{background:#b45309}\
table{width:100%;border-collapse:collapse;font-size:14px}\
th,td{padding:8px;border-bottom:1px solid #e5e7eb;text-align:right;vertical-align:top}\
.ltr{direction:ltr;text-align:left;unicode-bidi:plaintext;word-break:break-all}\
.badge{display:inline-block;padding:2px 8px;border-radius:99px;font-size:12px;background:#e5e7eb}\
.flash{padding:10px 12px;border-radius:6px;margin:12px 0;font-size:14px}\
.flash.ok{background:#ecfdf5;color:#065f46;border:1px solid #a7f3d0}\
.flash.err{background:#fef2f2;color:#991b1b;border:1px solid #fecaca}\
.secret{background:#111827;color:#f9fafb;padding:12px;border-radius:6px;font-size:15px;direction:ltr;text-align:left;word-break:break-all}\
.hint{color:#6b7280;font-size:13px}\
form.inline{display:inline;margin:0}";

fn layout(title: &str, body: &str) -> String {
    let mut s = String::with_capacity(body.len() + 2048);
    s.push_str("<!DOCTYPE html>\n<html dir=\"rtl\" lang=\"fa\">\n<head>\n<meta charset=\"utf-8\">\n");
    s.push_str("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>");
    s.push_str(&html_escape(title));
    s.push_str("</title>\n<style>");
    s.push_str(STYLE);
    s.push_str("</style>\n</head>\n<body>\n<div class=\"wrap\">\n");
    s.push_str(body);
    s.push_str("\n</div>\n</body>\n</html>\n");
    s
}

/// Values shown in the "new connection" form.
#[derive(Debug, Clone, Default)]
pub struct Prefill {
    pub name: String,
    pub client_id: String,
    /// One URI per line.
    pub redirect_uris: String,
    /// One URI per line.
    pub post_logout_redirect_uris: String,
    pub require_pkce: bool,
}

impl Prefill {
    pub fn blank() -> Self {
        Self {
            require_pkce: true,
            ..Self::default()
        }
    }

    /// Ready-made values for connecting Outline (the topology of this
    /// project). The person can still edit every field.
    pub fn outline() -> Self {
        Self {
            name: "Outline".to_string(),
            client_id: "outline".to_string(),
            redirect_uris: "http://kms.imamreza.ir/auth/oidc.callback".to_string(),
            post_logout_redirect_uris: "http://kms.imamreza.ir".to_string(),
            require_pkce: true,
        }
    }
}

pub enum Flash<'a> {
    Ok(&'a str),
    Err(&'a str),
}

fn csrf_input(csrf: &str) -> String {
    format!(r#"<input type="hidden" name="csrf" value="{}">"#, html_escape(csrf))
}

pub fn render_dashboard(
    base_url: &str,
    admin_name: &str,
    csrf: &str,
    clients: &[Client],
    flash: Option<Flash<'_>>,
    prefill: &Prefill,
) -> String {
    let mut b = String::new();
    b.push_str("<h1>مدیریت اتصال سیستم‌ها</h1>\n");
    b.push_str(&format!(
        "<p class=\"hint\">وارد شده با نام: {} · نشانی SSO: <span class=\"ltr\">{}</span></p>\n",
        html_escape(admin_name),
        html_escape(base_url)
    ));

    match flash {
        Some(Flash::Ok(m)) => b.push_str(&format!("<div class=\"flash ok\">{}</div>\n", html_escape(m))),
        Some(Flash::Err(m)) => b.push_str(&format!("<div class=\"flash err\">{}</div>\n", html_escape(m))),
        None => {}
    }

    // Existing clients
    b.push_str("<div class=\"card\">\n<h2>سیستم‌های متصل</h2>\n");
    if clients.is_empty() {
        b.push_str("<p class=\"hint\">هنوز هیچ سیستمی متصل نشده است.</p>\n");
    } else {
        b.push_str("<table>\n<tr><th>نام</th><th>شناسه (client_id)</th><th>آدرس بازگشت</th><th>منبع</th><th>عملیات</th></tr>\n");
        for c in clients {
            let uris = c
                .redirect_uris
                .iter()
                .map(|u| format!("<div class=\"ltr\">{}</div>", html_escape(u)))
                .collect::<String>();
            let source = if c.dynamic { "پنل مدیریت" } else { "clients.toml (فقط‌خواندنی)" };
            let actions = if c.dynamic {
                let id = html_escape(&c.client_id);
                format!(
                    "<form class=\"inline\" method=\"post\" action=\"{base}/admin/clients/{id}/rotate\">{csrf}<button class=\"warn\" type=\"submit\">کلید جدید</button></form> \
                     <form class=\"inline\" method=\"post\" action=\"{base}/admin/clients/{id}/delete\">{csrf}<button class=\"danger\" type=\"submit\">حذف</button></form>",
                    base = html_escape(base_url),
                    id = id,
                    csrf = csrf_input(csrf),
                )
            } else {
                "—".to_string()
            };
            b.push_str(&format!(
                "<tr><td>{}</td><td class=\"ltr\">{}</td><td>{}</td><td><span class=\"badge\">{}</span></td><td>{}</td></tr>\n",
                html_escape(if c.name.is_empty() { &c.client_id } else { &c.name }),
                html_escape(&c.client_id),
                uris,
                source,
                actions
            ));
        }
        b.push_str("</table>\n");
    }
    b.push_str("</div>\n");

    // New client form
    b.push_str("<div class=\"card\">\n<h2>اتصال سیستم جدید</h2>\n");
    b.push_str(&format!(
        "<p class=\"hint\">برای Outline می‌توانید فرم را با <a href=\"{}/admin?preset=outline\">مقادیر آماده‌ی Outline</a> پر کنید. \
         پس از ساخت، کلید (client secret) فقط یک‌بار نمایش داده می‌شود.</p>\n",
        html_escape(base_url)
    ));
    b.push_str(&format!(
        "<form method=\"post\" action=\"{}/admin/clients\">\n{}\n",
        html_escape(base_url),
        csrf_input(csrf)
    ));
    b.push_str(&format!(
        "<label for=\"name\">نام نمایشی</label>\n<input id=\"name\" name=\"name\" type=\"text\" value=\"{}\">\n",
        html_escape(&prefill.name)
    ));
    b.push_str(&format!(
        "<label for=\"client_id\">شناسه (client_id): حروف کوچک انگلیسی، عدد، «-» و «_»</label>\n<input id=\"client_id\" name=\"client_id\" type=\"text\" class=\"code\" required value=\"{}\">\n",
        html_escape(&prefill.client_id)
    ));
    b.push_str(&format!(
        "<label for=\"redirect_uris\">آدرس بازگشت پس از ورود (redirect_uri): هر خط یک آدرس، دقیقاً مطابق سیستم مقصد</label>\n<textarea id=\"redirect_uris\" name=\"redirect_uris\" class=\"code\" required>{}</textarea>\n",
        html_escape(&prefill.redirect_uris)
    ));
    b.push_str(&format!(
        "<label for=\"post_logout_redirect_uris\">آدرس بازگشت پس از خروج (post_logout_redirect_uri): هر خط یک آدرس، اختیاری</label>\n<textarea id=\"post_logout_redirect_uris\" name=\"post_logout_redirect_uris\" class=\"code\">{}</textarea>\n",
        html_escape(&prefill.post_logout_redirect_uris)
    ));
    b.push_str(&format!(
        "<label><input type=\"checkbox\" name=\"require_pkce\" value=\"on\"{}> PKCE اجباری باشد (پیشنهادی)</label>\n",
        if prefill.require_pkce { " checked" } else { "" }
    ));
    b.push_str("<p><button type=\"submit\">ساخت اتصال و تولید کلید</button></p>\n</form>\n</div>\n");

    layout("مدیریت اتصال سیستم‌ها", &b)
}

/// The one-time page that shows a freshly generated secret together with
/// ready-to-paste settings. The secret has `id="client-secret"`.
pub fn render_secret(base_url: &str, client: &Client, secret: &str, rotated: bool) -> String {
    let id = &client.client_id;
    let env_block = format!(
        "OIDC_CLIENT_ID={id}\nOIDC_CLIENT_SECRET={secret}\nOIDC_ISSUER_URL={base}\nOIDC_LOGOUT_URI={base}/logout\nOIDC_SCOPES=openid profile email\nOIDC_USERNAME_CLAIM=preferred_username\nOIDC_DISPLAY_NAME=ورود با SSO\n",
        id = id,
        secret = secret,
        base = base_url
    );

    let mut b = String::new();
    b.push_str(if rotated {
        "<h1>کلید جدید ساخته شد</h1>\n"
    } else {
        "<h1>اتصال ساخته شد</h1>\n"
    });
    b.push_str(
        "<div class=\"flash err\"><strong>این کلید فقط همین یک‌بار نمایش داده می‌شود.</strong> \
         همین حالا آن را در سیستم مقصد وارد کنید؛ ssozia فقط هش آن را نگه می‌دارد و بعداً قابل بازیابی نیست \
         (در صورت گم‌شدن باید «کلید جدید» بسازید).</div>\n",
    );
    if rotated {
        b.push_str("<p class=\"hint\">کلید قبلی از همین لحظه کار نمی‌کند.</p>\n");
    }

    b.push_str("<div class=\"card\">\n<h2>کلید (client secret)</h2>\n");
    b.push_str(&format!(
        "<div class=\"secret\"><code id=\"client-secret\">{}</code></div>\n</div>\n",
        html_escape(secret)
    ));

    b.push_str("<div class=\"card\">\n<h2>تنظیمات Outline</h2>\n");
    b.push_str("<p class=\"hint\">این خط‌ها را به متغیرهای محیطی Outline اضافه کنید و Outline را دوباره راه‌اندازی کنید. ");
    b.push_str("متغیرهای OIDC_AUTH_URI، OIDC_TOKEN_URI و OIDC_USERINFO_URI را تنظیم نکنید.</p>\n");
    b.push_str(&format!(
        "<textarea class=\"code\" id=\"outline-env\" rows=\"8\" readonly>{}</textarea>\n</div>\n",
        html_escape(&env_block)
    ));

    b.push_str("<div class=\"card\">\n<h2>برای هر سیستم OIDC دیگر</h2>\n<table>\n");
    let rows: [(&str, String); 7] = [
        ("Client ID", id.clone()),
        ("Discovery", format!("{base_url}/.well-known/openid-configuration")),
        ("Issuer", base_url.to_string()),
        ("Authorization endpoint", format!("{base_url}/authorize")),
        ("Token endpoint", format!("{base_url}/token")),
        ("Userinfo endpoint", format!("{base_url}/userinfo")),
        ("End session endpoint", format!("{base_url}/logout")),
    ];
    for (k, v) in rows.iter() {
        b.push_str(&format!(
            "<tr><th>{}</th><td class=\"ltr\">{}</td></tr>\n",
            html_escape(k),
            html_escape(v)
        ));
    }
    b.push_str("</table>\n<p class=\"hint\">روش احراز هویت کلاینت: client_secret_basic یا client_secret_post · PKCE: S256 · scope: openid profile email</p>\n</div>\n");

    b.push_str(&format!(
        "<p><a href=\"{}/admin\">بازگشت به فهرست</a></p>",
        html_escape(base_url)
    ));
    layout("کلید اتصال", &b)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::test_support::test_client;

    #[test]
    fn secret_page_shows_secret_and_escaped_env_block() {
        let html = render_secret("http://sso.imamreza.ir", &test_client(), "abc<def>", false);
        assert!(html.contains(r#"<code id="client-secret">abc&lt;def&gt;</code>"#));
        assert!(html.contains("OIDC_ISSUER_URL=http://sso.imamreza.ir"));
        assert!(html.contains("OIDC_LOGOUT_URI=http://sso.imamreza.ir/logout"));
        assert!(!html.contains("<def>"));
    }

    #[test]
    fn dashboard_escapes_and_offers_actions_only_for_dynamic_clients() {
        let mut dynamic = test_client();
        dynamic.client_id = "wiki".to_string();
        dynamic.name = "<b>Wiki</b>".to_string();
        dynamic.dynamic = true;
        let html = render_dashboard(
            "http://sso.imamreza.ir",
            "Admin",
            "tok",
            &[test_client(), dynamic],
            None,
            &Prefill::blank(),
        );
        assert!(html.contains("&lt;b&gt;Wiki&lt;/b&gt;"));
        assert!(html.contains("/admin/clients/wiki/rotate"));
        assert!(html.contains("/admin/clients/wiki/delete"));
        assert!(!html.contains("/admin/clients/outline/delete"));
        assert!(html.contains(r#"<html dir="rtl" lang="fa">"#));
    }
}
