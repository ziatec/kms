//! Password hashing, client authentication and session lookup.

use std::collections::HashMap;
use std::sync::OnceLock;

use argon2::password_hash::rand_core::OsRng;
use argon2::password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString};
use argon2::Argon2;
use axum::http::{header, HeaderMap};
use base64::engine::general_purpose::{STANDARD, STANDARD_NO_PAD};
use base64::Engine;
use percent_encoding::percent_decode_str;

use crate::state::AppState;
use crate::stores::{Client, ClientStore, Session};
use crate::util;

/// SSO sessions last 8 hours.
pub const SESSION_TTL_SECS: i64 = 8 * 3600;

// ---------------------------------------------------------------------------
// Passwords (argon2id, default parameters)
// ---------------------------------------------------------------------------

pub fn hash_password(password: &str) -> Result<String, String> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| e.to_string())
}

pub fn verify_password(password: &str, hash: &str) -> bool {
    match PasswordHash::new(hash) {
        Ok(parsed) => Argon2::default()
            .verify_password(password.as_bytes(), &parsed)
            .is_ok(),
        Err(_) => false,
    }
}

static DUMMY_HASH: OnceLock<String> = OnceLock::new();

/// Verify against `hash` when there is one; otherwise burn the same amount
/// of time against a dummy hash and return false. This keeps "unknown
/// user" and "wrong password" indistinguishable by timing.
pub fn verify_password_or_dummy(password: &str, hash: Option<&str>) -> bool {
    match hash {
        Some(h) => verify_password(password, h),
        None => {
            let dummy = DUMMY_HASH
                .get_or_init(|| hash_password("ssozia-dummy-password").unwrap_or_default());
            let _ = verify_password(password, dummy);
            false
        }
    }
}

// ---------------------------------------------------------------------------
// Client authentication (client_secret_basic AND client_secret_post)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ClientAuthMethod {
    Basic,
    Post,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClientCredentials {
    pub client_id: String,
    pub client_secret: String,
    pub method: ClientAuthMethod,
}

fn pct_decode(s: &str) -> String {
    percent_decode_str(s).decode_utf8_lossy().into_owned()
}

/// Pull client credentials from the Authorization header (Basic) or, when
/// there is no Basic header, from the form fields `client_id` and
/// `client_secret`. `Err(())` means "no usable credentials".
pub fn extract_client_credentials(
    headers: &HeaderMap,
    form: &HashMap<String, String>,
) -> Result<ClientCredentials, ()> {
    if let Some(value) = headers.get(header::AUTHORIZATION).and_then(|v| v.to_str().ok()) {
        let value = value.trim();
        if value.len() > 6 && value[..6].eq_ignore_ascii_case("basic ") {
            let b64 = value[6..].trim();
            let decoded = STANDARD
                .decode(b64)
                .or_else(|_| STANDARD_NO_PAD.decode(b64))
                .map_err(|_| ())?;
            let text = String::from_utf8(decoded).map_err(|_| ())?;
            let (id, secret) = text.split_once(':').ok_or(())?;
            // RFC 6749 2.3.1: id and secret are form-urlencoded before
            // being base64-encoded.
            let (id, secret) = (pct_decode(id), pct_decode(secret));
            if id.is_empty() || secret.is_empty() {
                return Err(());
            }
            return Ok(ClientCredentials {
                client_id: id,
                client_secret: secret,
                method: ClientAuthMethod::Basic,
            });
        }
    }

    match (form.get("client_id"), form.get("client_secret")) {
        (Some(id), Some(secret)) if !id.is_empty() && !secret.is_empty() => Ok(ClientCredentials {
            client_id: id.clone(),
            client_secret: secret.clone(),
            method: ClientAuthMethod::Post,
        }),
        _ => Err(()),
    }
}

/// Look the client up and check its secret. Always does one argon2
/// verification, even for unknown clients.
pub async fn authenticate_client(
    store: &dyn ClientStore,
    client_id: &str,
    client_secret: &str,
) -> Option<Client> {
    let client = store.get(client_id).await;
    let ok = verify_password_or_dummy(
        client_secret,
        client.as_ref().map(|c| c.client_secret_hash.as_str()),
    );
    match (ok, client) {
        (true, Some(c)) => Some(c),
        _ => None,
    }
}

/// CSRF token for the admin forms, bound to the session and a per-process
/// secret.
pub fn csrf_token(secret: &str, session_id: &str) -> String {
    use sha2::{Digest, Sha256};
    let mut h = Sha256::new();
    h.update(secret.as_bytes());
    h.update([0u8]);
    h.update(session_id.as_bytes());
    util::b64url(&h.finalize())
}

// ---------------------------------------------------------------------------
// Sessions
// ---------------------------------------------------------------------------

/// The valid SSO session referenced by the request's cookie, if any.
pub async fn current_session(state: &AppState, headers: &HeaderMap) -> Option<Session> {
    let id = util::get_cookie(headers, &state.config.cookie_name)?;
    state.sessions.get(&id, util::now_secs()).await
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::test_support::*;
    use axum::http::HeaderValue;

    fn basic(id: &str, secret: &str) -> HeaderMap {
        let mut h = HeaderMap::new();
        let v = format!("Basic {}", STANDARD.encode(format!("{id}:{secret}")));
        h.insert(header::AUTHORIZATION, HeaderValue::from_str(&v).unwrap());
        h
    }

    fn post_form(id: &str, secret: &str) -> HashMap<String, String> {
        let mut m = HashMap::new();
        m.insert("client_id".to_string(), id.to_string());
        m.insert("client_secret".to_string(), secret.to_string());
        m
    }

    #[test]
    fn password_hash_roundtrip() {
        let h = hash_password("hunter2").unwrap();
        assert!(h.starts_with("$argon2id$"));
        assert!(verify_password("hunter2", &h));
        assert!(!verify_password("hunter3", &h));
        assert!(!verify_password("hunter2", "not-a-hash"));
        assert!(!verify_password_or_dummy("x", None));
    }

    #[tokio::test]
    async fn client_secret_basic_works() {
        let state = test_state();
        let creds =
            extract_client_credentials(&basic(TEST_CLIENT_ID, TEST_CLIENT_SECRET), &HashMap::new()).unwrap();
        assert_eq!(creds.method, ClientAuthMethod::Basic);
        let client = authenticate_client(state.clients.as_ref(), &creds.client_id, &creds.client_secret).await;
        assert_eq!(client.unwrap().client_id, TEST_CLIENT_ID);

        let bad = extract_client_credentials(&basic(TEST_CLIENT_ID, "wrong"), &HashMap::new()).unwrap();
        assert!(authenticate_client(state.clients.as_ref(), &bad.client_id, &bad.client_secret)
            .await
            .is_none());
    }

    #[tokio::test]
    async fn client_secret_post_works() {
        let state = test_state();
        let creds = extract_client_credentials(
            &HeaderMap::new(),
            &post_form(TEST_CLIENT_ID, TEST_CLIENT_SECRET),
        )
        .unwrap();
        assert_eq!(creds.method, ClientAuthMethod::Post);
        let client = authenticate_client(state.clients.as_ref(), &creds.client_id, &creds.client_secret).await;
        assert_eq!(client.unwrap().client_id, TEST_CLIENT_ID);

        let bad = extract_client_credentials(&HeaderMap::new(), &post_form(TEST_CLIENT_ID, "wrong")).unwrap();
        assert!(authenticate_client(state.clients.as_ref(), &bad.client_id, &bad.client_secret)
            .await
            .is_none());
    }

    #[tokio::test]
    async fn unknown_client_and_missing_credentials_are_rejected() {
        let state = test_state();
        assert!(authenticate_client(state.clients.as_ref(), "nobody", TEST_CLIENT_SECRET)
            .await
            .is_none());
        assert!(extract_client_credentials(&HeaderMap::new(), &HashMap::new()).is_err());
        let mut h = HeaderMap::new();
        h.insert(header::AUTHORIZATION, HeaderValue::from_static("Basic !!!not-base64!!!"));
        assert!(extract_client_credentials(&h, &HashMap::new()).is_err());
    }

    #[test]
    fn basic_credentials_are_percent_decoded() {
        let creds = extract_client_credentials(&basic("out%20line", "a%2Bb"), &HashMap::new()).unwrap();
        assert_eq!(creds.client_id, "out line");
        assert_eq!(creds.client_secret, "a+b");
    }
}
