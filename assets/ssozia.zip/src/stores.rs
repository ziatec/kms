//! Storage traits and their in-memory implementations.
//! VERSION: ssozia 0.2.0 (2026-10-12) - users managed from the admin API are
//! persisted in DATA_DIR/users-admin.json; disabled users cannot sign in.
//!
//! Handlers only ever see the traits (`Arc<dyn ...>` in `AppState`), so
//! step 2 can swap in PostgreSQL / Redis implementations without touching
//! any handler.

use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, RwLock};

use argon2::password_hash::PasswordHash;
use async_trait::async_trait;
use serde::{Deserialize, Serialize};

use crate::util;

// ---------------------------------------------------------------------------
// Data types
// ---------------------------------------------------------------------------

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct User {
    pub id: String,
    pub email: String,
    pub name: String,
    /// May be Persian (compared after `normalize_username`).
    pub preferred_username: String,
    pub password_hash: String,
    /// Admins may open /admin and manage connected systems (clients).
    #[serde(default)]
    pub is_admin: bool,
    /// Disabled users cannot sign in, and their sessions stop working.
    #[serde(default)]
    pub disabled: bool,
    /// Unix seconds; set for users created through the admin API.
    #[serde(default)]
    pub created_at: i64,
    #[serde(default)]
    pub updated_at: i64,
    /// true = managed through the admin API and persisted in
    /// DATA_DIR/users-admin.json; false = defined in users.toml (read-only).
    #[serde(skip)]
    pub dynamic: bool,
}

/// Canonical form used to compare user names: trimmed, Arabic letters mapped
/// to their Persian forms (ي ى -> ی, ك -> ک, ة -> ه), tatweel removed, Latin
/// lower-cased. The stored name keeps what the admin typed (normalized the
/// same way), so a Persian user name works with either keyboard layout.
pub fn normalize_username(s: &str) -> String {
    s.trim()
        .chars()
        .filter(|c| *c != '\u{0640}')
        .map(|c| match c {
            '\u{064A}' | '\u{0649}' => '\u{06CC}',
            '\u{0643}' => '\u{06A9}',
            '\u{0629}' => '\u{0647}',
            '\u{0660}'..='\u{0669}' => char::from_u32(c as u32 - 0x0660 + 0x06F0).unwrap_or(c),
            _ => c,
        })
        .flat_map(char::to_lowercase)
        .collect()
}

/// A user name: 2..64 characters, letters (Persian or Latin), digits,
/// ZWNJ, '.', '_' and '-'; no spaces.
pub fn valid_username(name: &str) -> bool {
    let n = name.chars().count();
    (2..=64).contains(&n)
        && name.chars().all(|c| {
            c.is_alphanumeric() || c == '.' || c == '_' || c == '-' || c == '\u{200C}'
        })
        && !name.starts_with(['.', '-', '\u{200C}'])
}

pub fn normalize_email(s: &str) -> String {
    s.trim().to_lowercase()
}

fn default_true() -> bool {
    true
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Client {
    pub client_id: String,
    /// Optional human readable name (shown in /admin).
    #[serde(default)]
    pub name: String,
    pub client_secret_hash: String,
    pub redirect_uris: Vec<String>,
    #[serde(default)]
    pub post_logout_redirect_uris: Vec<String>,
    #[serde(default = "default_true")]
    pub require_pkce: bool,
    /// May call the admin API (/admin/api/*) with its client credentials, on
    /// behalf of a signed-in ssozia admin. ADMIN_API_CLIENTS adds more ids.
    #[serde(default)]
    pub admin_api: bool,
    /// true = created in /admin and persisted in DATA_DIR/clients-admin.json;
    /// false = defined in clients.toml (read-only from /admin).
    #[serde(skip)]
    pub dynamic: bool,
}

/// An issued authorization code and everything needed to redeem it.
#[derive(Debug, Clone)]
pub struct AuthCode {
    pub client_id: String,
    pub redirect_uri: String,
    pub user_id: String,
    pub code_challenge: Option<String>,
    pub nonce: Option<String>,
    pub scope: String,
    pub auth_time: i64,
    pub expires_at: i64,
}

#[derive(Debug, Clone)]
pub struct Session {
    pub id: String,
    pub user_id: String,
    pub created_at: i64,
    pub expires_at: i64,
}

// ---------------------------------------------------------------------------
// Traits
// ---------------------------------------------------------------------------

#[async_trait]
pub trait UserStore: Send + Sync {
    /// Case-insensitive email lookup. Active (not disabled) users only.
    async fn find_by_email(&self, email: &str) -> Option<User>;
    /// Active users only: a disabled user's session and tokens stop working.
    async fn find_by_id(&self, id: &str) -> Option<User>;
    /// Sign-in lookup by email or user name (Persian allowed). Active only.
    async fn find_by_login(&self, login: &str) -> Option<User>;
    /// Any user, disabled ones included (for the admin API).
    async fn get(&self, id: &str) -> Option<User>;
    /// All users, sorted by name.
    async fn list(&self) -> Vec<User>;
    /// Create or replace a managed user (stored with `dynamic = true`).
    /// Users from users.toml cannot be replaced. Email and user name must be
    /// unique among all users.
    async fn upsert(&self, user: User) -> Result<(), String>;
}

#[async_trait]
pub trait ClientStore: Send + Sync {
    async fn get(&self, client_id: &str) -> Option<Client>;
    /// All clients, sorted by client_id.
    async fn list(&self) -> Vec<Client>;
    /// Create or replace an admin-managed client (stored with
    /// `dynamic = true`). Clients from clients.toml cannot be replaced.
    async fn upsert(&self, client: Client) -> Result<(), String>;
    /// Remove an admin-managed client. `Ok(false)` if it does not exist;
    /// clients from clients.toml cannot be removed.
    async fn remove(&self, client_id: &str) -> Result<bool, String>;
}

#[async_trait]
pub trait CodeStore: Send + Sync {
    async fn put(&self, code: &str, grant: AuthCode);
    /// Atomically remove and return the code. This is what makes codes
    /// single-use: a second `take` of the same code returns `None`.
    async fn take(&self, code: &str) -> Option<AuthCode>;
}

#[async_trait]
pub trait SessionStore: Send + Sync {
    async fn create(&self, user_id: &str, now: i64, ttl_secs: i64) -> Session;
    /// Returns the session only if it exists and has not expired.
    async fn get(&self, id: &str, now: i64) -> Option<Session>;
    async fn delete(&self, id: &str);
}

// ---------------------------------------------------------------------------
// In-memory users
// ---------------------------------------------------------------------------

pub struct InMemoryUserStore {
    users: RwLock<HashMap<String, User>>,
    persist_path: Option<PathBuf>,
}

fn validate_user(u: &User) -> Result<(), String> {
    if u.id.trim().is_empty() {
        return Err("user id is empty".to_string());
    }
    PasswordHash::new(&u.password_hash).map_err(|_| {
        format!(
            "user '{}': password_hash is not a valid argon2 hash \
             (generate one with `ssozia hash-password`)",
            u.id
        )
    })?;
    Ok(())
}

/// Duplicate id / email / user name among `users`, if any.
fn find_conflict<'a>(users: impl Iterator<Item = &'a User>, u: &User) -> Option<String> {
    let email = normalize_email(&u.email);
    let name = normalize_username(&u.preferred_username);
    for other in users {
        if other.id == u.id {
            continue;
        }
        if normalize_email(&other.email) == email {
            return Some(format!("duplicate user email '{}'", u.email));
        }
        if !name.is_empty() && normalize_username(&other.preferred_username) == name {
            return Some(format!("duplicate user name '{}'", u.preferred_username));
        }
    }
    None
}

impl InMemoryUserStore {
    pub fn new(users: Vec<User>) -> Result<Self, String> {
        if users.is_empty() {
            return Err("no users defined".to_string());
        }
        let mut map: HashMap<String, User> = HashMap::new();
        for u in users {
            validate_user(&u)?;
            if map.contains_key(&u.id) {
                return Err(format!("duplicate user id '{}'", u.id));
            }
            if let Some(e) = find_conflict(map.values(), &u) {
                return Err(e);
            }
            map.insert(u.id.clone(), u);
        }
        Ok(Self {
            users: RwLock::new(map),
            persist_path: None,
        })
    }

    /// Persist managed users to `path` on every change.
    pub fn with_persistence(mut self, path: PathBuf) -> Self {
        self.persist_path = Some(path);
        self
    }

    fn persist(&self, map: &HashMap<String, User>) -> Result<(), String> {
        let Some(path) = &self.persist_path else {
            return Ok(());
        };
        let mut dynamic: Vec<&User> = map.values().filter(|u| u.dynamic).collect();
        dynamic.sort_by(|a, b| a.id.cmp(&b.id));
        write_json_private(path, &dynamic)
    }

    fn read(&self) -> std::sync::RwLockReadGuard<'_, HashMap<String, User>> {
        self.users.read().unwrap_or_else(|e| e.into_inner())
    }
}

#[async_trait]
impl UserStore for InMemoryUserStore {
    async fn find_by_email(&self, email: &str) -> Option<User> {
        let key = normalize_email(email);
        self.read()
            .values()
            .find(|u| !u.disabled && normalize_email(&u.email) == key)
            .cloned()
    }

    async fn find_by_id(&self, id: &str) -> Option<User> {
        self.read().get(id).filter(|u| !u.disabled).cloned()
    }

    async fn find_by_login(&self, login: &str) -> Option<User> {
        let email = normalize_email(login);
        let name = normalize_username(login);
        if name.is_empty() {
            return None;
        }
        let map = self.read();
        map.values()
            .find(|u| !u.disabled && normalize_email(&u.email) == email)
            .or_else(|| {
                map.values()
                    .find(|u| !u.disabled && normalize_username(&u.preferred_username) == name)
            })
            .cloned()
    }

    async fn get(&self, id: &str) -> Option<User> {
        self.read().get(id).cloned()
    }

    async fn list(&self) -> Vec<User> {
        let mut v: Vec<User> = self.read().values().cloned().collect();
        v.sort_by(|a, b| a.name.cmp(&b.name).then_with(|| a.id.cmp(&b.id)));
        v
    }

    async fn upsert(&self, mut user: User) -> Result<(), String> {
        validate_user(&user)?;
        user.dynamic = true;
        let mut map = self.users.write().unwrap_or_else(|e| e.into_inner());
        if matches!(map.get(&user.id), Some(existing) if !existing.dynamic) {
            return Err(format!(
                "user '{}' is defined in users.toml and cannot be changed here",
                user.id
            ));
        }
        if let Some(e) = find_conflict(map.values(), &user) {
            return Err(e);
        }
        let id = user.id.clone();
        let previous = map.insert(id.clone(), user);
        if let Err(e) = self.persist(&map) {
            match previous {
                Some(p) => map.insert(id, p),
                None => map.remove(&id),
            };
            return Err(e);
        }
        Ok(())
    }
}

#[derive(Deserialize)]
struct UsersFile {
    #[serde(default)]
    users: Vec<User>,
}

/// Users from users.toml (read-only) plus the managed ones in
/// DATA_DIR/users-admin.json. An id present in users.toml wins.
pub fn load_users(path: &Path, admin_path: &Path) -> Result<InMemoryUserStore, String> {
    let text = std::fs::read_to_string(path)
        .map_err(|e| format!("cannot read users file {}: {e}", path.display()))?;
    let file: UsersFile =
        toml::from_str(&text).map_err(|e| format!("invalid users file {}: {e}", path.display()))?;
    let mut users = file.users;
    if admin_path.exists() {
        let text = std::fs::read_to_string(admin_path)
            .map_err(|e| format!("cannot read {}: {e}", admin_path.display()))?;
        let stored: Vec<User> = serde_json::from_str(&text)
            .map_err(|e| format!("invalid {}: {e}", admin_path.display()))?;
        for mut u in stored {
            if users.iter().any(|x| x.id == u.id) {
                tracing::warn!(user_id = %u.id, "ignoring managed user: id also defined in users.toml");
                continue;
            }
            u.dynamic = true;
            users.push(u);
        }
    }
    if !users.iter().any(|u| u.is_admin && !u.disabled) {
        tracing::warn!(
            "no active user has is_admin = true ({}): /admin is unusable until you add one",
            path.display()
        );
    }
    Ok(InMemoryUserStore::new(users)
        .map_err(|e| format!("{}: {e}", path.display()))?
        .with_persistence(admin_path.to_path_buf()))
}

// ---------------------------------------------------------------------------
// In-memory clients (admin-created ones are persisted to a JSON file)
// ---------------------------------------------------------------------------

pub fn validate_client(c: &Client) -> Result<(), String> {
    if c.client_id.is_empty() {
        return Err("client_id is empty".to_string());
    }
    PasswordHash::new(&c.client_secret_hash).map_err(|_| {
        format!(
            "client '{}': client_secret_hash is not a valid argon2 hash \
             (generate one with `ssozia hash-password`)",
            c.client_id
        )
    })?;
    if c.redirect_uris.is_empty() {
        return Err(format!("client '{}': redirect_uris is empty", c.client_id));
    }
    Ok(())
}

pub struct InMemoryClientStore {
    clients: RwLock<HashMap<String, Client>>,
    persist_path: Option<PathBuf>,
}

impl InMemoryClientStore {
    /// Zero clients is allowed: they can be created in /admin.
    pub fn new(clients: Vec<Client>) -> Result<Self, String> {
        let mut map = HashMap::new();
        for c in clients {
            validate_client(&c)?;
            if map.contains_key(&c.client_id) {
                return Err(format!("duplicate client_id '{}'", c.client_id));
            }
            map.insert(c.client_id.clone(), c);
        }
        Ok(Self {
            clients: RwLock::new(map),
            persist_path: None,
        })
    }

    /// Persist admin-created clients to `path` on every change.
    pub fn with_persistence(mut self, path: PathBuf) -> Self {
        self.persist_path = Some(path);
        self
    }

    fn persist(&self, map: &HashMap<String, Client>) -> Result<(), String> {
        let Some(path) = &self.persist_path else {
            return Ok(());
        };
        let mut dynamic: Vec<&Client> = map.values().filter(|c| c.dynamic).collect();
        dynamic.sort_by(|a, b| a.client_id.cmp(&b.client_id));
        write_json_private(path, &dynamic)
    }
}

/// Write `value` as pretty JSON to `path` (mode 600), atomically.
pub fn write_json_private<T: Serialize + ?Sized>(path: &Path, value: &T) -> Result<(), String> {
    let json = serde_json::to_vec_pretty(value).map_err(|e| e.to_string())?;
    if let Some(dir) = path.parent() {
        std::fs::create_dir_all(dir).map_err(|e| format!("cannot create {}: {e}", dir.display()))?;
    }
    let tmp = path.with_extension("json.tmp");
    write_private(&tmp, &json).map_err(|e| format!("cannot write {}: {e}", tmp.display()))?;
    std::fs::rename(&tmp, path).map_err(|e| format!("cannot replace {}: {e}", path.display()))
}

#[cfg(unix)]
fn write_private(path: &Path, data: &[u8]) -> std::io::Result<()> {
    use std::io::Write;
    use std::os::unix::fs::OpenOptionsExt;
    let mut f = std::fs::OpenOptions::new()
        .write(true)
        .create(true)
        .truncate(true)
        .mode(0o600)
        .open(path)?;
    f.write_all(data)
}

#[cfg(not(unix))]
fn write_private(path: &Path, data: &[u8]) -> std::io::Result<()> {
    std::fs::write(path, data)
}

#[async_trait]
impl ClientStore for InMemoryClientStore {
    async fn get(&self, client_id: &str) -> Option<Client> {
        self.clients
            .read()
            .unwrap_or_else(|e| e.into_inner())
            .get(client_id)
            .cloned()
    }

    async fn list(&self) -> Vec<Client> {
        let map = self.clients.read().unwrap_or_else(|e| e.into_inner());
        let mut v: Vec<Client> = map.values().cloned().collect();
        v.sort_by(|a, b| a.client_id.cmp(&b.client_id));
        v
    }

    async fn upsert(&self, mut client: Client) -> Result<(), String> {
        validate_client(&client)?;
        client.dynamic = true;
        let mut map = self.clients.write().unwrap_or_else(|e| e.into_inner());
        if matches!(map.get(&client.client_id), Some(existing) if !existing.dynamic) {
            return Err(format!(
                "client '{}' is defined in clients.toml and cannot be changed here",
                client.client_id
            ));
        }
        let id = client.client_id.clone();
        let previous = map.insert(id.clone(), client);
        if let Err(e) = self.persist(&map) {
            match previous {
                Some(p) => map.insert(id, p),
                None => map.remove(&id),
            };
            return Err(e);
        }
        Ok(())
    }

    async fn remove(&self, client_id: &str) -> Result<bool, String> {
        let mut map = self.clients.write().unwrap_or_else(|e| e.into_inner());
        match map.get(client_id) {
            None => Ok(false),
            Some(c) if !c.dynamic => Err(format!(
                "client '{client_id}' is defined in clients.toml and cannot be removed here"
            )),
            Some(_) => {
                let previous = map.remove(client_id);
                if let Err(e) = self.persist(&map) {
                    if let Some(p) = previous {
                        map.insert(client_id.to_string(), p);
                    }
                    return Err(e);
                }
                Ok(true)
            }
        }
    }
}

#[derive(Deserialize)]
struct ClientsFile {
    #[serde(default)]
    clients: Vec<Client>,
}

/// Load clients from clients.toml (optional) plus the admin-managed JSON
/// file. A client id present in clients.toml wins over the JSON file.
pub fn load_clients(path: &Path, admin_path: &Path) -> Result<InMemoryClientStore, String> {
    let mut clients: Vec<Client> = Vec::new();
    if path.exists() {
        let text = std::fs::read_to_string(path)
            .map_err(|e| format!("cannot read clients file {}: {e}", path.display()))?;
        let file: ClientsFile = toml::from_str(&text)
            .map_err(|e| format!("invalid clients file {}: {e}", path.display()))?;
        clients = file.clients;
    } else {
        tracing::warn!(
            "clients file {} not found; only admin-created clients will exist",
            path.display()
        );
    }
    if admin_path.exists() {
        let text = std::fs::read_to_string(admin_path)
            .map_err(|e| format!("cannot read {}: {e}", admin_path.display()))?;
        let stored: Vec<Client> = serde_json::from_str(&text)
            .map_err(|e| format!("invalid {}: {e}", admin_path.display()))?;
        for mut c in stored {
            if clients.iter().any(|x| x.client_id == c.client_id) {
                tracing::warn!(client_id = %c.client_id, "ignoring admin-created client: id also defined in clients.toml");
                continue;
            }
            c.dynamic = true;
            clients.push(c);
        }
    }
    Ok(InMemoryClientStore::new(clients)
        .map_err(|e| format!("{}: {e}", path.display()))?
        .with_persistence(admin_path.to_path_buf()))
}

// ---------------------------------------------------------------------------
// In-memory authorization codes
// ---------------------------------------------------------------------------

#[derive(Default)]
pub struct InMemoryCodeStore {
    codes: Mutex<HashMap<String, AuthCode>>,
}

impl InMemoryCodeStore {
    pub fn new() -> Self {
        Self::default()
    }
}

#[async_trait]
impl CodeStore for InMemoryCodeStore {
    async fn put(&self, code: &str, grant: AuthCode) {
        let now = util::now_secs();
        let mut map = self.codes.lock().unwrap_or_else(|e| e.into_inner());
        // Opportunistic cleanup so abandoned codes do not pile up.
        map.retain(|_, g| g.expires_at > now);
        map.insert(code.to_string(), grant);
    }

    async fn take(&self, code: &str) -> Option<AuthCode> {
        let mut map = self.codes.lock().unwrap_or_else(|e| e.into_inner());
        map.remove(code)
    }
}

// ---------------------------------------------------------------------------
// In-memory sessions
// ---------------------------------------------------------------------------

#[derive(Default)]
pub struct InMemorySessionStore {
    sessions: Mutex<HashMap<String, Session>>,
}

impl InMemorySessionStore {
    pub fn new() -> Self {
        Self::default()
    }
}

#[async_trait]
impl SessionStore for InMemorySessionStore {
    async fn create(&self, user_id: &str, now: i64, ttl_secs: i64) -> Session {
        let session = Session {
            id: util::random_token(32),
            user_id: user_id.to_string(),
            created_at: now,
            expires_at: now + ttl_secs,
        };
        let mut map = self.sessions.lock().unwrap_or_else(|e| e.into_inner());
        map.retain(|_, s| s.expires_at > now);
        map.insert(session.id.clone(), session.clone());
        session
    }

    async fn get(&self, id: &str, now: i64) -> Option<Session> {
        let mut map = self.sessions.lock().unwrap_or_else(|e| e.into_inner());
        match map.get(id) {
            Some(s) if s.expires_at > now => Some(s.clone()),
            Some(_) => {
                map.remove(id);
                None
            }
            None => None,
        }
    }

    async fn delete(&self, id: &str) {
        let mut map = self.sessions.lock().unwrap_or_else(|e| e.into_inner());
        map.remove(id);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn sessions_expire_and_delete() {
        let store = InMemorySessionStore::new();
        let s = store.create("u_1", 1000, 60).await;
        assert!(store.get(&s.id, 1059).await.is_some());
        assert!(store.get(&s.id, 1060).await.is_none());
        let s2 = store.create("u_1", 1000, 60).await;
        store.delete(&s2.id).await;
        assert!(store.get(&s2.id, 1001).await.is_none());
    }

    #[test]
    fn example_placeholder_hash_is_rejected() {
        let u = User {
            id: "u_1".into(),
            email: "a@b.c".into(),
            name: "A".into(),
            preferred_username: "a".into(),
            password_hash: "PASTE_HASH_HERE".into(),
            is_admin: false,
            disabled: false,
            created_at: 0,
            updated_at: 0,
            dynamic: false,
        };
        assert!(InMemoryUserStore::new(vec![u]).is_err());
    }
}
