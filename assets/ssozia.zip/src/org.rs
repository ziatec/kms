//! Organization chart: positions (a tree) and which users hold them.
//! VERSION: ssozia 0.2.0 (2026-10-12)
//!
//! Stored in DATA_DIR/orgchart.json next to the other ssozia data. A user may
//! hold several positions and a position may have several holders (e.g. an
//! acting holder). Positions are referenced by a stable id.

use std::path::{Path, PathBuf};
use std::sync::RwLock;

use serde::{Deserialize, Serialize};

use crate::stores::write_json_private;
use crate::util;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Position {
    pub id: String,
    pub title: String,
    /// None = a root of the chart.
    #[serde(default)]
    pub parent_id: Option<String>,
    /// Optional organizational unit (e.g. «معاونت فنی»).
    #[serde(default)]
    pub unit: String,
    #[serde(default)]
    pub description: String,
    /// Order among siblings (smaller first).
    #[serde(default)]
    pub sort: i64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct Assignment {
    pub position_id: String,
    pub user_id: String,
    /// The user's main position (at most one per user).
    #[serde(default)]
    pub primary: bool,
    #[serde(default)]
    pub since: i64,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct OrgChart {
    #[serde(default)]
    pub positions: Vec<Position>,
    #[serde(default)]
    pub assignments: Vec<Assignment>,
}

#[derive(Debug, Clone, Default)]
pub struct PositionInput {
    pub title: String,
    pub parent_id: Option<String>,
    pub unit: String,
    pub description: String,
    pub sort: i64,
}

pub struct OrgStore {
    chart: RwLock<OrgChart>,
    persist_path: Option<PathBuf>,
}

impl OrgStore {
    pub fn new(chart: OrgChart) -> Self {
        Self {
            chart: RwLock::new(chart),
            persist_path: None,
        }
    }

    /// Load DATA_DIR/orgchart.json (an empty chart when it does not exist).
    pub fn load(path: &Path) -> Result<Self, String> {
        let chart = if path.exists() {
            let text = std::fs::read_to_string(path)
                .map_err(|e| format!("cannot read {}: {e}", path.display()))?;
            serde_json::from_str(&text).map_err(|e| format!("invalid {}: {e}", path.display()))?
        } else {
            OrgChart::default()
        };
        Ok(Self {
            chart: RwLock::new(chart),
            persist_path: Some(path.to_path_buf()),
        })
    }

    pub fn snapshot(&self) -> OrgChart {
        self.chart.read().unwrap_or_else(|e| e.into_inner()).clone()
    }

    /// Positions a user holds, in chart order.
    pub fn positions_of(&self, user_id: &str) -> Vec<(Position, bool)> {
        let chart = self.chart.read().unwrap_or_else(|e| e.into_inner());
        chart
            .assignments
            .iter()
            .filter(|a| a.user_id == user_id)
            .filter_map(|a| {
                chart
                    .positions
                    .iter()
                    .find(|p| p.id == a.position_id)
                    .map(|p| (p.clone(), a.primary))
            })
            .collect()
    }

    /// Apply `change` to a copy, persist it, then publish it. On any error
    /// the stored chart stays as it was.
    fn modify<T>(&self, change: impl FnOnce(&mut OrgChart) -> Result<T, String>) -> Result<T, String> {
        let mut guard = self.chart.write().unwrap_or_else(|e| e.into_inner());
        let mut next = guard.clone();
        let out = change(&mut next)?;
        if let Some(path) = &self.persist_path {
            write_json_private(path, &next)?;
        }
        *guard = next;
        Ok(out)
    }

    pub fn create_position(&self, input: PositionInput) -> Result<Position, String> {
        let title = clean_title(&input.title)?;
        self.modify(|chart| {
            check_parent(chart, None, input.parent_id.as_deref())?;
            let p = Position {
                id: format!("p_{}", util::random_hex(6)),
                title,
                parent_id: input.parent_id.clone(),
                unit: input.unit.trim().to_string(),
                description: input.description.trim().to_string(),
                sort: input.sort,
            };
            chart.positions.push(p.clone());
            Ok(p)
        })
    }

    pub fn update_position(&self, id: &str, input: PositionInput) -> Result<Position, String> {
        let title = clean_title(&input.title)?;
        self.modify(|chart| {
            check_parent(chart, Some(id), input.parent_id.as_deref())?;
            let p = chart
                .positions
                .iter_mut()
                .find(|p| p.id == id)
                .ok_or_else(|| "پست پیدا نشد.".to_string())?;
            p.title = title;
            p.parent_id = input.parent_id.clone();
            p.unit = input.unit.trim().to_string();
            p.description = input.description.trim().to_string();
            p.sort = input.sort;
            Ok(p.clone())
        })
    }

    /// Delete a position that has no sub-positions; its assignments go too.
    pub fn delete_position(&self, id: &str) -> Result<(), String> {
        self.modify(|chart| {
            if !chart.positions.iter().any(|p| p.id == id) {
                return Err("پست پیدا نشد.".to_string());
            }
            if chart.positions.iter().any(|p| p.parent_id.as_deref() == Some(id)) {
                return Err("این پست زیرمجموعه دارد؛ اول زیرمجموعه‌ها را جابه‌جا یا حذف کنید.".to_string());
            }
            chart.positions.retain(|p| p.id != id);
            chart.assignments.retain(|a| a.position_id != id);
            Ok(())
        })
    }

    pub fn assign(&self, position_id: &str, user_id: &str, primary: bool) -> Result<(), String> {
        self.modify(|chart| {
            if !chart.positions.iter().any(|p| p.id == position_id) {
                return Err("پست پیدا نشد.".to_string());
            }
            if primary {
                for a in chart.assignments.iter_mut().filter(|a| a.user_id == user_id) {
                    a.primary = false;
                }
            }
            match chart
                .assignments
                .iter_mut()
                .find(|a| a.user_id == user_id && a.position_id == position_id)
            {
                Some(a) => a.primary = primary,
                None => chart.assignments.push(Assignment {
                    position_id: position_id.to_string(),
                    user_id: user_id.to_string(),
                    primary,
                    since: util::now_secs(),
                }),
            }
            Ok(())
        })
    }

    pub fn unassign(&self, position_id: &str, user_id: &str) -> Result<bool, String> {
        self.modify(|chart| {
            let before = chart.assignments.len();
            chart
                .assignments
                .retain(|a| !(a.user_id == user_id && a.position_id == position_id));
            Ok(chart.assignments.len() != before)
        })
    }
}

fn clean_title(title: &str) -> Result<String, String> {
    let t = title.trim();
    if t.is_empty() || t.chars().count() > 200 {
        return Err("عنوان پست لازم است (حداکثر ۲۰۰ نویسه).".to_string());
    }
    Ok(t.to_string())
}

/// The parent must exist and must not be the position itself or one of its
/// descendants (no cycles).
fn check_parent(chart: &OrgChart, id: Option<&str>, parent: Option<&str>) -> Result<(), String> {
    let Some(mut cur) = parent else {
        return Ok(());
    };
    if !chart.positions.iter().any(|p| p.id == cur) {
        return Err("پست بالادست پیدا نشد.".to_string());
    }
    let Some(id) = id else {
        return Ok(());
    };
    for _ in 0..=chart.positions.len() {
        if cur == id {
            return Err("پست نمی‌تواند زیرمجموعه‌ی خودش یا زیرمجموعه‌هایش باشد.".to_string());
        }
        match chart
            .positions
            .iter()
            .find(|p| p.id == cur)
            .and_then(|p| p.parent_id.as_deref())
        {
            Some(next) => cur = next,
            None => return Ok(()),
        }
    }
    Err("چرخه در چارت سازمانی".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn input(title: &str, parent: Option<&str>) -> PositionInput {
        PositionInput {
            title: title.to_string(),
            parent_id: parent.map(str::to_string),
            ..Default::default()
        }
    }

    #[test]
    fn tree_assignments_and_cycles() {
        let org = OrgStore::new(OrgChart::default());
        let ceo = org.create_position(input("مدیرعامل", None)).unwrap();
        let cto = org.create_position(input("معاون فنی", Some(&ceo.id))).unwrap();
        let dev = org.create_position(input("کارشناس", Some(&cto.id))).unwrap();

        // no cycles, no unknown parent
        assert!(org.update_position(&ceo.id, input("مدیرعامل", Some(&dev.id))).is_err());
        assert!(org.update_position(&cto.id, input("x", Some(&cto.id))).is_err());
        assert!(org.create_position(input("x", Some("p_missing"))).is_err());
        assert!(org.create_position(input("  ", None)).is_err());

        // a user with two positions, one primary
        org.assign(&cto.id, "u_1", true).unwrap();
        org.assign(&dev.id, "u_1", false).unwrap();
        org.assign(&dev.id, "u_2", true).unwrap();
        let mine = org.positions_of("u_1");
        assert_eq!(mine.len(), 2);
        assert_eq!(mine.iter().filter(|(_, primary)| *primary).count(), 1);
        org.assign(&dev.id, "u_1", true).unwrap();
        let primary: Vec<_> = org.positions_of("u_1").into_iter().filter(|(_, p)| *p).collect();
        assert_eq!(primary.len(), 1);
        assert_eq!(primary[0].0.id, dev.id);

        // a parent with children cannot be deleted; a leaf can, with its assignments
        assert!(org.delete_position(&cto.id).is_err());
        org.delete_position(&dev.id).unwrap();
        assert_eq!(org.positions_of("u_1").len(), 1);
        assert!(org.positions_of("u_2").is_empty());
        assert!(org.unassign(&cto.id, "u_1").unwrap());
        assert!(!org.unassign(&cto.id, "u_1").unwrap());
    }

    #[test]
    fn chart_survives_a_restart() {
        let dir = std::env::temp_dir().join(format!("ssozia-orgtest-{}", util::random_token(8)));
        let path = dir.join("orgchart.json");
        let org = OrgStore::load(&path).unwrap();
        let p = org.create_position(input("مدیر", None)).unwrap();
        org.assign(&p.id, "u_9", true).unwrap();
        let again = OrgStore::load(&path).unwrap();
        assert_eq!(again.snapshot().positions, vec![p]);
        assert_eq!(again.positions_of("u_9").len(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
