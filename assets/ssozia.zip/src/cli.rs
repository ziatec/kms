//! Command line interface.

use std::io::Read;

use clap::{Parser, Subcommand};

#[derive(Parser, Debug)]
#[command(name = "ssozia", version, about = "Minimal OIDC provider")]
pub struct Cli {
    #[command(subcommand)]
    pub command: Option<Command>,
}

#[derive(Subcommand, Debug)]
pub enum Command {
    /// Start the HTTP server (default when no subcommand is given).
    Serve,
    /// Print an argon2id hash. Reads the password from stdin unless
    /// --password is given.
    HashPassword {
        /// Plaintext password. Prefer stdin: arguments are visible in `ps`
        /// and shell history.
        #[arg(long)]
        password: Option<String>,
    },
}

/// Read the whole of stdin and strip ONE trailing line ending (so both
/// `printf %s pw |` and `echo pw |` give the same result).
pub fn read_password_from_stdin() -> Result<String, String> {
    let mut buf = String::new();
    std::io::stdin()
        .read_to_string(&mut buf)
        .map_err(|e| format!("cannot read password from stdin: {e}"))?;
    Ok(strip_one_newline(buf))
}

fn strip_one_newline(mut s: String) -> String {
    if s.ends_with('\n') {
        s.pop();
        if s.ends_with('\r') {
            s.pop();
        }
    }
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn strips_a_single_trailing_newline() {
        assert_eq!(strip_one_newline("pw\n".into()), "pw");
        assert_eq!(strip_one_newline("pw\r\n".into()), "pw");
        assert_eq!(strip_one_newline("pw".into()), "pw");
        assert_eq!(strip_one_newline("pw\n\n".into()), "pw\n");
    }

    #[test]
    fn parses_subcommands() {
        let c = Cli::try_parse_from(["ssozia", "hash-password", "--password", "x"]).unwrap();
        assert!(matches!(c.command, Some(Command::HashPassword { password: Some(_) })));
        let c = Cli::try_parse_from(["ssozia"]).unwrap();
        assert!(c.command.is_none());
        let c = Cli::try_parse_from(["ssozia", "serve"]).unwrap();
        assert!(matches!(c.command, Some(Command::Serve)));
    }
}
