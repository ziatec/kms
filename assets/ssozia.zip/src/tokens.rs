//! id_token and access_token issuing / verification.
//!
//! The access token is a signed JWT (with `token_use = "access"`), so
//! /userinfo needs no token table: it verifies the signature, then loads the
//! user by `sub`.

use std::collections::HashSet;

use jsonwebtoken::{Algorithm, Validation};
use serde::{Deserialize, Serialize};

use crate::keys::SigningKeys;
use crate::stores::User;
use crate::util;

pub const TOKEN_TTL_SECS: i64 = 3600;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdTokenClaims {
    pub iss: String,
    pub sub: String,
    pub aud: String,
    pub exp: i64,
    pub iat: i64,
    pub auth_time: i64,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub nonce: Option<String>,
    pub email: String,
    pub email_verified: bool,
    pub name: String,
    pub preferred_username: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AccessTokenClaims {
    pub iss: String,
    pub sub: String,
    pub aud: String,
    pub exp: i64,
    pub iat: i64,
    pub scope: String,
    pub token_use: String,
    pub jti: String,
}

pub fn issue_id_token(
    keys: &SigningKeys,
    issuer: &str,
    client_id: &str,
    user: &User,
    nonce: Option<&str>,
    auth_time: i64,
    now: i64,
) -> Result<String, String> {
    let claims = IdTokenClaims {
        iss: issuer.to_string(),
        sub: user.id.clone(),
        aud: client_id.to_string(),
        exp: now + TOKEN_TTL_SECS,
        iat: now,
        auth_time,
        nonce: nonce.map(str::to_string),
        email: user.email.clone(),
        email_verified: true,
        name: user.name.clone(),
        preferred_username: user.preferred_username.clone(),
    };
    keys.sign(&claims)
}

pub fn issue_access_token(
    keys: &SigningKeys,
    issuer: &str,
    client_id: &str,
    user_id: &str,
    scope: &str,
    now: i64,
) -> Result<String, String> {
    let claims = AccessTokenClaims {
        iss: issuer.to_string(),
        sub: user_id.to_string(),
        aud: client_id.to_string(),
        exp: now + TOKEN_TTL_SECS,
        iat: now,
        scope: scope.to_string(),
        token_use: "access".to_string(),
        jti: util::random_token(16),
    };
    keys.sign(&claims)
}

/// Verify an access token we issued. `None` for anything wrong: bad
/// signature, wrong issuer, expired, or not an access token (an id_token
/// cannot be used as a bearer token).
pub fn verify_access_token(
    keys: &SigningKeys,
    issuer: &str,
    token: &str,
    now: i64,
) -> Option<AccessTokenClaims> {
    let mut validation = Validation::new(Algorithm::RS256);
    validation.set_issuer(&[issuer]);
    validation.validate_aud = false;
    validation.validate_exp = false; // checked below against `now`
    validation.required_spec_claims = ["exp", "iss", "sub"]
        .iter()
        .map(|s| s.to_string())
        .collect::<HashSet<_>>();
    let data = jsonwebtoken::decode::<AccessTokenClaims>(token, keys.decoding_key(), &validation).ok()?;
    let claims = data.claims;
    if claims.token_use != "access" || claims.exp <= now {
        return None;
    }
    Some(claims)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::state::test_support::*;
    use jsonwebtoken::{Algorithm, DecodingKey, Validation};

    /// Build a verification key from the JWKS document exactly as a relying
    /// party would, instead of using the in-process key object.
    fn key_from_jwks(jwks: &serde_json::Value) -> (DecodingKey, String) {
        let k = &jwks["keys"][0];
        assert_eq!(k["kty"], "RSA");
        assert_eq!(k["alg"], "RS256");
        (
            DecodingKey::from_rsa_components(k["n"].as_str().unwrap(), k["e"].as_str().unwrap())
                .unwrap(),
            k["kid"].as_str().unwrap().to_string(),
        )
    }

    #[test]
    fn id_token_has_correct_claims_and_verifies_against_jwks() {
        let state = test_state();
        let user = test_user();
        let now = util::now_secs();
        let token = issue_id_token(
            &state.keys,
            BASE,
            TEST_CLIENT_ID,
            &user,
            Some("n-0S6_WzA2Mj"),
            now - 5,
            now,
        )
        .unwrap();

        let (key, kid) = key_from_jwks(state.keys.jwks());
        let header = jsonwebtoken::decode_header(&token).unwrap();
        assert_eq!(header.alg, Algorithm::RS256);
        assert_eq!(header.kid.as_deref(), Some(kid.as_str()));

        let mut v = Validation::new(Algorithm::RS256);
        v.set_issuer(&[BASE]);
        v.set_audience(&[TEST_CLIENT_ID]);
        let claims = jsonwebtoken::decode::<IdTokenClaims>(&token, &key, &v)
            .expect("signature must verify against the JWKS")
            .claims;

        assert_eq!(claims.iss, "http://sso.imamreza.ir");
        assert_eq!(claims.aud, TEST_CLIENT_ID);
        assert_eq!(claims.sub, user.id);
        assert_eq!(claims.email, user.email);
        assert!(claims.email_verified);
        assert_eq!(claims.name, user.name);
        assert_eq!(claims.preferred_username, user.preferred_username);
        assert_eq!(claims.nonce.as_deref(), Some("n-0S6_WzA2Mj"));
        assert_eq!(claims.iat, now);
        assert_eq!(claims.exp, now + TOKEN_TTL_SECS);
    }

    #[test]
    fn id_token_rejected_with_wrong_audience_or_issuer() {
        let state = test_state();
        let now = util::now_secs();
        let token =
            issue_id_token(&state.keys, BASE, TEST_CLIENT_ID, &test_user(), None, now, now).unwrap();
        let (key, _) = key_from_jwks(state.keys.jwks());

        let mut v = Validation::new(Algorithm::RS256);
        v.set_issuer(&[BASE]);
        v.set_audience(&["someone-else"]);
        assert!(jsonwebtoken::decode::<IdTokenClaims>(&token, &key, &v).is_err());

        let mut v = Validation::new(Algorithm::RS256);
        v.set_issuer(&["http://evil.example"]);
        v.set_audience(&[TEST_CLIENT_ID]);
        assert!(jsonwebtoken::decode::<IdTokenClaims>(&token, &key, &v).is_err());
    }

    #[test]
    fn nonce_is_omitted_when_absent() {
        let state = test_state();
        let now = util::now_secs();
        let token =
            issue_id_token(&state.keys, BASE, TEST_CLIENT_ID, &test_user(), None, now, now).unwrap();
        let payload = token.split('.').nth(1).unwrap();
        let raw = base64_decode(payload);
        let v: serde_json::Value = serde_json::from_slice(&raw).unwrap();
        assert!(v.get("nonce").is_none());
    }

    fn base64_decode(s: &str) -> Vec<u8> {
        use base64::Engine;
        base64::engine::general_purpose::URL_SAFE_NO_PAD.decode(s).unwrap()
    }

    #[test]
    fn access_token_roundtrip_and_misuse() {
        let state = test_state();
        let now = util::now_secs();
        let at = issue_access_token(&state.keys, BASE, TEST_CLIENT_ID, "u_1", "openid email", now).unwrap();
        let c = verify_access_token(&state.keys, BASE, &at, now).unwrap();
        assert_eq!(c.sub, "u_1");
        // expired
        assert!(verify_access_token(&state.keys, BASE, &at, now + TOKEN_TTL_SECS + 1).is_none());
        // wrong issuer
        assert!(verify_access_token(&state.keys, "http://other", &at, now).is_none());
        // an id_token is not an access token
        let idt = issue_id_token(&state.keys, BASE, TEST_CLIENT_ID, &test_user(), None, now, now).unwrap();
        assert!(verify_access_token(&state.keys, BASE, &idt, now).is_none());
        // garbage
        assert!(verify_access_token(&state.keys, BASE, "not.a.jwt", now).is_none());
    }
}
