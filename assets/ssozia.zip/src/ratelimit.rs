//! In-memory fixed-window rate limiter for failed login attempts, plus
//! real-client-IP detection.

use std::collections::HashMap;
use std::net::{IpAddr, SocketAddr};
use std::sync::Mutex;

use axum::http::HeaderMap;

/// Maximum number of failed attempts per key per window.
pub const MAX_FAILURES: u32 = 10;
/// Window length: 5 minutes.
pub const WINDOW_SECS: i64 = 5 * 60;

const MAX_TRACKED_KEYS: usize = 10_000;

pub struct RateLimiter {
    max: u32,
    window: i64,
    // key -> (window start, failures in window)
    inner: Mutex<HashMap<String, (i64, u32)>>,
}

impl RateLimiter {
    pub fn new(max: u32, window_secs: i64) -> Self {
        Self {
            max,
            window: window_secs,
            inner: Mutex::new(HashMap::new()),
        }
    }

    pub fn standard() -> Self {
        Self::new(MAX_FAILURES, WINDOW_SECS)
    }

    /// True when `key` has used up its attempts in the current window.
    pub fn is_blocked(&self, key: &str, now: i64) -> bool {
        let map = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        match map.get(key) {
            Some(&(start, count)) if now - start < self.window => count >= self.max,
            _ => false,
        }
    }

    pub fn record_failure(&self, key: &str, now: i64) {
        let mut map = self.inner.lock().unwrap_or_else(|e| e.into_inner());
        if map.len() >= MAX_TRACKED_KEYS {
            let window = self.window;
            map.retain(|_, (start, _)| now - *start < window);
        }
        let entry = map.entry(key.to_string()).or_insert((now, 0));
        if now - entry.0 >= self.window {
            *entry = (now, 0);
        }
        entry.1 += 1;
    }
}

/// The real client IP. Caddy REPLACES X-Forwarded-For with `{remote_host}` (header_up),
/// so the leftmost value is trustworthy; fall back to the socket peer.
pub fn client_ip(headers: &HeaderMap, peer: Option<SocketAddr>) -> String {
    if let Some(v) = headers.get("x-forwarded-for").and_then(|v| v.to_str().ok()) {
        if let Some(first) = v.split(',').next() {
            if let Ok(ip) = first.trim().parse::<IpAddr>() {
                return ip.to_string();
            }
        }
    }
    match peer {
        Some(addr) => addr.ip().to_string(),
        None => "unknown".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::http::HeaderValue;

    #[test]
    fn blocks_after_max_failures_and_resets_after_window() {
        let rl = RateLimiter::new(3, 300);
        for _ in 0..3 {
            assert!(!rl.is_blocked("k", 1000));
            rl.record_failure("k", 1000);
        }
        assert!(rl.is_blocked("k", 1000));
        assert!(rl.is_blocked("k", 1299));
        assert!(!rl.is_blocked("k", 1300));
        assert!(!rl.is_blocked("other", 1000));
        rl.record_failure("k", 1301);
        assert!(!rl.is_blocked("k", 1301));
    }

    #[test]
    fn leftmost_forwarded_for_wins() {
        let mut h = HeaderMap::new();
        h.insert("x-forwarded-for", HeaderValue::from_static("203.0.113.9, 10.0.0.1"));
        let peer: SocketAddr = "172.18.0.2:5555".parse().unwrap();
        assert_eq!(client_ip(&h, Some(peer)), "203.0.113.9");
        assert_eq!(client_ip(&HeaderMap::new(), Some(peer)), "172.18.0.2");
        assert_eq!(client_ip(&HeaderMap::new(), None), "unknown");

        let mut bad = HeaderMap::new();
        bad.insert("x-forwarded-for", HeaderValue::from_static("garbage"));
        assert_eq!(client_ip(&bad, Some(peer)), "172.18.0.2");
    }
}
