//! GET /authorize (Authorization Code flow with PKCE S256)

use axum::extract::{RawQuery, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::Response;

use crate::auth;
use crate::grant;
use crate::login_page;
use crate::pkce;
use crate::state::AppState;
use crate::util;

/// Errors that must NOT be redirected to the client (the client_id or
/// redirect_uri is not trustworthy) are shown to the user instead.
fn bad_request(detail: &str) -> Response {
    util::html_response(
        StatusCode::BAD_REQUEST,
        login_page::render_message(
            "درخواست نامعتبر",
            "درخواست ورود نامعتبر است و امکان ادامه وجود ندارد.",
            Some(detail),
        ),
        None,
    )
}

/// Errors reported back to the (already validated) redirect_uri.
fn error_redirect(redirect_uri: &str, state: Option<&str>, error: &str, description: &str) -> Response {
    let mut pairs = vec![("error", error), ("error_description", description)];
    if let Some(s) = state {
        pairs.push(("state", s));
    }
    util::redirect(&util::append_query(redirect_uri, &pairs), None)
}

pub async fn authorize(
    State(state): State<AppState>,
    RawQuery(raw): RawQuery,
    headers: HeaderMap,
) -> Response {
    let raw = raw.unwrap_or_default();
    let params = util::parse_query(&raw);
    let get = |key: &str| params.get(key).map(String::as_str);

    // 1. client_id and redirect_uri first: only after both are valid may we
    //    redirect errors back to the client.
    let Some(client_id) = get("client_id").filter(|s| !s.is_empty()) else {
        return bad_request("client_id is required");
    };
    let Some(client) = state.clients.get(client_id).await else {
        return bad_request("unknown client_id");
    };
    let Some(redirect_uri) = get("redirect_uri") else {
        return bad_request("redirect_uri is required");
    };
    if !grant::redirect_uri_matches(&client.redirect_uris, redirect_uri) {
        return bad_request("redirect_uri is not registered for this client");
    }
    let oauth_state = get("state");

    // 2. response_type and scope
    if get("response_type") != Some("code") {
        return error_redirect(
            redirect_uri,
            oauth_state,
            "unsupported_response_type",
            "only response_type=code is supported",
        );
    }
    let scope = get("scope").unwrap_or("");
    if !scope.split_whitespace().any(|s| s == "openid") {
        return error_redirect(redirect_uri, oauth_state, "invalid_scope", "scope must contain openid");
    }

    // 3. PKCE: S256 only, "plain" is always rejected.
    let challenge = get("code_challenge").filter(|s| !s.is_empty());
    let method = get("code_challenge_method");
    let code_challenge = match challenge {
        Some(c) => {
            if method != Some("S256") {
                return error_redirect(
                    redirect_uri,
                    oauth_state,
                    "invalid_request",
                    "code_challenge_method must be S256",
                );
            }
            if !pkce::is_valid_challenge(c) {
                return error_redirect(
                    redirect_uri,
                    oauth_state,
                    "invalid_request",
                    "code_challenge is malformed",
                );
            }
            Some(c.to_string())
        }
        None => {
            if method.is_some() {
                return error_redirect(
                    redirect_uri,
                    oauth_state,
                    "invalid_request",
                    "code_challenge_method given without code_challenge",
                );
            }
            if client.require_pkce {
                return error_redirect(
                    redirect_uri,
                    oauth_state,
                    "invalid_request",
                    "code_challenge is required (PKCE with S256)",
                );
            }
            None
        }
    };

    // 4. Is there an SSO session? If not, show the login page and carry the
    //    original query string along in a hidden field.
    let session = auth::current_session(&state, &headers).await;
    let user = match &session {
        Some(s) => state.users.find_by_id(&s.user_id).await,
        None => None,
    };
    let (Some(session), Some(user)) = (session, user) else {
        return util::html_response(
            StatusCode::OK,
            login_page::render_login(state.base_url(), &util::normalize_query(&raw), None, ""),
            None,
        );
    };

    // 5. Issue the code and send the browser back to the client.
    let now = util::now_secs();
    let nonce = get("nonce").filter(|s| !s.is_empty()).map(str::to_string);
    let code = grant::issue_code(
        state.codes.as_ref(),
        grant::new_grant(
            &client.client_id,
            redirect_uri,
            &user.id,
            code_challenge,
            nonce,
            scope,
            session.created_at,
            now,
        ),
    )
    .await;

    let mut pairs = vec![("code", code.as_str())];
    if let Some(s) = oauth_state {
        pairs.push(("state", s));
    }
    util::redirect(&util::append_query(redirect_uri, &pairs), None)
}
