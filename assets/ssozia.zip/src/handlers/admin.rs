//! /admin: connect other systems (OIDC clients) and generate their keys.
//!
//! - Only users with `is_admin = true` in users.toml may use it. Anyone else
//!   gets the login page (not signed in) or a 403 page.
//! - Every POST needs a CSRF token derived from the session.
//! - A client secret is generated here (32 random bytes, hex), shown ONCE and
//!   stored only as an argon2id hash.
//! - Clients created here live in DATA_DIR/clients-admin.json; clients from
//!   clients.toml are listed but read-only.

use axum::extract::{Form, Path, RawQuery, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::Response;
use serde::Deserialize;

use crate::admin_page::{self, Flash, Prefill};
use crate::auth;
use crate::login_page;
use crate::state::AppState;
use crate::stores::{Client, Session, User};
use crate::util;

// ---------------------------------------------------------------------------
// Access control
// ---------------------------------------------------------------------------

async fn require_admin(state: &AppState, headers: &HeaderMap) -> Result<(Session, User), Response> {
    let session = auth::current_session(state, headers).await;
    let user = match &session {
        Some(s) => state.users.find_by_id(&s.user_id).await,
        None => None,
    };
    let (Some(session), Some(user)) = (session, user) else {
        // Not signed in: show the login page. An empty authorize query makes
        // /login continue to /admin.
        return Err(util::html_response(
            StatusCode::OK,
            login_page::render_login(state.base_url(), "", None, ""),
            None,
        ));
    };
    if !user.is_admin {
        return Err(util::html_response(
            StatusCode::FORBIDDEN,
            login_page::render_message(
                "دسترسی ندارید",
                "حساب شما اجازه‌ی مدیریت اتصال سیستم‌ها را ندارد.",
                None,
            ),
            None,
        ));
    }
    Ok((session, user))
}

fn csrf_failed() -> Response {
    util::html_response(
        StatusCode::FORBIDDEN,
        login_page::render_message(
            "درخواست نامعتبر",
            "نشست شما منقضی شده یا درخواست معتبر نیست. صفحه را دوباره باز کنید.",
            Some("invalid CSRF token"),
        ),
        None,
    )
}

fn csrf_ok(state: &AppState, session: &Session, given: &str) -> bool {
    let expected = auth::csrf_token(&state.csrf_secret, &session.id);
    util::ct_eq(expected.as_bytes(), given.as_bytes())
}

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

fn valid_client_id(id: &str) -> bool {
    !id.is_empty()
        && id.len() <= 64
        && id
            .bytes()
            .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit() || b == b'-' || b == b'_')
}

/// One absolute http(s) URI per line. Matching at /authorize is byte for
/// byte, so values are stored exactly as typed (only trimmed).
fn parse_uri_lines(text: &str, what: &str) -> Result<Vec<String>, String> {
    let mut out: Vec<String> = Vec::new();
    for line in text.lines() {
        let uri = line.trim();
        if uri.is_empty() {
            continue;
        }
        let ok_scheme = uri.starts_with("http://") || uri.starts_with("https://");
        let bad_char = uri.chars().any(|c| c.is_whitespace() || c.is_control()) || uri.contains('#');
        if !ok_scheme || bad_char || uri.len() > 2048 {
            return Err(format!(
                "{what} نامعتبر است: «{uri}». باید آدرس کامل http:// یا https:// بدون فاصله و بدون # باشد."
            ));
        }
        if !out.iter().any(|u| u == uri) {
            out.push(uri.to_string());
        }
    }
    Ok(out)
}

// ---------------------------------------------------------------------------
// Handlers
// ---------------------------------------------------------------------------

async fn dashboard_page(
    state: &AppState,
    session: &Session,
    user: &User,
    status: StatusCode,
    flash: Option<Flash<'_>>,
    prefill: &Prefill,
) -> Response {
    let csrf = auth::csrf_token(&state.csrf_secret, &session.id);
    let clients = state.clients.list().await;
    util::html_response(
        status,
        admin_page::render_dashboard(state.base_url(), &user.name, &csrf, &clients, flash, prefill),
        None,
    )
}

/// GET /admin
pub async fn dashboard(
    State(state): State<AppState>,
    RawQuery(raw): RawQuery,
    headers: HeaderMap,
) -> Response {
    let (session, user) = match require_admin(&state, &headers).await {
        Ok(x) => x,
        Err(r) => return r,
    };
    let params = util::parse_query(&raw.unwrap_or_default());
    let prefill = match params.get("preset").map(String::as_str) {
        Some("outline") => Prefill::outline(),
        _ => Prefill::blank(),
    };
    dashboard_page(&state, &session, &user, StatusCode::OK, None, &prefill).await
}

#[derive(Debug, Deserialize)]
pub struct CreateForm {
    #[serde(default)]
    pub csrf: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub client_id: String,
    #[serde(default)]
    pub redirect_uris: String,
    #[serde(default)]
    pub post_logout_redirect_uris: String,
    #[serde(default)]
    pub require_pkce: Option<String>,
}

/// Validate the "new connection" form: returns (redirect_uris, post_logout_redirect_uris).
async fn validate_create(
    state: &AppState,
    client_id: &str,
    form: &CreateForm,
) -> Result<(Vec<String>, Vec<String>), String> {
    if !valid_client_id(client_id) {
        return Err("شناسه نامعتبر است: فقط حروف کوچک انگلیسی، عدد، «-» و «_» (حداکثر ۶۴ نویسه).".to_string());
    }
    let redirect_uris = parse_uri_lines(&form.redirect_uris, "آدرس بازگشت پس از ورود")?;
    if redirect_uris.is_empty() {
        return Err("حداقل یک آدرس بازگشت پس از ورود لازم است.".to_string());
    }
    let post_logout = parse_uri_lines(&form.post_logout_redirect_uris, "آدرس بازگشت پس از خروج")?;
    if state.clients.get(client_id).await.is_some() {
        return Err(format!("سیستمی با شناسه «{client_id}» از قبل وجود دارد."));
    }
    Ok((redirect_uris, post_logout))
}

/// POST /admin/clients
pub async fn create(
    State(state): State<AppState>,
    headers: HeaderMap,
    Form(form): Form<CreateForm>,
) -> Response {
    let (session, user) = match require_admin(&state, &headers).await {
        Ok(x) => x,
        Err(r) => return r,
    };
    if !csrf_ok(&state, &session, &form.csrf) {
        return csrf_failed();
    }

    let client_id = form.client_id.trim().to_string();
    let prefill = Prefill {
        name: form.name.clone(),
        client_id: client_id.clone(),
        redirect_uris: form.redirect_uris.clone(),
        post_logout_redirect_uris: form.post_logout_redirect_uris.clone(),
        require_pkce: form.require_pkce.is_some(),
    };
    let (redirect_uris, post_logout) = match validate_create(&state, &client_id, &form).await {
        Ok(v) => v,
        Err(msg) => {
            return dashboard_page(
                &state,
                &session,
                &user,
                StatusCode::BAD_REQUEST,
                Some(Flash::Err(&msg)),
                &prefill,
            )
            .await;
        }
    };

    let secret = util::random_hex(32);
    let Ok(hash) = auth::hash_password(&secret) else {
        tracing::error!("hashing a new client secret failed");
        return util::html_response(
            StatusCode::INTERNAL_SERVER_ERROR,
            login_page::render_message("خطا", "ساخت کلید با خطا روبه‌رو شد.", None),
            None,
        );
    };
    let name = form.name.trim();
    let client = Client {
        client_id: client_id.clone(),
        name: if name.is_empty() { client_id.clone() } else { name.to_string() },
        client_secret_hash: hash,
        redirect_uris,
        post_logout_redirect_uris: post_logout,
        require_pkce: form.require_pkce.is_some(),
        admin_api: false,
        dynamic: true,
    };
    if let Err(e) = state.clients.upsert(client.clone()).await {
        tracing::error!(error = %e, "saving a new client failed");
        return dashboard_page(
            &state,
            &session,
            &user,
            StatusCode::INTERNAL_SERVER_ERROR,
            Some(Flash::Err("ذخیره‌ی اتصال با خطا روبه‌رو شد.")),
            &prefill,
        )
        .await;
    }
    tracing::info!(admin = %user.id, client_id = %client_id, "client created");
    util::html_response(
        StatusCode::OK,
        admin_page::render_secret(state.base_url(), &client, &secret, false),
        None,
    )
}

#[derive(Debug, Deserialize)]
pub struct CsrfForm {
    #[serde(default)]
    pub csrf: String,
}

/// POST /admin/clients/:id/rotate  (new secret; the old one stops working)
pub async fn rotate(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Form(form): Form<CsrfForm>,
) -> Response {
    let (session, user) = match require_admin(&state, &headers).await {
        Ok(x) => x,
        Err(r) => return r,
    };
    if !csrf_ok(&state, &session, &form.csrf) {
        return csrf_failed();
    }
    let blank = Prefill::blank();
    let Some(mut client) = state.clients.get(&id).await else {
        return dashboard_page(&state, &session, &user, StatusCode::NOT_FOUND, Some(Flash::Err("این سیستم پیدا نشد.")), &blank).await;
    };
    if !client.dynamic {
        return dashboard_page(
            &state,
            &session,
            &user,
            StatusCode::BAD_REQUEST,
            Some(Flash::Err("این سیستم در clients.toml تعریف شده و از اینجا قابل تغییر نیست.")),
            &blank,
        )
        .await;
    }
    let secret = util::random_hex(32);
    let Ok(hash) = auth::hash_password(&secret) else {
        return dashboard_page(&state, &session, &user, StatusCode::INTERNAL_SERVER_ERROR, Some(Flash::Err("ساخت کلید با خطا روبه‌رو شد.")), &blank).await;
    };
    client.client_secret_hash = hash;
    if let Err(e) = state.clients.upsert(client.clone()).await {
        tracing::error!(error = %e, "saving rotated client secret failed");
        return dashboard_page(&state, &session, &user, StatusCode::INTERNAL_SERVER_ERROR, Some(Flash::Err("ذخیره‌ی کلید جدید با خطا روبه‌رو شد.")), &blank).await;
    }
    tracing::info!(admin = %user.id, client_id = %client.client_id, "client secret rotated");
    util::html_response(
        StatusCode::OK,
        admin_page::render_secret(state.base_url(), &client, &secret, true),
        None,
    )
}

/// POST /admin/clients/:id/delete
pub async fn delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Form(form): Form<CsrfForm>,
) -> Response {
    let (session, user) = match require_admin(&state, &headers).await {
        Ok(x) => x,
        Err(r) => return r,
    };
    if !csrf_ok(&state, &session, &form.csrf) {
        return csrf_failed();
    }
    let blank = Prefill::blank();
    match state.clients.remove(&id).await {
        Ok(true) => {
            tracing::info!(admin = %user.id, client_id = %id, "client deleted");
            dashboard_page(&state, &session, &user, StatusCode::OK, Some(Flash::Ok("اتصال حذف شد.")), &blank).await
        }
        Ok(false) => {
            dashboard_page(&state, &session, &user, StatusCode::NOT_FOUND, Some(Flash::Err("این سیستم پیدا نشد.")), &blank).await
        }
        Err(_) => {
            dashboard_page(
                &state,
                &session,
                &user,
                StatusCode::BAD_REQUEST,
                Some(Flash::Err("این سیستم در clients.toml تعریف شده و از اینجا قابل حذف نیست.")),
                &blank,
            )
            .await
        }
    }
}

#[cfg(test)]
mod tests {
    use axum::body::Body;
    use axum::http::{header, Request, StatusCode};
    use axum::Router;
    use base64::engine::general_purpose::STANDARD;
    use base64::Engine;

    use crate::auth;
    use crate::handlers::router;
    use crate::state::test_support::*;
    use crate::state::AppState;
    use crate::stores::{InMemoryClientStore, ClientStore};
    use crate::util;

    const CSRF_SECRET: &str = "test-csrf-secret";

    async fn admin_session(state: &AppState, user_id: &str) -> (String, String) {
        let s = state.sessions.create(user_id, util::now_secs(), 3600).await;
        (
            format!("ssozia_session={}", s.id),
            auth::csrf_token(CSRF_SECRET, &s.id),
        )
    }

    fn get(uri: &str, cookie: Option<&str>) -> Request<Body> {
        let mut b = Request::get(uri);
        if let Some(c) = cookie {
            b = b.header(header::COOKIE, c);
        }
        b.body(Body::empty()).unwrap()
    }

    fn post(uri: &str, cookie: Option<&str>, pairs: &[(&str, &str)]) -> Request<Body> {
        let mut b = Request::post(uri).header(header::CONTENT_TYPE, "application/x-www-form-urlencoded");
        if let Some(c) = cookie {
            b = b.header(header::COOKIE, c);
        }
        b.body(Body::from(util::encode_query(pairs))).unwrap()
    }

    fn create_pairs<'a>(csrf: &'a str, id: &'a str) -> Vec<(&'a str, &'a str)> {
        vec![
            ("csrf", csrf),
            ("name", "Wiki"),
            ("client_id", id),
            ("redirect_uris", "http://wiki.imamreza.ir/callback"),
            ("post_logout_redirect_uris", "http://wiki.imamreza.ir"),
            ("require_pkce", "on"),
        ]
    }

    fn extract_secret(html: &str) -> String {
        let marker = r#"<code id="client-secret">"#;
        let start = html.find(marker).expect("secret in page") + marker.len();
        let end = html[start..].find("</code>").unwrap();
        html[start..start + end].to_string()
    }

    async fn body_string(app: &Router, req: Request<Body>) -> (StatusCode, String) {
        let (status, _, body) = send(app, req).await;
        (status, String::from_utf8(body).unwrap())
    }

    #[tokio::test]
    async fn anonymous_gets_the_login_page_and_non_admins_are_forbidden() {
        let state = test_state();
        let app = router(state.clone());

        let (status, html) = body_string(&app, get("/admin", None)).await;
        assert_eq!(status, StatusCode::OK);
        assert!(html.contains("authorize_query"));
        assert!(!html.contains("سیستم‌های متصل"));

        // a signed-in user who is not an admin
        let mut user = test_user();
        user.is_admin = false;
        let state2 = test_state_custom(vec![user], test_client());
        let app2 = router(state2.clone());
        let (cookie, csrf) = admin_session(&state2, "u_1").await;
        let (status, _) = body_string(&app2, get("/admin", Some(&cookie))).await;
        assert_eq!(status, StatusCode::FORBIDDEN);
        let (status, _) = body_string(&app2, post("/admin/clients", Some(&cookie), &create_pairs(&csrf, "wiki"))).await;
        assert_eq!(status, StatusCode::FORBIDDEN);
        assert!(state2.clients.get("wiki").await.is_none());

        // anonymous POST is not allowed either
        let (status, _) = body_string(&app, post("/admin/clients", None, &create_pairs("x", "wiki"))).await;
        assert_eq!(status, StatusCode::OK); // login page, nothing created
        assert!(state.clients.get("wiki").await.is_none());
    }

    #[tokio::test]
    async fn dashboard_lists_clients_and_outline_preset_prefills() {
        let state = test_state();
        let app = router(state.clone());
        let (cookie, _) = admin_session(&state, "u_1").await;
        let (status, html) = body_string(&app, get("/admin", Some(&cookie))).await;
        assert_eq!(status, StatusCode::OK);
        assert!(html.contains("سیستم‌های متصل"));
        assert!(html.contains("outline"));

        let (_, html) = body_string(&app, get("/admin?preset=outline", Some(&cookie))).await;
        assert!(html.contains("http://kms.imamreza.ir/auth/oidc.callback"));
    }

    #[tokio::test]
    async fn csrf_is_required() {
        let state = test_state();
        let app = router(state.clone());
        let (cookie, _) = admin_session(&state, "u_1").await;
        let (status, _) = body_string(&app, post("/admin/clients", Some(&cookie), &create_pairs("wrong", "wiki"))).await;
        assert_eq!(status, StatusCode::FORBIDDEN);
        assert!(state.clients.get("wiki").await.is_none());
        let (status, _) = body_string(&app, post("/admin/clients/outline/delete", Some(&cookie), &[("csrf", "wrong")])).await;
        assert_eq!(status, StatusCode::FORBIDDEN);
    }

    #[tokio::test]
    async fn created_client_gets_a_key_that_really_works_end_to_end() {
        let state = test_state();
        let app = router(state.clone());
        let (cookie, csrf) = admin_session(&state, "u_1").await;

        let (status, html) =
            body_string(&app, post("/admin/clients", Some(&cookie), &create_pairs(&csrf, "wiki"))).await;
        assert_eq!(status, StatusCode::OK);
        assert!(html.contains("OIDC_CLIENT_ID=wiki"));
        assert!(html.contains("OIDC_ISSUER_URL=http://sso.imamreza.ir"));
        let secret = extract_secret(&html);
        assert_eq!(secret.len(), 64);

        // stored hashed only, never in clear
        let stored = state.clients.get("wiki").await.unwrap();
        assert!(stored.dynamic && stored.require_pkce);
        assert!(stored.client_secret_hash.starts_with("$argon2id$"));
        assert!(!stored.client_secret_hash.contains(&secret));
        assert_eq!(stored.redirect_uris, vec!["http://wiki.imamreza.ir/callback".to_string()]);

        // full flow with the new client: authorize -> code -> token
        let (verifier, challenge) = pkce_pair();
        let query = util::encode_query(&[
            ("response_type", "code"),
            ("client_id", "wiki"),
            ("redirect_uri", "http://wiki.imamreza.ir/callback"),
            ("scope", "openid profile email"),
            ("state", "s1"),
            ("code_challenge", &challenge),
            ("code_challenge_method", "S256"),
        ]);
        let (status, headers, _) = send(&app, get(&format!("/authorize?{query}"), Some(&cookie))).await;
        assert_eq!(status, StatusCode::FOUND);
        let loc = headers[header::LOCATION].to_str().unwrap().to_string();
        assert!(loc.starts_with("http://wiki.imamreza.ir/callback?"));
        let code = util::parse_query(loc.split_once('?').unwrap().1).get("code").cloned().unwrap();

        let basic = STANDARD.encode(format!("wiki:{secret}"));
        let req = Request::post("/token")
            .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
            .header(header::AUTHORIZATION, format!("Basic {basic}"))
            .body(Body::from(util::encode_query(&[
                ("grant_type", "authorization_code"),
                ("code", &code),
                ("redirect_uri", "http://wiki.imamreza.ir/callback"),
                ("code_verifier", &verifier),
            ])))
            .unwrap();
        let (status, body) = body_string(&app, req).await;
        assert_eq!(status, StatusCode::OK, "{body}");
        assert!(body.contains("access_token"));

        // duplicate id is refused
        let (status, html) =
            body_string(&app, post("/admin/clients", Some(&cookie), &create_pairs(&csrf, "wiki"))).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert!(html.contains("از قبل وجود دارد"));
    }

    #[tokio::test]
    async fn invalid_input_is_rejected_and_nothing_is_created() {
        let state = test_state();
        let app = router(state.clone());
        let (cookie, csrf) = admin_session(&state, "u_1").await;

        for (id, uris) in [
            ("Bad Id", "http://a.example/cb"),
            ("", "http://a.example/cb"),
            ("okid", ""),
            ("okid", "ftp://a.example/cb"),
            ("okid", "http://a.example/cb#frag"),
            ("okid", "javascript:alert(1)"),
            ("okid", "http://a.example/c b"),
        ] {
            let (status, _) = body_string(
                &app,
                post(
                    "/admin/clients",
                    Some(&cookie),
                    &[("csrf", &csrf), ("client_id", id), ("redirect_uris", uris)],
                ),
            )
            .await;
            assert_eq!(status, StatusCode::BAD_REQUEST, "id={id:?} uris={uris:?}");
        }
        assert!(state.clients.get("okid").await.is_none());
        assert_eq!(state.clients.list().await.len(), 1);
    }

    #[tokio::test]
    async fn rotate_replaces_the_secret_and_delete_removes_the_client() {
        let state = test_state();
        let app = router(state.clone());
        let (cookie, csrf) = admin_session(&state, "u_1").await;

        let (_, html) = body_string(&app, post("/admin/clients", Some(&cookie), &create_pairs(&csrf, "wiki"))).await;
        let old_secret = extract_secret(&html);

        let (status, html) =
            body_string(&app, post("/admin/clients/wiki/rotate", Some(&cookie), &[("csrf", &csrf)])).await;
        assert_eq!(status, StatusCode::OK);
        let new_secret = extract_secret(&html);
        assert_ne!(old_secret, new_secret);
        assert!(auth::authenticate_client(state.clients.as_ref(), "wiki", &old_secret).await.is_none());
        assert!(auth::authenticate_client(state.clients.as_ref(), "wiki", &new_secret).await.is_some());

        // clients from clients.toml are read-only
        for path in ["/admin/clients/outline/rotate", "/admin/clients/outline/delete"] {
            let (status, _) = body_string(&app, post(path, Some(&cookie), &[("csrf", &csrf)])).await;
            assert_eq!(status, StatusCode::BAD_REQUEST, "{path}");
        }
        assert!(state.clients.get("outline").await.is_some());

        let (status, _) =
            body_string(&app, post("/admin/clients/wiki/delete", Some(&cookie), &[("csrf", &csrf)])).await;
        assert_eq!(status, StatusCode::OK);
        assert!(state.clients.get("wiki").await.is_none());
        let (status, _) =
            body_string(&app, post("/admin/clients/wiki/delete", Some(&cookie), &[("csrf", &csrf)])).await;
        assert_eq!(status, StatusCode::NOT_FOUND);
    }

    #[tokio::test]
    async fn admin_created_clients_survive_a_restart() {
        let dir = std::env::temp_dir().join(format!("ssozia-admintest-{}", util::random_token(8)));
        let path = dir.join("clients-admin.json");
        let missing_toml = dir.join("clients.toml");

        let store = InMemoryClientStore::new(vec![]).unwrap().with_persistence(path.clone());
        let mut c = test_client();
        c.client_id = "wiki".to_string();
        store.upsert(c).await.unwrap();

        let reloaded = crate::stores::load_clients(&missing_toml, &path).unwrap();
        let got = reloaded.get("wiki").await.expect("persisted client is loaded");
        assert!(got.dynamic);
        assert_eq!(got.redirect_uris, vec![TEST_REDIRECT_URI.to_string()]);

        reloaded.remove("wiki").await.unwrap();
        let again = crate::stores::load_clients(&missing_toml, &path).unwrap();
        assert!(again.get("wiki").await.is_none());
        let _ = std::fs::remove_dir_all(&dir);
    }
}
