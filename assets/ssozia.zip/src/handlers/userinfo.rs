//! GET /userinfo (Bearer access token)
//! VERSION: ssozia 0.2.0 (2026-10-12) - adds "positions" from the organization chart

use axum::extract::State;
use axum::http::{header, HeaderMap, HeaderValue, StatusCode};
use axum::response::Response;
use serde_json::json;

use crate::state::AppState;
use crate::tokens;
use crate::util;

fn unauthorized(www_authenticate: &'static str) -> Response {
    let mut resp = util::json_response(
        StatusCode::UNAUTHORIZED,
        &json!({ "error": "invalid_token" }),
    );
    resp.headers_mut()
        .insert(header::WWW_AUTHENTICATE, HeaderValue::from_static(www_authenticate));
    resp
}

fn bearer_token(headers: &HeaderMap) -> Option<&str> {
    let value = headers.get(header::AUTHORIZATION)?.to_str().ok()?.trim();
    if value.len() > 7 && value[..7].eq_ignore_ascii_case("bearer ") {
        let token = value[7..].trim();
        if !token.is_empty() {
            return Some(token);
        }
    }
    None
}

pub async fn userinfo(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let Some(token) = bearer_token(&headers) else {
        return unauthorized("Bearer");
    };
    let Some(claims) =
        tokens::verify_access_token(&state.keys, state.base_url(), token, util::now_secs())
    else {
        return unauthorized(r#"Bearer error="invalid_token""#);
    };
    let Some(user) = state.users.find_by_id(&claims.sub).await else {
        return unauthorized(r#"Bearer error="invalid_token""#);
    };
    let positions: Vec<serde_json::Value> = state
        .org
        .positions_of(&user.id)
        .into_iter()
        .map(|(p, primary)| json!({ "id": p.id, "title": p.title, "unit": p.unit, "primary": primary }))
        .collect();
    util::json_response(
        StatusCode::OK,
        &json!({
            "sub": user.id,
            "email": user.email,
            "email_verified": true,
            "name": user.name,
            "preferred_username": user.preferred_username,
            "positions": positions,
        }),
    )
}
