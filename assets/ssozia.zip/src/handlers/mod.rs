//! HTTP handlers and the router. All routes live at the ROOT of the host.
//! VERSION: ssozia 0.2.0 (2026-10-12) - /admin/api/* (users, organization chart)

use axum::routing::{get, post};
use axum::Router;

use crate::state::AppState;

pub mod admin;
pub mod admin_api;
pub mod authorize;
pub mod discovery;
pub mod health;
pub mod jwks;
pub mod login;
pub mod logout;
pub mod token;
pub mod userinfo;

pub fn router(state: AppState) -> Router {
    Router::new()
        .route("/.well-known/openid-configuration", get(discovery::discovery))
        .route("/.well-known/jwks.json", get(jwks::jwks))
        .route("/jwks", get(jwks::jwks))
        .route("/authorize", get(authorize::authorize))
        .route("/login", post(login::login))
        .route("/token", post(token::token))
        .route("/userinfo", get(userinfo::userinfo))
        .route("/logout", get(logout::logout))
        .route("/health", get(health::health))
        .route("/admin", get(admin::dashboard))
        .route("/admin/clients", post(admin::create))
        .route("/admin/clients/:id/rotate", post(admin::rotate))
        .route("/admin/clients/:id/delete", post(admin::delete))
        .route("/admin/api/users", get(admin_api::users_list).post(admin_api::users_create))
        .route("/admin/api/users/:id", post(admin_api::users_update))
        .route("/admin/api/users/:id/password", post(admin_api::users_password))
        .route("/admin/api/users/:id/status", post(admin_api::users_status))
        .route("/admin/api/org", get(admin_api::org_get))
        .route("/admin/api/org/positions", post(admin_api::org_position_create))
        .route("/admin/api/org/positions/:id", post(admin_api::org_position_update))
        .route("/admin/api/org/positions/:id/delete", post(admin_api::org_position_delete))
        .route("/admin/api/org/assign", post(admin_api::org_assign))
        .route("/admin/api/org/unassign", post(admin_api::org_unassign))
        .with_state(state)
}

/// In-process end-to-end tests of the whole flow through the real router.
#[cfg(test)]
mod tests {
    use axum::body::Body;
    use axum::http::{header, HeaderMap, Request, StatusCode};
    use axum::Router;
    use base64::engine::general_purpose::STANDARD;
    use base64::Engine;
    use jsonwebtoken::{Algorithm, DecodingKey, Validation};
    use serde_json::Value;

    use super::router;
    use crate::state::test_support::*;
    use crate::tokens::IdTokenClaims;
    use crate::util;

    fn authorize_query(challenge: Option<&str>, method: &str) -> String {
        let mut pairs = vec![
            ("response_type", "code"),
            ("client_id", TEST_CLIENT_ID),
            ("redirect_uri", TEST_REDIRECT_URI),
            ("scope", "openid profile email"),
            ("state", "st-123"),
            ("nonce", "nonce-456"),
        ];
        if let Some(c) = challenge {
            pairs.push(("code_challenge", c));
            pairs.push(("code_challenge_method", method));
        }
        util::encode_query(&pairs)
    }

    fn post_form(uri: &str, pairs: &[(&str, &str)]) -> Request<Body> {
        Request::post(uri)
            .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
            .body(Body::from(util::encode_query(pairs)))
            .unwrap()
    }

    fn get_with_cookie(uri: &str, cookie: Option<&str>) -> Request<Body> {
        let mut b = Request::get(uri);
        if let Some(c) = cookie {
            b = b.header(header::COOKIE, c);
        }
        b.body(Body::empty()).unwrap()
    }

    fn location(headers: &HeaderMap) -> String {
        headers[header::LOCATION].to_str().unwrap().to_string()
    }

    /// "ssozia_session=<id>" taken from a Set-Cookie header.
    fn session_cookie(headers: &HeaderMap) -> String {
        headers[header::SET_COOKIE]
            .to_str()
            .unwrap()
            .split(';')
            .next()
            .unwrap()
            .to_string()
    }

    fn query_param(url: &str, key: &str) -> Option<String> {
        let query = url.split_once('?')?.1;
        util::parse_query(query).get(key).cloned()
    }

    /// POST /login and return the session cookie plus the /authorize path.
    async fn login(app: &Router, query: &str) -> (String, String) {
        let (status, headers, _) = send(
            app,
            post_form(
                "/login",
                &[("email", TEST_EMAIL), ("password", TEST_PASSWORD), ("authorize_query", query)],
            ),
        )
        .await;
        assert_eq!(status, StatusCode::FOUND);
        let loc = location(&headers);
        let path = loc.strip_prefix(BASE).expect("absolute URL built from PUBLIC_BASE_URL");
        (session_cookie(&headers), path.to_string())
    }

    /// Full login + authorize, returning the authorization code.
    async fn get_code(app: &Router, challenge: &str) -> (String, String) {
        let query = authorize_query(Some(challenge), "S256");
        let (cookie, path) = login(app, &query).await;
        let (status, headers, _) = send(app, get_with_cookie(&path, Some(&cookie))).await;
        assert_eq!(status, StatusCode::FOUND);
        let loc = location(&headers);
        assert!(loc.starts_with(TEST_REDIRECT_URI));
        assert_eq!(query_param(&loc, "state").as_deref(), Some("st-123"));
        (query_param(&loc, "code").expect("code in redirect"), cookie)
    }

    fn token_request_basic(code: &str, verifier: &str) -> Request<Body> {
        let basic = STANDARD.encode(format!("{TEST_CLIENT_ID}:{TEST_CLIENT_SECRET}"));
        Request::post("/token")
            .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
            .header(header::AUTHORIZATION, format!("Basic {basic}"))
            .body(Body::from(util::encode_query(&[
                ("grant_type", "authorization_code"),
                ("code", code),
                ("redirect_uri", TEST_REDIRECT_URI),
                ("code_verifier", verifier),
            ])))
            .unwrap()
    }

    fn json_body(body: &[u8]) -> Value {
        serde_json::from_slice(body).unwrap()
    }

    #[tokio::test]
    async fn full_flow_login_token_userinfo() {
        let app = router(test_state());
        let (verifier, challenge) = pkce_pair();

        // 1. no session: the Persian RTL login page, query kept in a hidden field
        let query = authorize_query(Some(&challenge), "S256");
        let (status, headers, body) =
            send(&app, get_with_cookie(&format!("/authorize?{query}"), None)).await;
        assert_eq!(status, StatusCode::OK);
        assert!(headers[header::CONTENT_TYPE].to_str().unwrap().starts_with("text/html"));
        let html = String::from_utf8(body).unwrap();
        assert!(html.contains(r#"dir="rtl" lang="fa""#));
        assert!(html.contains(r#"action="http://sso.imamreza.ir/login""#));
        assert!(html.contains("authorize_query"));
        assert!(html.contains("client_id=outline"));

        // 2. login sets the cookie and continues the flow
        let (status, headers, _) = send(
            &app,
            post_form(
                "/login",
                &[("email", TEST_EMAIL), ("password", TEST_PASSWORD), ("authorize_query", &query)],
            ),
        )
        .await;
        assert_eq!(status, StatusCode::FOUND);
        let set_cookie = headers[header::SET_COOKIE].to_str().unwrap().to_string();
        assert!(set_cookie.starts_with("ssozia_session="));
        assert!(set_cookie.contains("HttpOnly"));
        assert!(set_cookie.contains("SameSite=Lax"));
        assert!(set_cookie.contains("Path=/"));
        assert!(!set_cookie.contains("Secure"));
        assert!(!set_cookie.contains("Domain"));
        let cookie = session_cookie(&headers);
        let loc = location(&headers);
        assert!(loc.starts_with("http://sso.imamreza.ir/authorize?"));

        // 3. /authorize with the session: 302 to the registered redirect_uri
        let path = loc.strip_prefix(BASE).unwrap();
        let (status, headers, _) = send(&app, get_with_cookie(path, Some(&cookie))).await;
        assert_eq!(status, StatusCode::FOUND);
        let loc = location(&headers);
        assert!(loc.starts_with("http://kms.imamreza.ir/auth/oidc.callback?"));
        assert_eq!(query_param(&loc, "state").as_deref(), Some("st-123"));
        let code = query_param(&loc, "code").unwrap();

        // 4. /token
        let (status, _, body) = send(&app, token_request_basic(&code, &verifier)).await;
        assert_eq!(status, StatusCode::OK);
        let tok = json_body(&body);
        assert_eq!(tok["token_type"], "Bearer");
        assert_eq!(tok["expires_in"], 3600);
        let id_token = tok["id_token"].as_str().unwrap();
        let access_token = tok["access_token"].as_str().unwrap();

        // 5. id_token verifies against the JWKS the server really serves
        let (status, _, body) = send(&app, get_with_cookie("/jwks", None)).await;
        assert_eq!(status, StatusCode::OK);
        let jwks = json_body(&body);
        let (_, _, body2) = send(&app, get_with_cookie("/.well-known/jwks.json", None)).await;
        assert_eq!(jwks, json_body(&body2));
        let k = &jwks["keys"][0];
        let key = DecodingKey::from_rsa_components(k["n"].as_str().unwrap(), k["e"].as_str().unwrap()).unwrap();
        let mut v = Validation::new(Algorithm::RS256);
        v.set_issuer(&[BASE]);
        v.set_audience(&[TEST_CLIENT_ID]);
        let claims = jsonwebtoken::decode::<IdTokenClaims>(id_token, &key, &v).unwrap().claims;
        assert_eq!(claims.sub, "u_1");
        assert_eq!(claims.nonce.as_deref(), Some("nonce-456"));
        assert_eq!(claims.email, TEST_EMAIL);

        // 6. /userinfo
        let req = Request::get("/userinfo")
            .header(header::AUTHORIZATION, format!("Bearer {access_token}"))
            .body(Body::empty())
            .unwrap();
        let (status, _, body) = send(&app, req).await;
        assert_eq!(status, StatusCode::OK);
        let ui = json_body(&body);
        assert_eq!(ui["sub"], "u_1");
        assert_eq!(ui["email"], TEST_EMAIL);
        assert_eq!(ui["email_verified"], true);
        assert_eq!(ui["name"], "Admin");
        assert_eq!(ui["preferred_username"], "admin");
    }

    #[tokio::test]
    async fn token_endpoint_accepts_client_secret_post() {
        let app = router(test_state());
        let (verifier, challenge) = pkce_pair();
        let (code, _) = get_code(&app, &challenge).await;
        let (status, _, body) = send(
            &app,
            post_form(
                "/token",
                &[
                    ("grant_type", "authorization_code"),
                    ("code", &code),
                    ("redirect_uri", TEST_REDIRECT_URI),
                    ("code_verifier", &verifier),
                    ("client_id", TEST_CLIENT_ID),
                    ("client_secret", TEST_CLIENT_SECRET),
                ],
            ),
        )
        .await;
        assert_eq!(status, StatusCode::OK, "{}", String::from_utf8_lossy(&body));
        assert!(json_body(&body)["access_token"].is_string());
    }

    #[tokio::test]
    async fn token_endpoint_rejects_bad_client_auth() {
        let app = router(test_state());
        let (verifier, challenge) = pkce_pair();
        let (code, _) = get_code(&app, &challenge).await;
        let (status, headers, body) = send(
            &app,
            post_form(
                "/token",
                &[
                    ("grant_type", "authorization_code"),
                    ("code", &code),
                    ("redirect_uri", TEST_REDIRECT_URI),
                    ("code_verifier", &verifier),
                    ("client_id", TEST_CLIENT_ID),
                    ("client_secret", "wrong"),
                ],
            ),
        )
        .await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);
        assert_eq!(json_body(&body)["error"], "invalid_client");
        assert!(headers.get(header::WWW_AUTHENTICATE).is_none());

        // no credentials at all
        let (status, _, _) = send(&app, post_form("/token", &[("grant_type", "authorization_code")])).await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn wrong_password_is_rejected_without_a_session() {
        let app = router(test_state());
        let query = authorize_query(Some(&pkce_pair().1), "S256");
        for (email, password) in [
            (TEST_EMAIL, "wrong password"),
            ("nobody@example.com", TEST_PASSWORD),
        ] {
            let (status, headers, body) = send(
                &app,
                post_form(
                    "/login",
                    &[("email", email), ("password", password), ("authorize_query", &query)],
                ),
            )
            .await;
            assert_eq!(status, StatusCode::UNAUTHORIZED);
            assert!(headers.get(header::SET_COOKIE).is_none());
            assert!(headers.get(header::LOCATION).is_none());
            let html = String::from_utf8(body).unwrap();
            assert!(html.contains("ایمیل یا رمز عبور اشتباه است."));
            assert!(html.contains("client_id=outline"), "flow state is preserved");
        }
    }

    #[tokio::test]
    async fn wrong_redirect_uri_is_rejected_even_with_a_session() {
        let app = router(test_state());
        let (_, challenge) = pkce_pair();
        let (_, cookie) = get_code(&app, &challenge).await;
        for bad in [
            "http://kms.imamreza.ir/auth/oidc.callback/",
            "http://evil.example/auth/oidc.callback",
            "http://kms.imamreza.ir/auth/oidc.callback?x=1",
        ] {
            let query = util::encode_query(&[
                ("response_type", "code"),
                ("client_id", TEST_CLIENT_ID),
                ("redirect_uri", bad),
                ("scope", "openid"),
                ("code_challenge", &challenge),
                ("code_challenge_method", "S256"),
            ]);
            let (status, headers, _) =
                send(&app, get_with_cookie(&format!("/authorize?{query}"), Some(&cookie))).await;
            assert_eq!(status, StatusCode::BAD_REQUEST, "{bad}");
            assert!(headers.get(header::LOCATION).is_none(), "never redirect to {bad}");
        }
        // unknown client
        let (status, _, _) =
            send(&app, get_with_cookie("/authorize?client_id=nope&redirect_uri=x", None)).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn reused_code_is_rejected() {
        let app = router(test_state());
        let (verifier, challenge) = pkce_pair();
        let (code, _) = get_code(&app, &challenge).await;
        let (status, _, _) = send(&app, token_request_basic(&code, &verifier)).await;
        assert_eq!(status, StatusCode::OK);
        let (status, _, body) = send(&app, token_request_basic(&code, &verifier)).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json_body(&body)["error"], "invalid_grant");
    }

    #[tokio::test]
    async fn wrong_pkce_verifier_is_rejected() {
        let app = router(test_state());
        let (_, challenge) = pkce_pair();
        let (code, _) = get_code(&app, &challenge).await;
        let wrong = "A".repeat(64);
        let (status, _, body) = send(&app, token_request_basic(&code, &wrong)).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        assert_eq!(json_body(&body)["error"], "invalid_grant");
    }

    #[tokio::test]
    async fn pkce_rules_at_authorize() {
        let app = router(test_state());
        let (_, challenge) = pkce_pair();
        let (_, cookie) = get_code(&app, &challenge).await;

        // "plain" is always rejected, via redirect with error
        let q = authorize_query(Some(&challenge), "plain");
        let (status, headers, _) =
            send(&app, get_with_cookie(&format!("/authorize?{q}"), Some(&cookie))).await;
        assert_eq!(status, StatusCode::FOUND);
        assert_eq!(query_param(&location(&headers), "error").as_deref(), Some("invalid_request"));
        assert_eq!(query_param(&location(&headers), "state").as_deref(), Some("st-123"));

        // missing challenge is rejected when the client requires PKCE
        let q = authorize_query(None, "");
        let (_, headers, _) = send(&app, get_with_cookie(&format!("/authorize?{q}"), Some(&cookie))).await;
        assert_eq!(query_param(&location(&headers), "error").as_deref(), Some("invalid_request"));

        // ... but allowed when require_pkce = false for this client
        let mut client = test_client();
        client.require_pkce = false;
        let lax = router(test_state_with_client(client));
        let (cookie2, _) = {
            let query = authorize_query(None, "");
            login(&lax, &query).await
        };
        let (status, headers, _) =
            send(&lax, get_with_cookie(&format!("/authorize?{q}"), Some(&cookie2))).await;
        assert_eq!(status, StatusCode::FOUND);
        assert!(query_param(&location(&headers), "code").is_some());
    }

    #[tokio::test]
    async fn bad_response_type_and_scope_are_reported_to_the_client() {
        let app = router(test_state());
        let (_, challenge) = pkce_pair();
        let base = |extra: (&str, &str)| {
            util::encode_query(&[
                ("client_id", TEST_CLIENT_ID),
                ("redirect_uri", TEST_REDIRECT_URI),
                ("code_challenge", &challenge),
                ("code_challenge_method", "S256"),
                extra,
            ])
        };
        let q = format!("{}&scope=openid", base(("response_type", "token")));
        let (status, headers, _) = send(&app, get_with_cookie(&format!("/authorize?{q}"), None)).await;
        assert_eq!(status, StatusCode::FOUND);
        assert_eq!(
            query_param(&location(&headers), "error").as_deref(),
            Some("unsupported_response_type")
        );

        let q = format!("{}&response_type=code", base(("scope", "profile email")));
        let (_, headers, _) = send(&app, get_with_cookie(&format!("/authorize?{q}"), None)).await;
        assert_eq!(query_param(&location(&headers), "error").as_deref(), Some("invalid_scope"));
    }

    #[tokio::test]
    async fn login_is_rate_limited_per_ip_and_per_email() {
        let state = test_state();
        let app = router(state);
        let attempt = |email: &str, password: &str, ip: &str| {
            Request::post("/login")
                .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
                .header("x-forwarded-for", ip.to_string())
                .body(Body::from(util::encode_query(&[
                    ("email", email),
                    ("password", password),
                    ("authorize_query", ""),
                ])))
                .unwrap()
        };

        // 10 failures from one IP (different emails) block that IP
        for i in 0..10 {
            let (status, _, _) = send(&app, attempt(&format!("x{i}@example.com"), "bad", "198.51.100.7")).await;
            assert_eq!(status, StatusCode::UNAUTHORIZED);
        }
        let (status, _, _) = send(&app, attempt(TEST_EMAIL, TEST_PASSWORD, "198.51.100.7")).await;
        assert_eq!(status, StatusCode::TOO_MANY_REQUESTS);
        // another IP is unaffected
        let (status, _, _) = send(&app, attempt(TEST_EMAIL, TEST_PASSWORD, "198.51.100.8")).await;
        assert_eq!(status, StatusCode::FOUND);

        // 10 failures against one email (from different IPs) block that email
        for i in 0..10 {
            let (status, _, _) =
                send(&app, attempt("victim@example.com", "bad", &format!("203.0.113.{}", i + 1))).await;
            assert_eq!(status, StatusCode::UNAUTHORIZED);
        }
        let (status, _, _) = send(&app, attempt("victim@example.com", "bad", "203.0.113.200")).await;
        assert_eq!(status, StatusCode::TOO_MANY_REQUESTS);
    }

    #[tokio::test]
    async fn userinfo_requires_a_valid_access_token() {
        let app = router(test_state());
        let (status, headers, _) = send(&app, get_with_cookie("/userinfo", None)).await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);
        assert!(headers.contains_key(header::WWW_AUTHENTICATE));

        let req = Request::get("/userinfo")
            .header(header::AUTHORIZATION, "Bearer garbage")
            .body(Body::empty())
            .unwrap();
        let (status, _, _) = send(&app, req).await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);

        // an id_token must not work as a bearer token
        let (verifier, challenge) = pkce_pair();
        let (code, _) = get_code(&app, &challenge).await;
        let (_, _, body) = send(&app, token_request_basic(&code, &verifier)).await;
        let id_token = json_body(&body)["id_token"].as_str().unwrap().to_string();
        let req = Request::get("/userinfo")
            .header(header::AUTHORIZATION, format!("Bearer {id_token}"))
            .body(Body::empty())
            .unwrap();
        let (status, _, _) = send(&app, req).await;
        assert_eq!(status, StatusCode::UNAUTHORIZED);
    }

    #[tokio::test]
    async fn health_is_ok() {
        let app = router(test_state());
        let (status, _, body) = send(&app, get_with_cookie("/health", None)).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(body, b"ok");
    }

    #[tokio::test]
    async fn logout_after_login_ends_the_sso_session() {
        let app = router(test_state());
        let (_, challenge) = pkce_pair();
        let (_, cookie) = get_code(&app, &challenge).await;

        // logged in: /authorize hands out a code without showing the login page
        let q = authorize_query(Some(&challenge), "S256");
        let (status, _, _) = send(&app, get_with_cookie(&format!("/authorize?{q}"), Some(&cookie))).await;
        assert_eq!(status, StatusCode::FOUND);

        let (status, _, _) = send(
            &app,
            get_with_cookie(
                "/logout?client_id=outline&post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir",
                Some(&cookie),
            ),
        )
        .await;
        assert_eq!(status, StatusCode::FOUND);

        // the old cookie no longer works: login page again
        let (status, _, body) = send(&app, get_with_cookie(&format!("/authorize?{q}"), Some(&cookie))).await;
        assert_eq!(status, StatusCode::OK);
        assert!(String::from_utf8(body).unwrap().contains("authorize_query"));
    }
}
