//! GET /jwks and GET /.well-known/jwks.json

use axum::extract::State;
use axum::http::{header, HeaderValue, StatusCode};
use axum::response::Response;

use crate::state::AppState;
use crate::util;

pub async fn jwks(State(state): State<AppState>) -> Response {
    let mut resp = util::json_response(StatusCode::OK, state.keys.jwks());
    resp.headers_mut().insert(
        header::CACHE_CONTROL,
        HeaderValue::from_static("public, max-age=300"),
    );
    resp.headers_mut().remove(header::PRAGMA);
    resp
}
