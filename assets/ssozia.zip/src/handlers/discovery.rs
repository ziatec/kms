//! GET /.well-known/openid-configuration

use axum::extract::State;
use axum::http::StatusCode;
use axum::response::Response;
use serde_json::{json, Value};

use crate::state::AppState;
use crate::util;

/// The discovery document. Every URL is built from the public base URL.
/// `code_challenge_methods_supported` MUST contain "S256" (Outline only
/// enables PKCE then) and `end_session_endpoint` MUST be present (without
/// it Outline never calls /logout).
pub fn document(base: &str) -> Value {
    json!({
        "issuer": base,
        "authorization_endpoint": format!("{base}/authorize"),
        "token_endpoint": format!("{base}/token"),
        "userinfo_endpoint": format!("{base}/userinfo"),
        "jwks_uri": format!("{base}/jwks"),
        "end_session_endpoint": format!("{base}/logout"),
        "response_types_supported": ["code"],
        "grant_types_supported": ["authorization_code"],
        "subject_types_supported": ["public"],
        "id_token_signing_alg_values_supported": ["RS256"],
        "scopes_supported": ["openid", "profile", "email"],
        "token_endpoint_auth_methods_supported": ["client_secret_basic", "client_secret_post"],
        "code_challenge_methods_supported": ["S256"]
    })
}

pub async fn discovery(State(state): State<AppState>) -> Response {
    util::json_response(StatusCode::OK, &document(state.base_url()))
}

#[cfg(test)]
mod tests {
    use axum::body::Body;
    use axum::http::Request;
    use serde_json::json;

    use super::*;
    use crate::handlers::router;
    use crate::state::test_support::*;

    #[tokio::test]
    async fn discovery_document_is_exact() {
        let app = router(test_state());
        let req = Request::get("/.well-known/openid-configuration")
            .body(Body::empty())
            .unwrap();
        let (status, _, body) = send(&app, req).await;
        assert_eq!(status, 200);
        let doc: Value = serde_json::from_slice(&body).unwrap();

        assert_eq!(doc["issuer"], "http://sso.imamreza.ir");
        assert_eq!(doc["code_challenge_methods_supported"], json!(["S256"]));
        assert_eq!(doc["end_session_endpoint"], "http://sso.imamreza.ir/logout");
        assert_eq!(doc["authorization_endpoint"], "http://sso.imamreza.ir/authorize");
        assert_eq!(doc["token_endpoint"], "http://sso.imamreza.ir/token");
        assert_eq!(doc["userinfo_endpoint"], "http://sso.imamreza.ir/userinfo");
        assert_eq!(doc["jwks_uri"], "http://sso.imamreza.ir/jwks");
        assert_eq!(doc["response_types_supported"], json!(["code"]));
        assert_eq!(doc["grant_types_supported"], json!(["authorization_code"]));
        assert_eq!(doc["subject_types_supported"], json!(["public"]));
        assert_eq!(doc["id_token_signing_alg_values_supported"], json!(["RS256"]));
        assert_eq!(doc["scopes_supported"], json!(["openid", "profile", "email"]));
        assert_eq!(
            doc["token_endpoint_auth_methods_supported"],
            json!(["client_secret_basic", "client_secret_post"])
        );
        // Outline's manual-mode endpoints must not leak into discovery as extras.
        assert_eq!(doc.as_object().unwrap().len(), 13);
    }

    #[test]
    fn urls_follow_the_configured_base() {
        let doc = document("https://sso.example.org");
        assert_eq!(doc["issuer"], "https://sso.example.org");
        assert_eq!(doc["end_session_endpoint"], "https://sso.example.org/logout");
    }
}
