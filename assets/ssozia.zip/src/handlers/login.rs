//! POST /login
//! VERSION: ssozia 0.2.0 (2026-10-12) - sign in with email or user name (Persian allowed)

use std::net::SocketAddr;

use axum::extract::{ConnectInfo, Form, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::Response;
use serde::Deserialize;

use crate::auth;
use crate::login_page;
use crate::ratelimit;
use crate::state::AppState;
use crate::util;

#[derive(Debug, Deserialize)]
pub struct LoginForm {
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub password: String,
    /// The original /authorize query string (hidden form field).
    #[serde(default)]
    pub authorize_query: String,
}

const MSG_BAD_CREDENTIALS: &str = "نام کاربری، ایمیل یا رمز عبور اشتباه است.";
const MSG_RATE_LIMITED: &str = "تلاش بیش از حد مجاز بود. لطفاً چند دقیقه بعد دوباره امتحان کنید.";

pub async fn login(
    State(state): State<AppState>,
    headers: HeaderMap,
    connect: Option<ConnectInfo<SocketAddr>>,
    Form(form): Form<LoginForm>,
) -> Response {
    let now = util::now_secs();
    let ip = ratelimit::client_ip(&headers, connect.map(|c| c.0));
    // The "email" field takes an email or a user name.
    let email_norm: String = crate::stores::normalize_username(&form.email).chars().take(254).collect();
    let ip_key = format!("ip:{ip}");
    let email_key = format!("email:{email_norm}");
    let query = util::normalize_query(&form.authorize_query);

    let page = |status: StatusCode, error: &str| {
        util::html_response(
            status,
            login_page::render_login(state.base_url(), &query, Some(error), &form.email),
            None,
        )
    };

    if state.limiter.is_blocked(&ip_key, now) || state.limiter.is_blocked(&email_key, now) {
        tracing::warn!(%ip, "login blocked by rate limiter");
        return page(StatusCode::TOO_MANY_REQUESTS, MSG_RATE_LIMITED);
    }

    let user = state.users.find_by_login(&email_norm).await;
    let ok = auth::verify_password_or_dummy(
        &form.password,
        user.as_ref().map(|u| u.password_hash.as_str()),
    );
    let user = match (ok, user) {
        (true, Some(u)) => u,
        _ => {
            state.limiter.record_failure(&ip_key, now);
            state.limiter.record_failure(&email_key, now);
            tracing::info!(%ip, "login failed");
            return page(StatusCode::UNAUTHORIZED, MSG_BAD_CREDENTIALS);
        }
    };

    // Replace any previous session (avoids session fixation).
    if let Some(old) = util::get_cookie(&headers, &state.config.cookie_name) {
        state.sessions.delete(&old).await;
    }
    let session = state
        .sessions
        .create(&user.id, now, auth::SESSION_TTL_SECS)
        .await;
    let cookie = util::cookie_header(
        &state.config.cookie_name,
        &session.id,
        state.config.cookie_secure,
        auth::SESSION_TTL_SECS,
    );
    tracing::info!(%ip, user = %user.id, "login succeeded");

    // Continue the original authorize request, or open /admin when the login
    // page was shown by /admin (no authorize query).
    let location = if query.is_empty() {
        format!("{}/admin", state.base_url())
    } else {
        format!("{}/authorize?{}", state.base_url(), query)
    };
    util::redirect(&location, Some(&cookie))
}
