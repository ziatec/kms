//! GET /health

use axum::http::{header, StatusCode};
use axum::response::{IntoResponse, Response};

pub async fn health() -> Response {
    (
        StatusCode::OK,
        [(header::CONTENT_TYPE, "text/plain; charset=utf-8")],
        "ok",
    )
        .into_response()
}
