//! POST /token (authorization_code grant)

use std::collections::HashMap;

use axum::body::Bytes;
use axum::extract::State;
use axum::http::{header, HeaderMap, HeaderValue, StatusCode};
use axum::response::Response;
use serde_json::json;

use crate::auth::{self, ClientAuthMethod};
use crate::grant;
use crate::state::AppState;
use crate::tokens;
use crate::util;

fn oauth_error(status: StatusCode, error: &str, description: &str) -> Response {
    util::json_response(
        status,
        &json!({ "error": error, "error_description": description }),
    )
}

fn invalid_client(basic: bool) -> Response {
    let mut resp = oauth_error(
        StatusCode::UNAUTHORIZED,
        "invalid_client",
        "client authentication failed",
    );
    if basic {
        resp.headers_mut().insert(
            header::WWW_AUTHENTICATE,
            HeaderValue::from_static(r#"Basic realm="ssozia""#),
        );
    }
    resp
}

pub async fn token(State(state): State<AppState>, headers: HeaderMap, body: Bytes) -> Response {
    let form: HashMap<String, String> = util::parse_query(&String::from_utf8_lossy(&body));

    // Client authentication: client_secret_basic and client_secret_post.
    let Ok(creds) = auth::extract_client_credentials(&headers, &form) else {
        return invalid_client(headers.contains_key(header::AUTHORIZATION));
    };
    let basic = creds.method == ClientAuthMethod::Basic;
    let Some(client) =
        auth::authenticate_client(state.clients.as_ref(), &creds.client_id, &creds.client_secret).await
    else {
        return invalid_client(basic);
    };

    if form.get("grant_type").map(String::as_str) != Some("authorization_code") {
        return oauth_error(
            StatusCode::BAD_REQUEST,
            "unsupported_grant_type",
            "only authorization_code is supported",
        );
    }
    let (Some(code), Some(redirect_uri)) = (
        form.get("code").filter(|s| !s.is_empty()),
        form.get("redirect_uri"),
    ) else {
        return oauth_error(
            StatusCode::BAD_REQUEST,
            "invalid_request",
            "code and redirect_uri are required",
        );
    };

    let now = util::now_secs();
    let grant = match grant::redeem_code(
        state.codes.as_ref(),
        code,
        &client,
        redirect_uri,
        form.get("code_verifier").map(String::as_str),
        now,
    )
    .await
    {
        Ok(g) => g,
        Err(e) => return oauth_error(StatusCode::BAD_REQUEST, "invalid_grant", e.0),
    };

    let Some(user) = state.users.find_by_id(&grant.user_id).await else {
        return oauth_error(StatusCode::BAD_REQUEST, "invalid_grant", "user no longer exists");
    };

    let issuer = state.base_url();
    let id_token = tokens::issue_id_token(
        &state.keys,
        issuer,
        &client.client_id,
        &user,
        grant.nonce.as_deref(),
        grant.auth_time,
        now,
    );
    let access_token =
        tokens::issue_access_token(&state.keys, issuer, &client.client_id, &user.id, &grant.scope, now);
    let (Ok(id_token), Ok(access_token)) = (id_token, access_token) else {
        tracing::error!("token signing failed");
        return oauth_error(
            StatusCode::INTERNAL_SERVER_ERROR,
            "server_error",
            "could not issue tokens",
        );
    };

    util::json_response(
        StatusCode::OK,
        &json!({
            "access_token": access_token,
            "id_token": id_token,
            "token_type": "Bearer",
            "expires_in": tokens::TOKEN_TTL_SECS,
            "scope": grant.scope,
        }),
    )
}
