//! GET /logout (RP-initiated logout, as used by Outline)

use axum::extract::{RawQuery, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::Response;

use crate::grant;
use crate::login_page;
use crate::state::AppState;
use crate::util;

/// Ends the SSO session (always), then either redirects back to a
/// registered post_logout_redirect_uri or shows a "logged out" page.
///
/// - `id_token_hint` is accepted and ignored (validation is step 2).
/// - Nothing here ever answers 400: unknown or missing parameters simply
///   fall through to the "logged out" page.
/// - `post_logout_redirect_uri` must match one registered for `client_id`
///   byte-for-byte; Outline sends env.URL exactly, without a trailing slash.
pub async fn logout(
    State(state): State<AppState>,
    RawQuery(raw): RawQuery,
    headers: HeaderMap,
) -> Response {
    let params = util::parse_query(&raw.unwrap_or_default());

    // End the SSO session and clear the cookie, whatever else happens.
    if let Some(id) = util::get_cookie(&headers, &state.config.cookie_name) {
        state.sessions.delete(&id).await;
    }
    let clear = util::cookie_header(
        &state.config.cookie_name,
        "",
        state.config.cookie_secure,
        0,
    );

    let target = match (
        params.get("client_id").filter(|s| !s.is_empty()),
        params.get("post_logout_redirect_uri").filter(|s| !s.is_empty()),
    ) {
        (Some(client_id), Some(uri)) => match state.clients.get(client_id).await {
            Some(client) if grant::redirect_uri_matches(&client.post_logout_redirect_uris, uri) => {
                Some(uri.clone())
            }
            _ => None,
        },
        _ => None,
    };

    match target {
        Some(uri) => {
            // Echo `state` if a client ever sends one; Outline does not.
            let location = match params.get("state") {
                Some(s) if !s.is_empty() => util::append_query(&uri, &[("state", s.as_str())]),
                _ => uri,
            };
            util::redirect(&location, Some(&clear))
        }
        None => util::html_response(
            StatusCode::OK,
            login_page::render_message("خروج", "شما با موفقیت از حساب کاربری خارج شدید.", None),
            Some(&clear),
        ),
    }
}

#[cfg(test)]
mod tests {
    use axum::body::Body;
    use axum::http::{header, Request};

    use crate::handlers::router;
    use crate::state::test_support::*;
    use crate::util;

    fn get(uri: &str) -> Request<Body> {
        Request::get(uri).body(Body::empty()).unwrap()
    }

    #[tokio::test]
    async fn exact_post_logout_redirect_uri_redirects() {
        let app = router(test_state());
        let (status, headers, _) = send(
            &app,
            get("/logout?client_id=outline&post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir"),
        )
        .await;
        assert_eq!(status, 302);
        // exactly the registered string: no trailing slash added
        assert_eq!(headers[header::LOCATION], "http://kms.imamreza.ir");
    }

    #[tokio::test]
    async fn mismatched_uri_shows_logged_out_page() {
        let app = router(test_state());
        for uri in [
            "http%3A%2F%2Fkms.imamreza.ir%2F",    // trailing slash
            "http%3A%2F%2Fevil.example",          // different host
            "HTTP%3A%2F%2Fkms.imamreza.ir",       // different case
        ] {
            let (status, headers, body) = send(
                &app,
                get(&format!("/logout?client_id=outline&post_logout_redirect_uri={uri}")),
            )
            .await;
            assert_eq!(status, 200, "uri {uri}");
            assert!(headers.get(header::LOCATION).is_none());
            assert!(String::from_utf8(body).unwrap().contains("خارج شدید"));
        }
    }

    #[tokio::test]
    async fn unknown_client_or_missing_client_id_shows_page() {
        let app = router(test_state());
        let (status, headers, _) = send(
            &app,
            get("/logout?client_id=nobody&post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir"),
        )
        .await;
        assert_eq!(status, 200);
        assert!(headers.get(header::LOCATION).is_none());

        let (status, headers, _) = send(
            &app,
            get("/logout?post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir"),
        )
        .await;
        assert_eq!(status, 200);
        assert!(headers.get(header::LOCATION).is_none());
    }

    #[tokio::test]
    async fn missing_or_garbage_id_token_hint_never_fails() {
        let app = router(test_state());
        let (status, _, _) = send(&app, get("/logout")).await;
        assert_eq!(status, 200);
        let (status, _, _) = send(&app, get("/logout?id_token_hint=not-a-jwt&client_id=outline")).await;
        assert_eq!(status, 200);
        let (status, _, _) = send(
            &app,
            get("/logout?client_id=outline&id_token_hint=%%%&post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir"),
        )
        .await;
        assert_eq!(status, 302);
    }

    #[tokio::test]
    async fn logout_ends_the_session_and_clears_the_cookie() {
        let state = test_state();
        let session = state.sessions.create("u_1", util::now_secs(), 3600).await;
        let app = router(state.clone());

        let req = Request::get("/logout?client_id=outline&post_logout_redirect_uri=http%3A%2F%2Fkms.imamreza.ir")
            .header(header::COOKIE, format!("ssozia_session={}", session.id))
            .body(Body::empty())
            .unwrap();
        let (status, headers, _) = send(&app, req).await;
        assert_eq!(status, 302);
        let set_cookie = headers[header::SET_COOKIE].to_str().unwrap();
        assert!(set_cookie.starts_with("ssozia_session=;"));
        assert!(set_cookie.contains("Max-Age=0"));
        assert!(state.sessions.get(&session.id, util::now_secs()).await.is_none());
    }
}
