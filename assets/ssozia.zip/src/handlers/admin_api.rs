//! /admin/api/*: JSON admin API for users and the organization chart.
//! VERSION: ssozia 0.2.0 (2026-10-12)
//!
//! Used by the Outline plugin "ssozia-users" from Outline's server. Every
//! request must carry
//!   - the client credentials (HTTP Basic) of a client allowed to use the API
//!     (`admin_api = true`, or listed in ADMIN_API_CLIENTS, default "outline"),
//!   - `X-Ssozia-Actor: <email>` of an active ssozia user with is_admin = true
//!     (the admin signed in to Outline, which signs in through ssozia).
//! Users from users.toml are listed but read-only; users created here live in
//! DATA_DIR/users-admin.json, the chart in DATA_DIR/orgchart.json.

use std::collections::HashMap;

use axum::extract::{Path, State};
use axum::http::{HeaderMap, StatusCode};
use axum::response::Response;
use axum::Json;
use serde::Deserialize;
use serde_json::{json, Value};

use crate::auth;
use crate::org::PositionInput;
use crate::state::AppState;
use crate::stores::{normalize_email, normalize_username, valid_username, User};
use crate::util;

const ACTOR_HEADER: &str = "x-ssozia-actor";

fn err(status: StatusCode, message: &str) -> Response {
    util::json_response(status, &json!({ "error": message }))
}

fn ok(value: Value) -> Response {
    util::json_response(StatusCode::OK, &json!({ "data": value }))
}

/// Client credentials + actor check. Returns the acting admin.
async fn api_auth(state: &AppState, headers: &HeaderMap) -> Result<User, Response> {
    let now = util::now_secs();
    let Ok(creds) = auth::extract_client_credentials(headers, &HashMap::new()) else {
        return Err(err(StatusCode::UNAUTHORIZED, "client credentials required"));
    };
    let key = format!("api-client:{}", creds.client_id);
    if state.limiter.is_blocked(&key, now) {
        return Err(err(StatusCode::TOO_MANY_REQUESTS, "too many failed attempts"));
    }
    let Some(client) =
        auth::authenticate_client(state.clients.as_ref(), &creds.client_id, &creds.client_secret).await
    else {
        state.limiter.record_failure(&key, now);
        tracing::warn!(client_id = %creds.client_id, "admin API: invalid client credentials");
        return Err(err(StatusCode::UNAUTHORIZED, "invalid client credentials"));
    };
    let allowed = client.admin_api
        || state
            .config
            .admin_api_clients
            .iter()
            .any(|c| c == &client.client_id);
    if !allowed {
        return Err(err(StatusCode::FORBIDDEN, "this client may not use the admin API"));
    }
    let actor = headers
        .get(ACTOR_HEADER)
        .and_then(|v| v.to_str().ok())
        .map(str::trim)
        .unwrap_or("");
    match state.users.find_by_email(actor).await {
        Some(u) if u.is_admin => Ok(u),
        _ => Err(err(
            StatusCode::FORBIDDEN,
            "کاربر شما در ssozia مدیر (is_admin) و فعال نیست.",
        )),
    }
}

macro_rules! admin {
    ($state:expr, $headers:expr) => {
        match api_auth(&$state, &$headers).await {
            Ok(u) => u,
            Err(r) => return r,
        }
    };
}

fn present_user(state: &AppState, u: &User) -> Value {
    let positions: Vec<Value> = state
        .org
        .positions_of(&u.id)
        .into_iter()
        .map(|(p, primary)| json!({ "id": p.id, "title": p.title, "unit": p.unit, "primary": primary }))
        .collect();
    json!({
        "id": u.id,
        "email": u.email,
        "name": u.name,
        "preferred_username": u.preferred_username,
        "is_admin": u.is_admin,
        "disabled": u.disabled,
        "source": if u.dynamic { "managed" } else { "file" },
        "created_at": u.created_at,
        "updated_at": u.updated_at,
        "positions": positions,
    })
}

fn duplicate_message(e: &str) -> String {
    if e.contains("duplicate user email") {
        "این ایمیل برای کاربر دیگری ثبت شده است.".to_string()
    } else if e.contains("duplicate user name") {
        "این نام کاربری برای کاربر دیگری ثبت شده است.".to_string()
    } else if e.contains("users.toml") {
        "این کاربر در users.toml تعریف شده و از اینجا قابل تغییر نیست.".to_string()
    } else {
        tracing::error!(error = %e, "saving a user failed");
        "ذخیره‌ی کاربر با خطا روبه‌رو شد.".to_string()
    }
}

fn valid_email(email: &str) -> bool {
    let e = email.trim();
    e.len() <= 254
        && !e.chars().any(char::is_whitespace)
        && matches!(e.split_once('@'), Some((a, b)) if !a.is_empty() && b.contains('.') && !b.starts_with('.') && !b.ends_with('.'))
}

fn check_password(p: &str) -> Result<(), &'static str> {
    let n = p.chars().count();
    if n < 8 {
        return Err("رمز عبور باید حداقل ۸ نویسه باشد.");
    }
    if n > 256 {
        return Err("رمز عبور بیش از حد بلند است.");
    }
    Ok(())
}

// ---------------------------------------------------------------------------
// Users
// ---------------------------------------------------------------------------

/// GET /admin/api/users
pub async fn users_list(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let _actor = admin!(state, headers);
    let users = state.users.list().await;
    ok(Value::Array(users.iter().map(|u| present_user(&state, u)).collect()))
}

#[derive(Debug, Deserialize)]
pub struct UserForm {
    #[serde(default)]
    pub email: String,
    #[serde(default)]
    pub name: String,
    #[serde(default)]
    pub preferred_username: String,
    /// Required on create; ignored on update (use /password).
    #[serde(default)]
    pub password: String,
    #[serde(default)]
    pub is_admin: bool,
    #[serde(default)]
    pub disabled: bool,
}

/// Validated email, name and user name (normalized).
fn check_user_fields(f: &UserForm) -> Result<(String, String, String), String> {
    let email = f.email.trim().to_string();
    if !valid_email(&email) {
        return Err("ایمیل نامعتبر است.".to_string());
    }
    let name = f.name.trim().to_string();
    if name.is_empty() || name.chars().count() > 128 {
        return Err("نام لازم است (حداکثر ۱۲۸ نویسه).".to_string());
    }
    let username = normalize_username(&f.preferred_username);
    if !valid_username(&username) {
        return Err(
            "نام کاربری نامعتبر است: ۲ تا ۶۴ نویسه، حروف فارسی یا انگلیسی، عدد، «.»، «_»، «-» و نیم‌فاصله؛ بدون فاصله."
                .to_string(),
        );
    }
    Ok((email, name, username))
}

/// POST /admin/api/users  (create)
pub async fn users_create(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(form): Json<UserForm>,
) -> Response {
    let actor = admin!(state, headers);
    let (email, name, username) = match check_user_fields(&form) {
        Ok(v) => v,
        Err(m) => return err(StatusCode::BAD_REQUEST, &m),
    };
    if let Err(m) = check_password(&form.password) {
        return err(StatusCode::BAD_REQUEST, m);
    }
    let Ok(hash) = auth::hash_password(&form.password) else {
        return err(StatusCode::INTERNAL_SERVER_ERROR, "hashing the password failed");
    };
    let now = util::now_secs();
    let user = User {
        id: format!("u_{}", util::random_hex(8)),
        email: normalize_email(&email),
        name,
        preferred_username: username,
        password_hash: hash,
        is_admin: form.is_admin,
        disabled: form.disabled,
        created_at: now,
        updated_at: now,
        dynamic: true,
    };
    if let Err(e) = state.users.upsert(user.clone()).await {
        return err(StatusCode::CONFLICT, &duplicate_message(&e));
    }
    tracing::info!(admin = %actor.id, user = %user.id, "user created");
    ok(present_user(&state, &user))
}

/// Load a managed user for a change, or the error response.
async fn managed_user(state: &AppState, id: &str) -> Result<User, Response> {
    match state.users.get(id).await {
        None => Err(err(StatusCode::NOT_FOUND, "کاربر پیدا نشد.")),
        Some(u) if !u.dynamic => Err(err(
            StatusCode::BAD_REQUEST,
            "این کاربر در users.toml تعریف شده و از اینجا قابل تغییر نیست.",
        )),
        Some(u) => Ok(u),
    }
}

/// POST /admin/api/users/:id  (email, name, user name, admin flag)
pub async fn users_update(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Json(form): Json<UserForm>,
) -> Response {
    let actor = admin!(state, headers);
    let mut user = match managed_user(&state, &id).await {
        Ok(u) => u,
        Err(r) => return r,
    };
    let (email, name, username) = match check_user_fields(&form) {
        Ok(v) => v,
        Err(m) => return err(StatusCode::BAD_REQUEST, &m),
    };
    if user.id == actor.id && user.is_admin && !form.is_admin {
        return err(StatusCode::BAD_REQUEST, "نمی‌توانید دسترسی مدیر را از خودتان بگیرید.");
    }
    user.email = normalize_email(&email);
    user.name = name;
    user.preferred_username = username;
    user.is_admin = form.is_admin;
    user.updated_at = util::now_secs();
    if let Err(e) = state.users.upsert(user.clone()).await {
        return err(StatusCode::CONFLICT, &duplicate_message(&e));
    }
    tracing::info!(admin = %actor.id, user = %user.id, "user updated");
    ok(present_user(&state, &user))
}

#[derive(Debug, Deserialize)]
pub struct PasswordForm {
    pub password: String,
}

/// POST /admin/api/users/:id/password
pub async fn users_password(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Json(form): Json<PasswordForm>,
) -> Response {
    let actor = admin!(state, headers);
    let mut user = match managed_user(&state, &id).await {
        Ok(u) => u,
        Err(r) => return r,
    };
    if let Err(m) = check_password(&form.password) {
        return err(StatusCode::BAD_REQUEST, m);
    }
    let Ok(hash) = auth::hash_password(&form.password) else {
        return err(StatusCode::INTERNAL_SERVER_ERROR, "hashing the password failed");
    };
    user.password_hash = hash;
    user.updated_at = util::now_secs();
    if let Err(e) = state.users.upsert(user.clone()).await {
        return err(StatusCode::INTERNAL_SERVER_ERROR, &duplicate_message(&e));
    }
    tracing::info!(admin = %actor.id, user = %user.id, "user password set");
    ok(present_user(&state, &user))
}

#[derive(Debug, Deserialize)]
pub struct StatusForm {
    pub disabled: bool,
}

/// POST /admin/api/users/:id/status  (enable / disable)
pub async fn users_status(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Json(form): Json<StatusForm>,
) -> Response {
    let actor = admin!(state, headers);
    let mut user = match managed_user(&state, &id).await {
        Ok(u) => u,
        Err(r) => return r,
    };
    if user.id == actor.id && form.disabled {
        return err(StatusCode::BAD_REQUEST, "نمی‌توانید حساب خودتان را غیرفعال کنید.");
    }
    user.disabled = form.disabled;
    user.updated_at = util::now_secs();
    if let Err(e) = state.users.upsert(user.clone()).await {
        return err(StatusCode::INTERNAL_SERVER_ERROR, &duplicate_message(&e));
    }
    tracing::info!(admin = %actor.id, user = %user.id, disabled = form.disabled, "user status changed");
    ok(present_user(&state, &user))
}

// ---------------------------------------------------------------------------
// Organization chart
// ---------------------------------------------------------------------------

/// GET /admin/api/org
pub async fn org_get(State(state): State<AppState>, headers: HeaderMap) -> Response {
    let _actor = admin!(state, headers);
    ok(json!(state.org.snapshot()))
}

#[derive(Debug, Deserialize)]
pub struct PositionForm {
    #[serde(default)]
    pub title: String,
    #[serde(default)]
    pub parent_id: Option<String>,
    #[serde(default)]
    pub unit: String,
    #[serde(default)]
    pub description: String,
    #[serde(default)]
    pub sort: i64,
}

impl PositionForm {
    fn input(self) -> PositionInput {
        PositionInput {
            title: self.title,
            parent_id: self.parent_id.filter(|p| !p.trim().is_empty()),
            unit: self.unit,
            description: self.description,
            sort: self.sort,
        }
    }
}

fn org_result<T: serde::Serialize>(r: Result<T, String>) -> Response {
    match r {
        Ok(v) => ok(json!(v)),
        Err(m) => err(StatusCode::BAD_REQUEST, &m),
    }
}

/// POST /admin/api/org/positions
pub async fn org_position_create(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(form): Json<PositionForm>,
) -> Response {
    let actor = admin!(state, headers);
    let r = state.org.create_position(form.input());
    if let Ok(p) = &r {
        tracing::info!(admin = %actor.id, position = %p.id, "position created");
    }
    org_result(r)
}

/// POST /admin/api/org/positions/:id
pub async fn org_position_update(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
    Json(form): Json<PositionForm>,
) -> Response {
    let actor = admin!(state, headers);
    let r = state.org.update_position(&id, form.input());
    if r.is_ok() {
        tracing::info!(admin = %actor.id, position = %id, "position updated");
    }
    org_result(r)
}

/// POST /admin/api/org/positions/:id/delete
pub async fn org_position_delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
    headers: HeaderMap,
) -> Response {
    let actor = admin!(state, headers);
    let r = state.org.delete_position(&id);
    if r.is_ok() {
        tracing::info!(admin = %actor.id, position = %id, "position deleted");
    }
    org_result(r.map(|_| json!({ "deleted": true })))
}

#[derive(Debug, Deserialize)]
pub struct AssignForm {
    pub position_id: String,
    pub user_id: String,
    #[serde(default)]
    pub primary: bool,
}

/// POST /admin/api/org/assign
pub async fn org_assign(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(form): Json<AssignForm>,
) -> Response {
    let actor = admin!(state, headers);
    if state.users.get(&form.user_id).await.is_none() {
        return err(StatusCode::NOT_FOUND, "کاربر پیدا نشد.");
    }
    let r = state.org.assign(&form.position_id, &form.user_id, form.primary);
    if r.is_ok() {
        tracing::info!(admin = %actor.id, position = %form.position_id, user = %form.user_id, "user assigned");
    }
    org_result(r.map(|_| json!({ "assigned": true })))
}

/// POST /admin/api/org/unassign
pub async fn org_unassign(
    State(state): State<AppState>,
    headers: HeaderMap,
    Json(form): Json<AssignForm>,
) -> Response {
    let actor = admin!(state, headers);
    let r = state.org.unassign(&form.position_id, &form.user_id);
    if r.is_ok() {
        tracing::info!(admin = %actor.id, position = %form.position_id, user = %form.user_id, "user unassigned");
    }
    org_result(r.map(|removed| json!({ "removed": removed })))
}

#[cfg(test)]
mod tests {
    use axum::body::Body;
    use axum::http::{header, Request, StatusCode};
    use axum::Router;
    use base64::engine::general_purpose::STANDARD;
    use base64::Engine;
    use serde_json::Value;

    use crate::handlers::router;
    use crate::state::test_support::*;
    use crate::util;

    fn basic() -> String {
        format!("Basic {}", STANDARD.encode(format!("{TEST_CLIENT_ID}:{TEST_CLIENT_SECRET}")))
    }

    fn req(method: &str, uri: &str, actor: &str, body: Option<Value>) -> Request<Body> {
        let b = Request::builder()
            .method(method)
            .uri(uri)
            .header(header::AUTHORIZATION, basic())
            .header("x-ssozia-actor", actor)
            .header(header::CONTENT_TYPE, "application/json");
        b.body(Body::from(body.map(|v| v.to_string()).unwrap_or_default())).unwrap()
    }

    async fn call(app: &Router, r: Request<Body>) -> (StatusCode, Value) {
        let (status, _, body) = send(app, r).await;
        (status, serde_json::from_slice(&body).unwrap_or(Value::Null))
    }

    #[tokio::test]
    async fn credentials_and_admin_actor_are_required() {
        let app = router(test_state());
        let r = Request::get("/admin/api/users").body(Body::empty()).unwrap();
        assert_eq!(send(&app, r).await.0, StatusCode::UNAUTHORIZED);
        let (status, _) = call(&app, req("GET", "/admin/api/users", "nobody@example.com", None)).await;
        assert_eq!(status, StatusCode::FORBIDDEN);
        let (status, v) = call(&app, req("GET", "/admin/api/users", TEST_EMAIL, None)).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(v["data"][0]["source"], "file");
    }

    #[tokio::test]
    async fn persian_user_lifecycle_and_login() {
        let state = test_state();
        let app = router(state.clone());
        let new_user = serde_json::json!({
            "email": "Ali@Example.com", "name": "علی رضایی",
            "preferred_username": "علي.رضايي", "password": "a-long-password",
        });
        let (status, v) = call(&app, req("POST", "/admin/api/users", TEST_EMAIL, Some(new_user.clone()))).await;
        assert_eq!(status, StatusCode::OK, "{v}");
        let id = v["data"]["id"].as_str().unwrap().to_string();
        // Arabic yeh was stored as Persian yeh
        assert_eq!(v["data"]["preferred_username"], "علی.رضایی");
        // duplicate email / user name
        let (status, _) = call(&app, req("POST", "/admin/api/users", TEST_EMAIL, Some(new_user))).await;
        assert_eq!(status, StatusCode::CONFLICT);

        // sign in with the Persian user name typed with the Arabic layout
        let login = |name: &str| {
            Request::post("/login")
                .header(header::CONTENT_TYPE, "application/x-www-form-urlencoded")
                .body(Body::from(util::encode_query(&[
                    ("email", name),
                    ("password", "a-long-password"),
                    ("authorize_query", ""),
                ])))
                .unwrap()
        };
        assert_eq!(send(&app, login("علي.رضايي")).await.0, StatusCode::FOUND);
        assert_eq!(send(&app, login("ali@example.com")).await.0, StatusCode::FOUND);

        // disable: no more sign-in
        let (status, _) = call(&app, req("POST", &format!("/admin/api/users/{id}/status"), TEST_EMAIL, Some(serde_json::json!({"disabled": true})))).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(send(&app, login("ali@example.com")).await.0, StatusCode::UNAUTHORIZED);
        assert!(state.users.find_by_id(&id).await.is_none());

        // enable and set a new password
        call(&app, req("POST", &format!("/admin/api/users/{id}/status"), TEST_EMAIL, Some(serde_json::json!({"disabled": false})))).await;
        let (status, _) = call(&app, req("POST", &format!("/admin/api/users/{id}/password"), TEST_EMAIL, Some(serde_json::json!({"password": "short"})))).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        let (status, _) = call(&app, req("POST", &format!("/admin/api/users/{id}/password"), TEST_EMAIL, Some(serde_json::json!({"password": "another-long-one"})))).await;
        assert_eq!(status, StatusCode::OK);

        // users.toml users are read-only
        let (status, _) = call(&app, req("POST", "/admin/api/users/u_1/status", TEST_EMAIL, Some(serde_json::json!({"disabled": true})))).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
    }

    #[tokio::test]
    async fn org_chart_with_multiple_positions_per_user() {
        let app = router(test_state());
        let (_, v) = call(&app, req("POST", "/admin/api/org/positions", TEST_EMAIL, Some(serde_json::json!({"title": "مدیرعامل"})))).await;
        let ceo = v["data"]["id"].as_str().unwrap().to_string();
        let (_, v) = call(&app, req("POST", "/admin/api/org/positions", TEST_EMAIL, Some(serde_json::json!({"title": "معاون فنی", "parent_id": ceo})))).await;
        let cto = v["data"]["id"].as_str().unwrap().to_string();
        for (p, primary) in [(&ceo, true), (&cto, false)] {
            let (status, _) = call(&app, req("POST", "/admin/api/org/assign", TEST_EMAIL, Some(serde_json::json!({"position_id": p, "user_id": "u_1", "primary": primary})))).await;
            assert_eq!(status, StatusCode::OK);
        }
        let (_, v) = call(&app, req("GET", "/admin/api/users", TEST_EMAIL, None)).await;
        assert_eq!(v["data"][0]["positions"].as_array().unwrap().len(), 2);
        let (status, _) = call(&app, req("POST", &format!("/admin/api/org/positions/{ceo}/delete"), TEST_EMAIL, None)).await;
        assert_eq!(status, StatusCode::BAD_REQUEST);
        let (status, v) = call(&app, req("GET", "/admin/api/org", TEST_EMAIL, None)).await;
        assert_eq!(status, StatusCode::OK);
        assert_eq!(v["data"]["positions"].as_array().unwrap().len(), 2);
    }
}
