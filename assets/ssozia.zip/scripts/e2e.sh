#!/usr/bin/env bash
# End-to-end test of a RUNNING ssozia, using only bash, curl, jq, openssl and
# (optionally) python3 for the id_token signature check.
#
# Checks 10-11 need the E2E user to be an admin (is_admin = true in users.toml).
#
# Usage:
#   E2E_CLIENT_SECRET=<plaintext OIDC_CLIENT_SECRET> bash scripts/e2e.sh
#
# If E2E_CLIENT_SECRET is not set, OIDC_CLIENT_SECRET is read from ./outline.env.
#
# Settings (environment variables, defaults in brackets):
#   BASE                https://sso.imamreza.ir
#   EXPECT_ISSUER       https://sso.imamreza.ir
#   E2E_EMAIL           admin@example.com
#   E2E_PASSWORD        change-me
#   E2E_CLIENT_ID       outline
#   E2E_REDIRECT_URI    https://kms.imamreza.ir/auth/oidc.callback
#   E2E_EXPECT_SUB      u_1
#   E2E_EXPECT_USERNAME admin

set -u

BASE="${BASE:-https://sso.imamreza.ir}"
EXPECT_ISSUER="${EXPECT_ISSUER:-https://sso.imamreza.ir}"
EMAIL="${E2E_EMAIL:-admin@example.com}"
PASSWORD="${E2E_PASSWORD:-change-me}"
CLIENT_ID="${E2E_CLIENT_ID:-outline}"
REDIRECT_URI="${E2E_REDIRECT_URI:-https://kms.imamreza.ir/auth/oidc.callback}"
EXPECT_SUB="${E2E_EXPECT_SUB:-u_1}"
EXPECT_USERNAME="${E2E_EXPECT_USERNAME:-admin}"
CLIENT_SECRET="${E2E_CLIENT_SECRET:-}"

for tool in curl jq openssl; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "missing required tool: $tool" >&2
    exit 2
  fi
done

if [ -z "$CLIENT_SECRET" ] && [ -f outline.env ]; then
  CLIENT_SECRET="$(grep -E '^OIDC_CLIENT_SECRET=' outline.env | head -n1 | cut -d= -f2-)"
fi
if [ -z "$CLIENT_SECRET" ]; then
  echo "set E2E_CLIENT_SECRET (the plaintext OIDC client secret) or provide ./outline.env" >&2
  exit 2
fi

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

PASS_COUNT=0
FAIL_COUNT=0
SKIP_COUNT=0

pass() { PASS_COUNT=$((PASS_COUNT + 1)); echo "PASS  $1"; }
fail() { FAIL_COUNT=$((FAIL_COUNT + 1)); echo "FAIL  $1${2:+  ($2)}"; }
skip() { SKIP_COUNT=$((SKIP_COUNT + 1)); echo "SKIP  $1${2:+  ($2)}"; }

check_eq() { # name expected actual
  if [ "$2" = "$3" ]; then pass "$1"; else fail "$1" "expected '$2', got '$3'"; fi
}

urlencode() { jq -rn --arg v "$1" '$v|@uri'; }

b64url_nopad() { openssl base64 -A | tr '+/' '-_' | tr -d '='; }

# PKCE helpers
new_verifier() { openssl rand -hex 32; } # 64 chars, all unreserved
challenge_for() { printf %s "$1" | openssl dgst -sha256 -binary | b64url_nopad; }

# Header value from a curl -D dump (case-insensitive name, CR stripped).
header_value() { # file name
  grep -i "^$2:" "$1" | head -n1 | cut -d: -f2- | sed 's/^ *//' | tr -d '\r'
}
status_of() { head -n1 "$1" | awk '{print $2}'; }

authorize_query() { # challenge [state] [redirect_uri]
  local challenge="$1" state="${2:-st-$(openssl rand -hex 6)}" redirect="${3:-$REDIRECT_URI}"
  printf 'response_type=code&client_id=%s&redirect_uri=%s&scope=%s&state=%s&nonce=%s&code_challenge=%s&code_challenge_method=S256' \
    "$(urlencode "$CLIENT_ID")" "$(urlencode "$redirect")" "$(urlencode 'openid profile email')" \
    "$(urlencode "$state")" "$NONCE" "$challenge"
}

# POST /login. Writes headers to $TMP/login.h. Args: jar email password query
do_login() {
  curl -s -o "$TMP/login.body" -D "$TMP/login.h" -c "$1" -b "$1" \
    --data-urlencode "email=$2" --data-urlencode "password=$3" \
    --data-urlencode "authorize_query=$4" "$BASE/login"
}

# GET the Location of a login redirect (absolute /authorize URL) with the jar,
# and echo the authorization code from the final redirect.
follow_to_code() { # jar
  local loc
  loc="$(header_value "$TMP/login.h" location)"
  [ -n "$loc" ] || return 1
  curl -s -o /dev/null -D "$TMP/authz.h" -b "$1" -c "$1" "$loc"
  loc="$(header_value "$TMP/authz.h" location)"
  case "$loc" in "$REDIRECT_URI"?*) ;; *) return 1 ;; esac
  printf '%s\n' "$loc" | sed -n 's/.*[?&]code=\([^&]*\).*/\1/p'
}

# With an existing session cookie: authorize directly, echo the code.
code_with_session() { # jar query
  curl -s -o /dev/null -D "$TMP/authz.h" -b "$1" -c "$1" "$BASE/authorize?$2"
  local loc
  loc="$(header_value "$TMP/authz.h" location)"
  case "$loc" in "$REDIRECT_URI"?*) ;; *) return 1 ;; esac
  printf '%s\n' "$loc" | sed -n 's/.*[?&]code=\([^&]*\).*/\1/p'
}

# POST /token with client_secret_basic. Body -> $TMP/token.json, prints HTTP status.
exchange() { # code verifier
  curl -s -o "$TMP/token.json" -w '%{http_code}' -u "$CLIENT_ID:$CLIENT_SECRET" \
    --data-urlencode "grant_type=authorization_code" \
    --data-urlencode "code=$1" \
    --data-urlencode "redirect_uri=$REDIRECT_URI" \
    --data-urlencode "code_verifier=$2" \
    "$BASE/token"
}

NONCE="$(openssl rand -hex 8)"

echo "ssozia e2e against $BASE"
echo "------------------------------------------------------------"

# ---- 1-3: discovery ---------------------------------------------------------
if curl -sf "$BASE/.well-known/openid-configuration" -o "$TMP/discovery.json"; then
  check_eq "1. discovery issuer == $EXPECT_ISSUER" "$EXPECT_ISSUER" "$(jq -r .issuer "$TMP/discovery.json")"
  if jq -e '.code_challenge_methods_supported | index("S256")' "$TMP/discovery.json" >/dev/null 2>&1; then
    pass "2. code_challenge_methods_supported contains S256"
  else
    fail "2. code_challenge_methods_supported contains S256"
  fi
  check_eq "3. end_session_endpoint == $EXPECT_ISSUER/logout" "$EXPECT_ISSUER/logout" \
    "$(jq -r .end_session_endpoint "$TMP/discovery.json")"
else
  fail "1. discovery issuer == $EXPECT_ISSUER" "cannot fetch $BASE/.well-known/openid-configuration"
  fail "2. code_challenge_methods_supported contains S256" "no discovery document"
  fail "3. end_session_endpoint == $EXPECT_ISSUER/logout" "no discovery document"
fi

# ---- 4: full flow -----------------------------------------------------------
JAR="$TMP/jar.txt"
VERIFIER="$(new_verifier)"
CHALLENGE="$(challenge_for "$VERIFIER")"
QUERY="$(authorize_query "$CHALLENGE")"

FLOW_OK=0
ID_TOKEN=""
ACCESS_TOKEN=""

# the login page must come first (no session yet)
curl -s -o "$TMP/login-page.html" -w '%{http_code}' -c "$JAR" -b "$JAR" "$BASE/authorize?$QUERY" >"$TMP/login-page.status"
if [ "$(cat "$TMP/login-page.status")" != "200" ] || ! grep -q 'name="authorize_query"' "$TMP/login-page.html"; then
  fail "4. full flow: authorize -> login -> token -> userinfo" "no login page from /authorize"
else
  do_login "$JAR" "$EMAIL" "$PASSWORD" "$QUERY"
  CODE="$(follow_to_code "$JAR")"
  if [ -z "$CODE" ]; then
    fail "4. full flow: authorize -> login -> token -> userinfo" "login did not lead to an authorization code"
  else
    HTTP="$(exchange "$CODE" "$VERIFIER")"
    if [ "$HTTP" != "200" ]; then
      fail "4. full flow: authorize -> login -> token -> userinfo" "token endpoint returned HTTP $HTTP: $(cat "$TMP/token.json")"
    else
      ACCESS_TOKEN="$(jq -r .access_token "$TMP/token.json")"
      ID_TOKEN="$(jq -r .id_token "$TMP/token.json")"
      curl -s -H "Authorization: Bearer $ACCESS_TOKEN" "$BASE/userinfo" -o "$TMP/userinfo.json"
      GOT_SUB="$(jq -r .sub "$TMP/userinfo.json")"
      GOT_EMAIL="$(jq -r .email "$TMP/userinfo.json")"
      GOT_USER="$(jq -r .preferred_username "$TMP/userinfo.json")"
      if [ "$GOT_SUB" = "$EXPECT_SUB" ] && [ "$GOT_EMAIL" = "$EMAIL" ] && [ "$GOT_USER" = "$EXPECT_USERNAME" ]; then
        FLOW_OK=1
        pass "4. full flow: authorize -> login -> token -> userinfo (sub=$GOT_SUB email=$GOT_EMAIL preferred_username=$GOT_USER)"
      else
        fail "4. full flow: authorize -> login -> token -> userinfo" "userinfo: $(jq -c . "$TMP/userinfo.json" 2>/dev/null)"
      fi
    fi
  fi
fi

# ---- 5: id_token signature against JWKS --------------------------------------
if ! command -v python3 >/dev/null 2>&1; then
  skip "5. id_token RS256 signature verifies against JWKS" "python3 not found"
elif [ -z "$ID_TOKEN" ] || [ "$ID_TOKEN" = "null" ]; then
  fail "5. id_token RS256 signature verifies against JWKS" "no id_token (flow in check 4 failed)"
else
  echo "      (python3: $(python3 --version 2>&1))"
  curl -sf "$BASE/jwks" -o "$TMP/jwks.json" || echo '{"keys":[]}' >"$TMP/jwks.json"
  PYOUT="$(python3 - "$ID_TOKEN" "$TMP/jwks.json" "$EXPECT_ISSUER" "$CLIENT_ID" "$NONCE" <<'PYEOF'
import base64, hashlib, json, sys, time

token, jwks_path, issuer, audience, nonce = sys.argv[1:6]

def b64d(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))

try:
    h64, p64, s64 = token.split(".")
    header = json.loads(b64d(h64))
    payload = json.loads(b64d(p64))
    keys = json.load(open(jwks_path))["keys"]
    key = next(k for k in keys if k.get("kid") == header.get("kid"))
    n = int.from_bytes(b64d(key["n"]), "big")
    e = int.from_bytes(b64d(key["e"]), "big")
    k = (n.bit_length() + 7) // 8
    sig = int.from_bytes(b64d(s64), "big")
    if sig >= n:
        raise ValueError("signature out of range")
    em = pow(sig, e, n).to_bytes(k, "big")
    digest = hashlib.sha256((h64 + "." + p64).encode()).digest()
    prefix = bytes.fromhex("3031300d060960864801650304020105000420")  # DigestInfo SHA-256
    t = prefix + digest
    expected = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
    problems = []
    if header.get("alg") != "RS256":
        problems.append("alg is not RS256")
    if em != expected:
        problems.append("signature does not verify")
    if payload.get("iss") != issuer:
        problems.append("iss mismatch")
    if payload.get("aud") != audience:
        problems.append("aud mismatch")
    if payload.get("nonce") != nonce:
        problems.append("nonce mismatch")
    if payload.get("exp", 0) <= time.time():
        problems.append("expired")
    print("OK" if not problems else "BAD: " + ", ".join(problems))
except Exception as exc:  # noqa
    print("BAD: " + repr(exc))
PYEOF
)"
  if [ "$PYOUT" = "OK" ]; then
    pass "5. id_token RS256 signature verifies against JWKS (iss, aud, nonce, exp also checked)"
  else
    fail "5. id_token RS256 signature verifies against JWKS" "$PYOUT"
  fi
fi

# ---- 6: wrong password ------------------------------------------------------
JAR6="$TMP/jar6.txt"
V6="$(new_verifier)"
Q6="$(authorize_query "$(challenge_for "$V6")")"
do_login "$JAR6" "$EMAIL" "definitely-not-the-password" "$Q6"
S6="$(status_of "$TMP/login.h")"
if [ "$S6" = "401" ] && [ -z "$(header_value "$TMP/login.h" set-cookie)" ] && [ -z "$(header_value "$TMP/login.h" location)" ]; then
  pass "6. wrong password is rejected (HTTP 401, no session cookie)"
else
  fail "6. wrong password is rejected" "HTTP $S6, set-cookie='$(header_value "$TMP/login.h" set-cookie)'"
fi

# ---- 7: wrong redirect_uri --------------------------------------------------
# Use the logged-in jar from check 4 so that only redirect_uri validation can stop us.
V7="$(new_verifier)"
BAD_REDIRECT="${REDIRECT_URI}/"
Q7="$(authorize_query "$(challenge_for "$V7")" "st-bad" "$BAD_REDIRECT")"
S7="$(curl -s -o /dev/null -D "$TMP/r7.h" -w '%{http_code}' -b "$JAR" "$BASE/authorize?$Q7")"
L7="$(header_value "$TMP/r7.h" location)"
if [ "$S7" = "400" ] && [ -z "$L7" ]; then
  pass "7. wrong redirect_uri is rejected (HTTP 400, no redirect)"
else
  fail "7. wrong redirect_uri is rejected" "HTTP $S7, location='$L7'"
fi

# ---- 8: reused authorization code -------------------------------------------
if [ "$FLOW_OK" = "1" ]; then
  V8="$(new_verifier)"
  Q8="$(authorize_query "$(challenge_for "$V8")")"
  CODE8="$(code_with_session "$JAR" "$Q8")"
  if [ -z "$CODE8" ]; then
    fail "8. reused authorization code is rejected" "could not obtain a code"
  else
    H1="$(exchange "$CODE8" "$V8")"
    H2="$(exchange "$CODE8" "$V8")"
    if [ "$H1" = "200" ] && [ "$H2" = "400" ] && [ "$(jq -r .error "$TMP/token.json")" = "invalid_grant" ]; then
      pass "8. reused authorization code is rejected (first HTTP $H1, second HTTP $H2 invalid_grant)"
    else
      fail "8. reused authorization code is rejected" "first HTTP $H1, second HTTP $H2"
    fi
  fi
else
  fail "8. reused authorization code is rejected" "skipped because check 4 failed"
fi

# ---- 9: wrong PKCE verifier -------------------------------------------------
if [ "$FLOW_OK" = "1" ]; then
  V9="$(new_verifier)"
  Q9="$(authorize_query "$(challenge_for "$V9")")"
  CODE9="$(code_with_session "$JAR" "$Q9")"
  if [ -z "$CODE9" ]; then
    fail "9. wrong PKCE verifier is rejected" "could not obtain a code"
  else
    H9="$(exchange "$CODE9" "$(new_verifier)")"
    if [ "$H9" = "400" ] && [ "$(jq -r .error "$TMP/token.json")" = "invalid_grant" ]; then
      pass "9. wrong PKCE verifier is rejected (HTTP $H9 invalid_grant)"
    else
      fail "9. wrong PKCE verifier is rejected" "HTTP $H9: $(cat "$TMP/token.json")"
    fi
  fi
else
  fail "9. wrong PKCE verifier is rejected" "skipped because check 4 failed"
fi

# ---- 10-11: /admin creates a key for another system, and it really works -----
JAR10="$TMP/jar10.txt"
do_login "$JAR10" "$EMAIL" "$PASSWORD" ""
L10="$(header_value "$TMP/login.h" location)"
curl -s -o "$TMP/admin.html" -b "$JAR10" -c "$JAR10" "$BASE/admin"
CSRF="$(grep -o 'name="csrf" value="[^"]*"' "$TMP/admin.html" | head -n1 | sed 's/.*value="//; s/"$//')"
NEW_ID="e2e-$(openssl rand -hex 3)"
NEW_REDIRECT="http://e2e.imamreza.ir/callback"
NEW_SECRET=""
if [ "$L10" = "$BASE/admin" ] && [ -n "$CSRF" ]; then
  curl -s -o "$TMP/created.html" -b "$JAR10" -c "$JAR10" \
    --data-urlencode "csrf=$CSRF" --data-urlencode "name=e2e test" \
    --data-urlencode "client_id=$NEW_ID" --data-urlencode "redirect_uris=$NEW_REDIRECT" \
    --data-urlencode "post_logout_redirect_uris=http://e2e.imamreza.ir" \
    --data-urlencode "require_pkce=on" "$BASE/admin/clients"
  NEW_SECRET="$(grep -o 'id="client-secret">[^<]*' "$TMP/created.html" | head -n1 | sed 's/.*>//')"
fi
if [ -z "$NEW_SECRET" ]; then
  fail "10. /admin creates a client and shows its key" "no key returned (is the user is_admin = true? login redirect='$L10')"
  fail "11. /admin delete removes the client" "skipped because check 10 failed"
else
  SAVE_ID="$CLIENT_ID"; SAVE_SECRET="$CLIENT_SECRET"; SAVE_REDIRECT="$REDIRECT_URI"
  CLIENT_ID="$NEW_ID"; CLIENT_SECRET="$NEW_SECRET"; REDIRECT_URI="$NEW_REDIRECT"
  V10="$(new_verifier)"
  Q10="$(authorize_query "$(challenge_for "$V10")")"
  CODE10="$(code_with_session "$JAR10" "$Q10")"
  H10=""
  [ -n "$CODE10" ] && H10="$(exchange "$CODE10" "$V10")"
  if [ "$H10" = "200" ] && [ "$(jq -r .token_type "$TMP/token.json")" = "Bearer" ]; then
    pass "10. /admin creates a client and its new key works (client_id=$NEW_ID, secret ${#NEW_SECRET} chars)"
  else
    fail "10. /admin creates a client and its new key works" "code='$CODE10' token HTTP '$H10'"
  fi
  # delete it again and make sure it is gone
  curl -s -o /dev/null -b "$JAR10" --data-urlencode "csrf=$CSRF" "$BASE/admin/clients/$NEW_ID/delete"
  S11="$(curl -s -o /dev/null -w '%{http_code}' -b "$JAR10" "$BASE/authorize?$Q10")"
  CLIENT_ID="$SAVE_ID"; CLIENT_SECRET="$SAVE_SECRET"; REDIRECT_URI="$SAVE_REDIRECT"
  if [ "$S11" = "400" ]; then
    pass "11. /admin delete removes the client (authorize now answers HTTP 400)"
  else
    fail "11. /admin delete removes the client" "authorize answered HTTP $S11"
  fi
fi

echo "------------------------------------------------------------"
echo "SUMMARY: $PASS_COUNT passed, $FAIL_COUNT failed, $SKIP_COUNT skipped"
if [ "$FAIL_COUNT" -eq 0 ]; then
  echo "RESULT: PASS"
  exit 0
fi
echo "RESULT: FAIL"
exit 1
