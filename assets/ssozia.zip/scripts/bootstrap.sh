#!/usr/bin/env bash
# VERSION: 2.0 (2026-10-10)  1.x = original; 2.0 = host cargo --release build used for the
#   image (docker-compose.host.yml), kms layout default, ROTATE_CLIENT, version print
# ssozia + Outline first-run bootstrap. Idempotent; fails fast.
#   bash scripts/bootstrap.sh            # first run or re-run (reuses existing secrets)
#   ROTATE=1 bash scripts/bootstrap.sh   # regenerate admin password + client secret
#   ROTATE_CLIENT=1 bash scripts/bootstrap.sh      # regenerate only the client secret
#   ADMIN_PASSWORD=... bash scripts/bootstrap.sh   # set the admin password yourself
# Optional: OUTLINE_DIR (default ./ if docker-compose.yml is here, else
#             ../outline/outline.ir (kms layout), else asks),
#           ADMIN_EMAIL (default admin@imamreza.ir),
#           USE_HOST_BUILD=0 to compile inside Docker (Dockerfile) instead of on the host,
#           CAROOT (mkcert CA folder; default: mkcert -CAROOT)
# NOTE: config files use ssozia's real schema (redirect_uris / post_logout_redirect_uris
#       arrays, name, preferred_username, require_pkce), not the flat keys of the brief.
set -Eeuo pipefail
umask 077
cd "$(dirname "${BASH_SOURCE[0]}")/.."

SSO_URL=https://sso.imamreza.ir
KMS_URL=https://kms.imamreza.ir
ADMIN_EMAIL="${ADMIN_EMAIL:-admin@imamreza.ir}"
ROTATE="${ROTATE:-0}"
ROTATE_CLIENT="${ROTATE_CLIENT:-$ROTATE}"
COMPOSE_SSO=docker-compose.ssozia.yml
COMPOSE_SSO_HOST=docker-compose.host.yml
USE_HOST_BUILD="${USE_HOST_BUILD:-1}"
BIN=./target/release/ssozia
NET=outline-net
TS=$(date +%Y%m%d-%H%M%S)
if [ -z "${OUTLINE_DIR:-}" ]; then
  if [ -f docker-compose.yml ]; then
    OUTLINE_DIR=.
  elif [ -f ../outline/outline.ir/docker-compose.yml ]; then
    OUTLINE_DIR="$(cd ../outline/outline.ir && pwd)"
  else
    read -rp "Outline project path: " OUTLINE_DIR \
      || { echo "ERROR: no Outline project path given (set OUTLINE_DIR)" >&2; exit 1; }
    OUTLINE_DIR="${OUTLINE_DIR/#\~/$HOME}"
    [ -d "$OUTLINE_DIR" ] || { echo "ERROR: '$OUTLINE_DIR' is not a directory" >&2; exit 1; }
    [ -f "$OUTLINE_DIR/docker-compose.yml" ] || { echo "ERROR: $OUTLINE_DIR/docker-compose.yml not found" >&2; exit 1; }
    [ -f "$OUTLINE_DIR/outline.env" ] || { echo "ERROR: $OUTLINE_DIR/outline.env not found" >&2; exit 1; }
  fi
fi
ENVF="$OUTLINE_DIR/outline.env"

CFG_CHANGED=0; ENV_CHANGED=0
ADMIN_PASSWORD="${ADMIN_PASSWORD:-}"; ADMIN_SHOWN="(unchanged, not printed)"
CLIENT_SECRET=""; CLIENT_SHOWN="(unchanged, see outline.env)"

declare -a REPORT=()
rep() { REPORT+=("$1|$2|$3"); }
print_report() {
  local row s st n
  printf '\n%-28s | %-8s | %s\n' STEP STATUS NOTES
  printf -- '-----------------------------+----------+------------------------------\n'
  for row in "${REPORT[@]:-}"; do
    [ -n "$row" ] || continue
    IFS='|' read -r s st n <<<"$row"
    printf '%-28s | %-8s | %s\n' "$s" "$st" "$n"
  done
}
fail() { echo "FAILED: $*" >&2; print_report >&2; exit 1; }
on_err() {
  local rc=$?
  echo "FAILED: '${BASH_COMMAND}' (line ${BASH_LINENO[0]}, exit $rc)" >&2
  print_report >&2
  exit "$rc"
}
trap on_err ERR

backup() { [ -f "$1" ] && { [ -e "$1.bak-$TS" ] || cp -p "$1" "$1.bak-$TS"; }; return 0; }
oc() { ( cd "$OUTLINE_DIR" && docker compose "$@" ); }
# Host build: the image only packages ./target/release/ssozia (Dockerfile.host).
if [ "$USE_HOST_BUILD" = 1 ] && [ -f "$COMPOSE_SSO_HOST" ]; then
  sc() { docker compose -f "$COMPOSE_SSO" -f "$COMPOSE_SSO_HOST" "$@"; }
else
  USE_HOST_BUILD=0
  sc() { docker compose -f "$COMPOSE_SSO" "$@"; }
fi
env_get() { awk -v k="$2" 'index($0,k"=")==1{sub(/^[^=]*=/,""); print; exit}' "$1"; }
hash_pw() { printf '%s' "$1" | "$BIN" hash-password | grep -m1 '^\$argon2id\$'; }
set_kv() {
  local tmp; tmp=$(mktemp)
  K="$2" V="$3" awk 'BEGIN{k=ENVIRON["K"];v=ENVIRON["V"]}
    index($0,k"=")==1{ if(!f){print k"="v; f=1}; next }
    {print} END{ if(!f) print k"="v }' "$1" >"$tmp"
  if ! cmp -s "$tmp" "$1"; then backup "$1"; cat "$tmp" >"$1"; ENV_CHANGED=1; fi
  rm -f "$tmp"
}
del_kv() {
  grep -q "^$2=" "$1" || return 0
  backup "$1"; sed -i "/^$2=/d" "$1"; ENV_CHANGED=1
}
wait_http() { # url, status regex, seconds
  local i=0 code
  while [ "$i" -lt "$3" ]; do
    code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "$1" || true)
    [[ $code =~ ^($2)$ ]] && return 0
    sleep 1; i=$((i + 1))
  done
  return 1
}
kid() { curl -fsS "$SSO_URL/.well-known/jwks.json" | jq -r '.keys[0].kid'; }

# ---- 1. Preflight ---------------------------------------------------------
echo "bootstrap.sh $(sed -n 's/^# VERSION: \([^ ]*\).*/\1/p' "${BASH_SOURCE[0]}" | head -n1) | OUTLINE_DIR=$OUTLINE_DIR | host build: $USE_HOST_BUILD"
for t in cargo openssl docker curl jq awk mkcert; do
  command -v "$t" >/dev/null || fail "missing tool: $t"
done
docker compose version >/dev/null
[ -f "$COMPOSE_SSO" ] || fail "$COMPOSE_SSO not found (run from the repo)"
[ -f "$OUTLINE_DIR/docker-compose.yml" ] || fail "Outline compose not found in $OUTLINE_DIR (set OUTLINE_DIR)"
[ -f "$ENVF" ] || fail "$ENVF not found"

if command -v ss >/dev/null; then
  for pid in $(ss -ltnpH 'sport = :4000' 2>/dev/null | grep -o 'pid=[0-9]*' | cut -d= -f2 | sort -u || true); do
    comm=$(cat "/proc/$pid/comm" 2>/dev/null || true)
    [ "$comm" = ssozia ] || fail "port 4000 is held by '$comm' (pid $pid)"
    kill "$pid"; sleep 1
  done
fi

for h in sso.imamreza.ir kms.imamreza.ir; do
  if ! getent ahostsv4 "$h" | awk '{print $1}' | grep -qx 127.0.0.1; then
    if sudo -n true 2>/dev/null; then
      echo "127.0.0.1 $h" | sudo -n tee -a /etc/hosts >/dev/null
    else
      fail "add '127.0.0.1 $h' to /etc/hosts (needs root)"
    fi
  fi
done

cargo build --release --locked --quiet
[ -x "$BIN" ] || fail "$BIN missing after build"
rep "1 preflight" OK "tools, port 4000, hosts, release binary (host cargo)"

# ---- 1b. TLS (mkcert) -------------------------------------------------------
mkcert -install >/dev/null
CAROOT=$(mkcert -CAROOT)
[ -f "$CAROOT/rootCA.pem" ] || fail "mkcert root CA not found in $CAROOT"
export CURL_CA_BUNDLE="$CAROOT/rootCA.pem" SSL_CERT_FILE="$CAROOT/rootCA.pem"
CRT=certs/imamreza.pem; KEY=certs/imamreza-key.pem
mkdir -p certs; chmod 755 certs
need=0
if [ ! -f "$CRT" ] || [ ! -f "$KEY" ]; then need=1
elif ! openssl x509 -in "$CRT" -noout -checkend 2592000 >/dev/null; then need=1
elif ! openssl verify -CAfile "$CAROOT/rootCA.pem" "$CRT" >/dev/null 2>&1; then need=1
elif ! { san=$(openssl x509 -in "$CRT" -noout -ext subjectAltName)
         grep -q sso.imamreza.ir <<<"$san" && grep -q kms.imamreza.ir <<<"$san"; }; then need=1
fi
if [ "$need" = 1 ]; then
  mkcert -cert-file "$CRT" -key-file "$KEY" sso.imamreza.ir kms.imamreza.ir >/dev/null
  chmod 644 "$CRT" "$KEY"
  rep "1b tls cert" CREATED "certs/imamreza.pem (sso + kms)"
else
  rep "1b tls cert" OK "valid, signed by mkcert CA"
fi

# ---- 2-4. Secrets, users, clients ----------------------------------------
have_admin=0
[ -f users.toml ] && grep -q '^password_hash = "\$argon2id\$' users.toml && have_admin=1
have_client=0
if [ -f clients.toml ] && grep -q '^client_id = "outline"' clients.toml \
   && grep -q '^client_secret_hash = "\$argon2id\$' clients.toml \
   && grep -qF "\"$KMS_URL/auth/oidc.callback\"" clients.toml; then
  cur=$(env_get "$ENVF" OIDC_CLIENT_SECRET)
  case "$cur" in ""|CHANGE_ME*) ;; *) have_client=1 ;; esac
fi

GEN_ADMIN=0; GEN_CLIENT=0
{ [ "$ROTATE" = 1 ] || [ "$have_admin" = 0 ] || [ -n "$ADMIN_PASSWORD" ]; } && GEN_ADMIN=1
{ [ "$ROTATE_CLIENT" = 1 ] || [ "$have_client" = 0 ]; } && GEN_CLIENT=1

if [ "$GEN_CLIENT" = 1 ]; then
  CLIENT_SECRET=$(openssl rand -hex 32)
  CLIENT_SHOWN="$CLIENT_SECRET"
else
  CLIENT_SECRET=$(env_get "$ENVF" OIDC_CLIENT_SECRET)
fi
if [ "$GEN_ADMIN" = 1 ]; then
  if [ -z "$ADMIN_PASSWORD" ]; then
    ADMIN_PASSWORD=$(openssl rand -base64 48 | tr -d '/+=\n' | cut -c1-28)
    ADMIN_SHOWN="$ADMIN_PASSWORD"
  else
    ADMIN_SHOWN="(provided by you)"
  fi
fi
rep "2 secrets" OK "admin: $([ $GEN_ADMIN = 1 ] && echo new || echo reused); client: $([ $GEN_CLIENT = 1 ] && echo new || echo reused)"

if [ "$GEN_ADMIN" = 1 ]; then
  ADMIN_HASH=$(hash_pw "$ADMIN_PASSWORD")
  backup users.toml
  cat >users.toml <<EOF
[[users]]
id = "u_1"
email = "$ADMIN_EMAIL"
name = "Admin"
preferred_username = "admin"
password_hash = "$ADMIN_HASH"
is_admin = true
EOF
  chmod 644 users.toml; CFG_CHANGED=1
  rep "3 users.toml" WRITTEN "u_1 $ADMIN_EMAIL"
else
  rep "3 users.toml" KEPT "existing admin hash"
fi

if [ "$GEN_CLIENT" = 1 ]; then
  CLIENT_HASH=$(hash_pw "$CLIENT_SECRET")
  backup clients.toml
  cat >clients.toml <<EOF
[[clients]]
client_id = "outline"
name = "Outline"
client_secret_hash = "$CLIENT_HASH"
redirect_uris = ["$KMS_URL/auth/oidc.callback"]
post_logout_redirect_uris = ["$KMS_URL"]
require_pkce = true
EOF
  chmod 644 clients.toml; CFG_CHANGED=1
  rep "4 clients.toml" WRITTEN "client outline"
else
  rep "4 clients.toml" KEPT "existing client"
fi

# ---- 5. Outline env --------------------------------------------------------
chmod 600 "$ENVF"
set_kv "$ENVF" OIDC_ISSUER_URL "$SSO_URL"
set_kv "$ENVF" OIDC_CLIENT_ID outline
set_kv "$ENVF" OIDC_CLIENT_SECRET "$CLIENT_SECRET"
set_kv "$ENVF" URL "$KMS_URL"
set_kv "$ENVF" FORCE_HTTPS false
set_kv "$ENVF" OIDC_LOGOUT_URI "$SSO_URL/logout"
set_kv "$ENVF" OIDC_SCOPES "openid profile email"
set_kv "$ENVF" OIDC_USERNAME_CLAIM preferred_username
for k in OIDC_AUTH_URI OIDC_TOKEN_URI OIDC_USERINFO_URI HTTPS_PROXY https_proxy; do del_kv "$ENVF" "$k"; done

# Outline must trust the mkcert CA to reach https://sso.imamreza.ir (compose override, merged automatically).
OVR="$OUTLINE_DIR/docker-compose.override.yml"
OVR_TMP=$(mktemp)
cat >"$OVR_TMP" <<EOF
# managed by ssozia scripts/bootstrap.sh
services:
  outline:
    environment:
      - NODE_EXTRA_CA_CERTS=/etc/ssl/certs/mkcert-rootCA.pem
    volumes:
      - $CAROOT/rootCA.pem:/etc/ssl/certs/mkcert-rootCA.pem:ro
EOF
if [ -f "$OVR" ] && ! grep -q 'managed by ssozia' "$OVR"; then
  fail "$OVR exists and is not managed by this script"
fi
if ! cmp -s "$OVR_TMP" "$OVR" 2>/dev/null; then
  backup "$OVR"; cat "$OVR_TMP" >"$OVR"; chmod 644 "$OVR"; ENV_CHANGED=1
fi
rm -f "$OVR_TMP"
rep "5 outline.env" "$([ $ENV_CHANGED = 1 ] && echo UPDATED || echo OK)" "OIDC keys, CA trust override, proxy keys removed"

# ---- 7a. Outline data services, network, migration ------------------------
oc up -d --wait postgres redis
docker network inspect "$NET" >/dev/null 2>&1 \
  || fail "network '$NET' missing: add 'name: $NET' under networks.outline-net in $OUTLINE_DIR/docker-compose.yml, then 'docker compose down && up -d'"

fresh=$(oc exec -T postgres sh -c 'psql -U "$POSTGRES_USER" -d "$POSTGRES_DB" -tA' \
        <<<"select to_regclass('public.users') is null;" | tr -d '[:space:]')
if [ "$fresh" = t ]; then
  oc run -T --rm --no-deps --entrypoint sh outline -c \
    'yarn db:migrate --env=production-ssl-disabled || ./node_modules/.bin/sequelize db:migrate --env=production-ssl-disabled'
  rep "7a db migrate" DONE "fresh database"
else
  rep "7a db migrate" SKIP "schema already present"
fi

# ---- 7b + 6. ssozia stack, signing key ------------------------------------
mkdir -p data
sc build ssozia
sc run -T --rm --no-deps --user 0 --entrypoint sh ssozia -c 'chown -R 10001:10001 /app/data && chmod 755 /app/data'
sc up -d --build
[ "$CFG_CHANGED" = 1 ] && sc restart ssozia
sc restart caddy
wait_http "$SSO_URL/health" 200 60 || fail "ssozia not healthy at $SSO_URL/health (docker compose -f $COMPOSE_SSO logs ssozia)"
[ -f data/signing-key.pem ] || fail "data/signing-key.pem was not created"
k1=$(kid); sc restart ssozia
wait_http "$SSO_URL/health" 200 60 || fail "ssozia not healthy after restart"
k2=$(kid)
[ -n "$k1" ] && [ "$k1" = "$k2" ] || fail "signing key changed after restart ($k1 -> $k2)"
rep "6 signing key" OK "persists across restart"
rep "7b ssozia + caddy" UP "built ($([ $USE_HOST_BUILD = 1 ] && echo 'host binary' || echo 'in Docker')), healthy"

# ---- 7c. Outline ------------------------------------------------------------
oc up -d
[ "$ENV_CHANGED" = 1 ] && oc up -d --force-recreate --no-deps outline
docker inspect -f '{{json .NetworkSettings.Networks}}' outline | jq -e --arg n "$NET" 'has($n)' >/dev/null \
  || fail "container 'outline' is not on network '$NET' (set 'name: $NET' on its network)"
rep "7c outline" UP "on $NET"

# ---- 8. Smoke tests ---------------------------------------------------------
DISC=$(mktemp)
wait_http "$SSO_URL/.well-known/openid-configuration" 200 30 || fail "discovery not reachable"
curl -fsS "$SSO_URL/.well-known/openid-configuration" >"$DISC"
jq . "$DISC"
jq -e --arg i "$SSO_URL" \
  '.issuer==$i and (.authorization_endpoint|type=="string") and (.token_endpoint|type=="string") and (.jwks_uri|type=="string")' "$DISC" >/dev/null \
  || fail "discovery document is missing issuer/authorization_endpoint/token_endpoint/jwks_uri"
rep "8 discovery" OK "issuer + endpoints present"

wait_http "$KMS_URL" '200|301|302' 90 || fail "Outline did not answer 200/302 at $KMS_URL (docker compose logs outline)"
rep "8 outline http" OK "$(curl -s -o /dev/null -w '%{http_code}' "$KMS_URL")"

if [ -n "$ADMIN_PASSWORD" ]; then
  E2E_EMAIL="$ADMIN_EMAIL" E2E_PASSWORD="$ADMIN_PASSWORD" E2E_CLIENT_SECRET="$CLIENT_SECRET" \
    bash scripts/e2e.sh || fail "scripts/e2e.sh reported failures"
  rep "8 e2e login" OK "scripts/e2e.sh passed"
else
  rep "8 e2e login" SKIP "admin password unknown (rerun with ADMIN_PASSWORD=...)"
fi

# ---- 9. Report --------------------------------------------------------------
print_report
printf '\nCREDENTIALS (shown once)\n  admin email    : %s\n  admin password : %s\n  client secret  : %s\n' \
  "$ADMIN_EMAIL" "$ADMIN_SHOWN" "$CLIENT_SHOWN"
