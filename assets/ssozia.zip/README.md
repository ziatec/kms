# ssozia (step 1)

> VERSION: 0.2.0 (2026-10-12) — users and organization chart: an admin JSON
> API (`/admin/api/*`) used by the Outline plugin **ssozia-users**; sign-in with
> email **or user name** (Persian user names allowed); users can be disabled.

A minimal OpenID Connect provider written in Rust. Step 1 has one job: let a
real **Outline v1.10.1** (image `outline-rtl:1.10.1`) sign in and sign out
through it, over HTTPS (mkcert certificate), locally.

```
https://kms.imamreza.ir  ->  Outline  (port 3000 in its container)
https://sso.imamreza.ir  ->  ssozia   (port 4000 in its container)
```

Both hostnames point to `127.0.0.1` in `/etc/hosts`. A Caddy container on
ports 80/443 routes by `Host` header and terminates TLS with a mkcert
certificate (`certs/`); port 80 only redirects to HTTPS. ssozia lives at the **root** of
`sso.imamreza.ir` (no path prefix) and its issuer is exactly
`https://sso.imamreza.ir`.

## Build

```sh
cargo build --release
```

## Generate a password hash

The password is read from stdin, so it never shows up in `ps` or your shell
history:

```sh
printf %s 'your-password' | cargo run -q -- hash-password
```

(`--password <value>` exists for tests only; it is visible in `ps`.)
The same command hashes the OIDC client secret.

## Fill in users.toml and clients.toml

```sh
cp users.toml.example users.toml
cp clients.toml.example clients.toml
```

`users.toml`: paste the hash of the user's password into `password_hash`.
`id` becomes the OIDC `sub` and must never change.

```toml
[[users]]
id = "u_1"
email = "admin@example.com"
name = "Admin"
preferred_username = "admin"
password_hash = "$argon2id$..."
```

`clients.toml`: generate one secret, put the plaintext in Outline's
`OIDC_CLIENT_SECRET` and its hash here.

```sh
SECRET=$(openssl rand -hex 32)
echo "OIDC_CLIENT_SECRET=$SECRET"                  # copy into outline.env
printf %s "$SECRET" | cargo run -q -- hash-password # copy into client_secret_hash
```

```toml
[[clients]]
client_id = "outline"
client_secret_hash = "$argon2id$..."
redirect_uris = ["https://kms.imamreza.ir/auth/oidc.callback"]
post_logout_redirect_uris = ["https://kms.imamreza.ir"]   # no trailing slash
require_pkce = true
```

`redirect_uris` and `post_logout_redirect_uris` are compared **byte for
byte**; there is no trailing-slash tolerance. ssozia refuses to start if a
hash is not a valid argon2 hash (so the `PASTE_HASH_HERE` placeholder fails
loudly).

## Connect systems from the admin page (/admin)

Besides `clients.toml`, systems such as Outline can be connected in the
browser at **https://sso.imamreza.ir/admin**, which generates the key for you.

1. Mark your user as an admin in `users.toml` (and restart ssozia):

   ```toml
   is_admin = true
   ```

   Without it, `/admin` answers 403 (and asks for a login when you are signed
   out). ssozia logs a warning at startup if no user is an admin.

2. Open `/admin`, sign in, and use **«اتصال سیستم جدید»**. For Outline click
   the link «مقادیر آماده‌ی Outline» to prefill the form
   (`client_id=outline`, redirect `https://kms.imamreza.ir/auth/oidc.callback`,
   post-logout `https://kms.imamreza.ir`), then press the button.

3. The next page shows the generated **client secret once**, ready-to-paste
   Outline environment lines (`OIDC_CLIENT_ID`, `OIDC_CLIENT_SECRET`,
   `OIDC_ISSUER_URL`, `OIDC_LOGOUT_URI`, ...) and the endpoint list for any
   other OIDC system. ssozia stores only the argon2id hash, so a lost secret
   cannot be recovered: use **«کلید جدید»** to rotate it (the old one stops
   working immediately). **«حذف»** removes the connection.

Notes:

- Connections created in `/admin` are saved in `DATA_DIR/clients-admin.json`
  (mode 0600; keep `./data` as a volume). `clients.toml` is now optional;
  clients defined there are listed but read-only in `/admin`, and win if the
  same `client_id` exists in both places.
- Every form is CSRF-protected. Redirect URIs must be absolute `http(s)://`
  URLs; they are matched byte for byte, so type them exactly as the other
  system sends them.
- Changing `OIDC_CLIENT_SECRET` in Outline requires restarting Outline.

## Configuration (environment variables)

| Variable          | Default                    |
|-------------------|----------------------------|
| `PUBLIC_BASE_URL` | `http://sso.imamreza.ir` (the compose file sets `https://sso.imamreza.ir`) |
| `BIND_ADDR`       | `0.0.0.0:4000`             |
| `USERS_FILE`      | `./users.toml`             |
| `CLIENTS_FILE`    | `./clients.toml`           |
| `DATA_DIR`        | `./data`                   |
| `COOKIE_SECURE`   | `false` (the compose file sets `true`) |
| `COOKIE_NAME`     | `ssozia_session`           |
| `RUST_LOG`        | `info`                     |

Every absolute URL (discovery, redirects, the login form action) is built
from `PUBLIC_BASE_URL`. The RSA signing key is generated on first start in
`DATA_DIR/signing-key.pem` (mode 0600) and reused afterwards.

## Run with docker compose

`docker-compose.ssozia.yml` contains the `ssozia` and `caddy` services. They
must share a Docker network with your existing Outline service.

1. Create the shared network once (or reuse your Outline network and change
   `name:` at the bottom of the compose file):

   ```sh
   docker network create outline-net
   ```

2. In your **existing Outline compose**, attach the Outline service to that
   network (it must be reachable as `outline` on port 3000) and add:

   ```yaml
   outline:
     extra_hosts:
       - "sso.imamreza.ir:host-gateway"
       - "kms.imamreza.ir:host-gateway"
     networks:
       - outline-net
   ```

   and make sure `HTTPS_PROXY` / `https_proxy` are **not** set for it.

3. Add the lines from `outline.env.example` to Outline's environment (with
   your real `OIDC_CLIENT_SECRET`). Do **not** set `OIDC_AUTH_URI`,
   `OIDC_TOKEN_URI` or `OIDC_USERINFO_URI`: they force Outline into manual
   mode and disable PKCE.

4. Prepare the data directory (the container runs as uid 10001) and start:

   ```sh
   mkdir -p data && sudo chown 10001:10001 data
   docker compose -f docker-compose.ssozia.yml up -d
   ```

Caddy listens on `0.0.0.0:80` (redirect only) and `0.0.0.0:443` (`Caddyfile`),
serves the mkcert certificate from `./certs`, and replaces `X-Forwarded-For`
with the real client address (ssozia's rate limiter trusts the leftmost
value). It sends `X-Forwarded-Proto: https` automatically.

`scripts/bootstrap.sh` does all of this for you: it runs `mkcert -install`,
creates `certs/imamreza.pem` for both hostnames, and writes
`docker-compose.override.yml` next to Outline's compose file so the Outline
container trusts the mkcert root CA (`NODE_EXTRA_CA_CERTS`). Requires
`mkcert` (Arch/Manjaro: `sudo pacman -S mkcert nss`).

## End-to-end script

With ssozia and Caddy running and the hostnames in `/etc/hosts`:

```sh
E2E_PASSWORD='change-me' E2E_CLIENT_SECRET="<plaintext client secret>" bash scripts/e2e.sh
```

Checks 10 and 11 use `/admin` (create a client, run a login with its new
key, delete it), so the e2e user must have `is_admin = true`.

(`E2E_CLIENT_SECRET` can be omitted if `./outline.env` exists; the script
reads `OIDC_CLIENT_SECRET` from it.) It needs only `bash`, `curl`, `jq` and
`openssl`; `python3` is optional and used only for the id_token signature
check, which prints `SKIP` when python3 is missing. It prints PASS/FAIL per
check and exits 0 when every non-SKIP check passes. Other knobs (`BASE`,
`E2E_EMAIL`, `E2E_EXPECT_SUB`, ...) are documented at the top of the script.

## Tests

```sh
cargo test
```

Unit tests cover PKCE S256, single-use and expiring codes, exact redirect
URI matching, both client-auth modes, id_token claims and RS256 signature
against the served JWKS, the discovery document, `/logout`, rate limiting,
and a full in-process login/token/userinfo flow through the real router.

## Notes on Outline v1.10.1

- `ALLOWED_PRIVATE_IP_ADDRESSES` is **irrelevant** to OIDC in Outline
  v1.10.1; do not spend time on it for this setup.
- `HTTPS_PROXY` / `https_proxy` must be **unset** in the Outline container,
  otherwise its back-channel calls to ssozia go through a proxy.
- Outline only enables PKCE when the discovery document advertises `S256`
  in `code_challenge_methods_supported`, and it only calls ssozia on logout
  when discovery has an `end_session_endpoint`. Both are present.
- Outline drives login purely from `/userinfo`; it never verifies the
  id_token signature or fetches the JWKS. ssozia still signs correctly.

## Endpoints

`GET /.well-known/openid-configuration`, `GET /.well-known/jwks.json`,
`GET /jwks`, `GET /authorize`, `POST /login`, `POST /token`,
`GET /userinfo`, `GET /logout`, `GET /health`, plus the admin pages `GET /admin`,
`POST /admin/clients`, `POST /admin/clients/:id/rotate`,
`POST /admin/clients/:id/delete`.

## Deferred to step 2

Persistent PostgreSQL/Redis stores, refresh tokens, `prompt` / `max_age`,
CSRF tokens for the login form, `id_token_hint` validation on logout,
signing-key rotation, user management (the admin page only manages connected
systems), real TLS deployment.


## 0.2.0: users and organization chart

Data (all in `DATA_DIR`, next to the keys):

| file | content |
|---|---|
| `users-admin.json` | users created in the admin API (argon2 hashes, mode 600) |
| `orgchart.json` | positions (a tree) and assignments (user ↔ position; a user may hold several, one of them primary) |

Users in `users.toml` keep working and stay read-only (e.g. the first admin).

Sign-in accepts the email or the user name. User names may be Persian; Arabic
letters are mapped to the Persian ones (ي→ی, ك→ک), so either keyboard works.
A disabled user cannot sign in and their SSO session stops working.
`/userinfo` also returns `positions` (id, title, unit, primary).

### Admin API

Every request needs the client credentials (HTTP Basic) of a client allowed to
use it (`admin_api = true` in clients.toml, or listed in `ADMIN_API_CLIENTS`,
default `outline`) **and** `X-Ssozia-Actor: <email>` of an active admin user.

```
GET  /admin/api/users                    POST /admin/api/users            {email,name,preferred_username,password,is_admin}
POST /admin/api/users/:id                {email,name,preferred_username,is_admin}
POST /admin/api/users/:id/password       {password}
POST /admin/api/users/:id/status         {disabled}
GET  /admin/api/org                      POST /admin/api/org/positions    {title,parent_id,unit,description,sort}
POST /admin/api/org/positions/:id        POST /admin/api/org/positions/:id/delete
POST /admin/api/org/assign               {position_id,user_id,primary}
POST /admin/api/org/unassign             {position_id,user_id}
```
