import type { AnyExtensionClass } from "@shared/editor/lib/types";
import BlockMenuExtension from "~/editor/extensions/BlockMenu";
import ClipboardTextSerializer from "~/editor/extensions/ClipboardTextSerializer";
import CommentGutterExtension from "~/editor/extensions/CommentGutter";
import DiagramsExtension from "@shared/editor/extensions/Diagrams";
import DocumentMenuExtension from "~/editor/extensions/DocumentMenu";
import DragHandle from "~/editor/extensions/DragHandle";
import EmojiMenuExtension from "~/editor/extensions/EmojiMenu";
import FindAndReplaceExtension from "~/editor/extensions/FindAndReplace";
import HoverPreviewsExtension from "~/editor/extensions/HoverPreviews";
import Keys from "~/editor/extensions/Keys";
import MentionMenuExtension from "~/editor/extensions/MentionMenu";
import PasteHandler from "~/editor/extensions/PasteHandler";
import PreventTab from "~/editor/extensions/PreventTab";
import SelectionToolbarExtension from "~/editor/extensions/SelectionToolbar";
import SmartText from "~/editor/extensions/SmartText";

type Nodes = AnyExtensionClass[];

export const withUIExtensions = (nodes: Nodes) => [
  ...nodes,
  SmartText,
  PasteHandler,
  ClipboardTextSerializer,
  BlockMenuExtension,
  EmojiMenuExtension,
  MentionMenuExtension,
  DocumentMenuExtension,
  FindAndReplaceExtension,
  HoverPreviewsExtension,
  SelectionToolbarExtension,
  CommentGutterExtension,
  DiagramsExtension,
  DragHandle,
  // Order these default key handlers last
  PreventTab,
  Keys,
];
