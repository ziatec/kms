import { observer } from "mobx-react";
import { MarkAsReadIcon } from "outline-icons";
import * as React from "react";
import { useTranslation } from "react-i18next";
import styled from "styled-components";
import { s, hover } from "@shared/styles";
import Notification, { type NotificationFilter } from "~/models/Notification";
import { markNotificationsAsRead } from "~/actions/definitions/notifications";
import useMobile from "~/hooks/useMobile";
import useStores from "~/hooks/useStores";
import NotificationMenu from "~/menus/NotificationMenu";
import Empty from "../Empty";
import ErrorBoundary from "../ErrorBoundary";
import Flex from "../Flex";
import { InputSelect, type Option } from "../InputSelect";
import NudeButton from "../NudeButton";
import PaginatedList from "../PaginatedList";
import Scrollable from "../Scrollable";
import Text from "../Text";
import Tooltip from "../Tooltip";
import NotificationListItem from "./NotificationListItem";
import { HStack } from "../primitives/HStack";

/**
 * Hook that returns filtered notifications in a stable order. The order is
 * snapshotted on first call (when the popover mounts) so that toggling
 * read/unread does not cause items to jump positions. Notifications that
 * arrive after the snapshot are prepended at the top.
 *
 * @param active - the current list of active notifications.
 * @param filter - the selected notification filter category.
 * @returns filtered notifications in snapshot order.
 */
function useStableOrderedNotifications(
  active: Notification[],
  filter: NotificationFilter
) {
  const orderSnapshotRef = React.useRef<string[] | null>(null);

  return React.useMemo(() => {
    if (orderSnapshotRef.current === null) {
      orderSnapshotRef.current = active.map((n) => n.id);
    }

    const filtered =
      filter === "all"
        ? active
        : active.filter((notification) =>
            Notification.filterCategories[filter].includes(notification.event)
          );

    const snapshot = orderSnapshotRef.current;
    const orderMap = new Map(snapshot.map((id, index) => [id, index]));
    const inSnapshot: Notification[] = [];
    const newItems: Notification[] = [];

    for (const notification of filtered) {
      if (orderMap.has(notification.id)) {
        inSnapshot.push(notification);
      } else {
        newItems.push(notification);
      }
    }

    inSnapshot.sort(
      (a, b) => (orderMap.get(a.id) ?? 0) - (orderMap.get(b.id) ?? 0)
    );

    return [...newItems, ...inSnapshot];
  }, [active, filter]);
}

type Props = {
  /** Callback when the notification panel wants to close. */
  onRequestClose: () => void;
  /** Ref to the scrollable container. */
  ref?: React.Ref<HTMLDivElement>;
};

/**
 * A panel containing a list of notifications and controls to manage them.
 */
function Notifications({ onRequestClose, ref }: Props) {
  const { notifications } = useStores();
  const { t } = useTranslation();
  const isMobile = useMobile();
  const [filter, setFilter] = React.useState<NotificationFilter>("all");

  const filterOptions = React.useMemo<Option[]>(
    () => [
      { type: "item", label: t("All"), value: "all" },
      { type: "item", label: t("Mentions"), value: "mentions" },
      { type: "item", label: t("Comments and replies"), value: "comments" },
      { type: "item", label: t("Reactions"), value: "reactions" },
      { type: "item", label: t("Document events"), value: "documents" },
      { type: "item", label: t("Collection events"), value: "collections" },
      { type: "item", label: t("System"), value: "system" },
    ],
    [t]
  );

  const filteredNotifications = useStableOrderedNotifications(
    notifications.active,
    filter
  );

  const unreadCount = notifications.approximateUnreadCount;

  return (
    <ErrorBoundary>
      <Flex
        style={{
          width: "100%",
          minHeight: isMobile ? "75vh" : "300px",
          maxHeight:
            "min(75vh, calc(var(--radix-popover-content-available-height, 75vh) - 44px))",
        }}
        column
      >
        <Header justify="space-between">
          <Text weight="bold" as="span">
            {t("Notifications")}
          </Text>
          <HStack>
            <StyledInputSelect
              label={t("Filter")}
              labelHidden
              options={filterOptions}
              value={filter}
              onChange={(value) => setFilter(value as NotificationFilter)}
              short
              nude
            />
            {unreadCount > 0 && (
              <Tooltip content={t("Mark all as read")}>
                <Button
                  action={markNotificationsAsRead}
                  aria-label={t("Mark all as read")}
                >
                  <MarkAsReadIcon />
                </Button>
              </Tooltip>
            )}
            <NotificationMenu />
          </HStack>
        </Header>
        <StyledScrollable ref={ref} flex topShadow hiddenScrollbars>
          <React.Suspense fallback={null}>
            <PaginatedList<Notification>
              fetch={notifications.fetchPage}
              options={{ archived: false }}
              items={filteredNotifications}
              empty={
                <EmptyNotifications>
                  {t("You’re all caught up")}.
                </EmptyNotifications>
              }
              renderItem={(item) => (
                <NotificationListItem
                  key={item.id}
                  notification={item}
                  onNavigate={onRequestClose}
                />
              )}
            />
          </React.Suspense>
        </StyledScrollable>
      </Flex>
    </ErrorBoundary>
  );
}

const StyledInputSelect = styled(InputSelect)`
  color: ${s("textSecondary")};
  font-weight: 500;
  font-size: 14px;
  height: 24px;

  & > * {
    min-height: 24px;
    line-height: 24px !important;
  }
`;

const StyledScrollable = styled(Scrollable)`
  flex: 1;
  min-height: 0;
`;

const EmptyNotifications = styled(Empty)`
  display: flex;
  align-items: center;
  justify-content: center;
  flex: 1;
`;

const Button = styled(NudeButton)`
  color: ${s("textSecondary")};

  &:${hover},
  &:active {
    color: ${s("text")};
    background: ${s("sidebarControlHoverBackground")};
  }
`;

const Header = styled(Flex)`
  padding: 8px 12px 12px;
  min-height: 44px;

  ${Button} {
    opacity: 0.75;
    transition: opacity 250ms ease-in-out;
  }

  &:${hover},
  &:focus-within {
    ${Button} {
      opacity: 1;
    }
  }
`;

export default observer(Notifications);
