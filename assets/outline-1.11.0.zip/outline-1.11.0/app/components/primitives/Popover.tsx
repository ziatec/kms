import * as PopoverPrimitive from "@radix-ui/react-popover";
import * as React from "react";
import { mergeRefs } from "react-merge-refs";
import styled from "styled-components";
import { depths, s, borderRadius } from "@shared/styles";
import { fadeAndScaleIn } from "~/styles/animations";
import { usePortalContext } from "../Portal";

const Popover = PopoverPrimitive.Root;

const PopoverAnchor = PopoverPrimitive.Anchor;

function PopoverTrigger(
  props: React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Trigger> & {
    ref?: React.Ref<React.ComponentRef<typeof PopoverPrimitive.Trigger>>;
  }
) {
  const { ref, children, ...rest } = props;
  return (
    <PopoverPrimitive.Trigger ref={ref} {...rest} asChild>
      {children}
    </PopoverPrimitive.Trigger>
  );
}
PopoverTrigger.displayName = PopoverPrimitive.Trigger.displayName;

type ContentProps = {
  /** The width of the popover, defaults to 380px. */
  width?: number;
  /** The minimum width of the popover, use instead of width if contents adjusts size. */
  minWidth?: number;
  /** The minimum height of the popover. */
  minHeight?: number;
  /** Whether the popover should be scrollable, defaults to true. */
  scrollable?: boolean;
  /** Shrink the padding of the popover */
  shrink?: boolean;
  ref?: React.Ref<React.ComponentRef<typeof PopoverPrimitive.Content>>;
} & React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>;

function PopoverContent(props: ContentProps) {
  const ref = React.useRef<React.ComponentRef<
    typeof PopoverPrimitive.Content
  > | null>(null);
  const timeoutRef = React.useRef<NodeJS.Timeout | undefined>(undefined);
  const container = usePortalContext();
  const {
    ref: forwardedRef,
    width,
    minWidth,
    minHeight,
    scrollable = true,
    shrink = false,
    sideOffset = 4,
    children,
    ...rest
  } = props;
  const resolvedWidth = width ?? (minWidth ? undefined : 380);

  const enablePointerEvents = React.useCallback(() => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    if (ref.current) {
      ref.current.style.pointerEvents = "auto";
    }
  }, []);

  const disablePointerEvents = React.useCallback(() => {
    if (ref.current) {
      ref.current.style.pointerEvents = "none";
    }
    // Fallback: re-enable pointer events after 500ms, onAnimationEnd is not always called.
    timeoutRef.current = setTimeout(() => {
      enablePointerEvents();
    }, 500);
  }, [enablePointerEvents]);

  return (
    <PopoverPrimitive.Portal container={container}>
      <StyledContent
        ref={mergeRefs([ref, forwardedRef])}
        sideOffset={sideOffset}
        $width={resolvedWidth}
        $minWidth={minWidth}
        $minHeight={minHeight}
        $scrollable={scrollable}
        $shrink={shrink}
        onAnimationStart={disablePointerEvents}
        onAnimationEnd={enablePointerEvents}
        {...rest}
      >
        {children}
      </StyledContent>
    </PopoverPrimitive.Portal>
  );
}
PopoverContent.displayName = PopoverPrimitive.Content.displayName;

type StyledContentProps = {
  $width?: number;
  $minWidth?: number;
  $minHeight?: number;
  $scrollable: boolean;
  $shrink: boolean;
};

const StyledContent = styled(PopoverPrimitive.Content)<StyledContentProps>`
  z-index: ${depths.modal};
  max-height: min(85vh, var(--radix-popover-content-available-height));
  transform-origin: var(--radix-popover-content-transform-origin);

  background: ${s("menuBackground")};
  box-shadow: ${s("menuShadow")};
  ${borderRadius(8)}
  outline: none;

  padding: ${({ $shrink }) => ($shrink ? "6px 0" : "12px 24px")};

  ${({ $width }) => $width && `width: ${$width}px`};
  ${({ $minWidth }) => $minWidth && `min-width: ${$minWidth}px`};
  ${({ $minHeight }) => $minHeight && `min-height: ${$minHeight}px`};

  ${({ $scrollable }) =>
    $scrollable
      ? `
      		overflow-x: hidden;
      		overflow-y: auto;
    		`
      : `
      		overflow: hidden;
    		`}

  &[data-state="open"] {
    animation: ${fadeAndScaleIn} 150ms cubic-bezier(0.08, 0.82, 0.17, 1);
  }
`;

export { Popover, PopoverAnchor, PopoverTrigger, PopoverContent };
