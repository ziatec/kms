import * as VisuallyHidden from "@radix-ui/react-visually-hidden";
import * as React from "react";
import styled from "styled-components";
import { Drawer as DrawerPrimitive } from "vaul";
import { depths, s, borderRadius } from "@shared/styles";
import Flex from "../Flex";
import Text from "../Text";
import { Overlay } from "./components/Overlay";
import { m } from "framer-motion";
import useMeasure from "react-use-measure";

/** Root Drawer component - all the other components are rendered inside it. */
const Drawer = (props: React.ComponentProps<typeof DrawerPrimitive.Root>) => (
  <DrawerPrimitive.Root {...props} />
);
Drawer.displayName = "Drawer";

/** Drawer's trigger. */
const DrawerTrigger = DrawerPrimitive.Trigger;

const DrawerHandle = DrawerPrimitive.Handle;

/** Drawer's content - renders the overlay and the actual content. */
function DrawerContent(
  props: React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Content> & {
    ref?: React.Ref<React.ComponentRef<typeof DrawerPrimitive.Content>>;
  }
) {
  const { ref, children, ...rest } = props;
  const [measureRef, bounds] = useMeasure();

  return (
    <DrawerPrimitive.Portal>
      <DrawerPrimitive.Overlay asChild>
        <Overlay />
      </DrawerPrimitive.Overlay>
      <DrawerPrimitive.Content ref={ref} asChild>
        <StyledContent
          animate={
            bounds.height
              ? {
                  height: bounds.height,
                  transition: { bounce: 0, duration: 0.2 },
                }
              : undefined
          }
        >
          <StyledInnerContent column ref={measureRef} {...rest}>
            {children}
          </StyledInnerContent>
        </StyledContent>
      </DrawerPrimitive.Content>
    </DrawerPrimitive.Portal>
  );
}
DrawerContent.displayName = DrawerPrimitive.Content.displayName;

/** Drawer's title shown in the center. */
function DrawerTitle(
  props: React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Title> & {
    ref?: React.Ref<React.ComponentRef<typeof DrawerPrimitive.Title>>;
  }
) {
  const { ref, hidden, children, ...rest } = props;

  const title = (
    <StyledText size="medium" weight="bold" as={TitleWrapper} justify="center">
      {children}
    </StyledText>
  );

  return (
    <DrawerPrimitive.Title ref={ref} {...rest} asChild>
      {hidden ? (
        <VisuallyHidden.Root>{title}</VisuallyHidden.Root>
      ) : (
        <>{title}</>
      )}
    </DrawerPrimitive.Title>
  );
}
DrawerTitle.displayName = DrawerPrimitive.Title.displayName;

const StyledText = styled(Text)`
  flex-shrink: 0;
`;

/** Styled components. */
const StyledContent = styled(m.div)`
  z-index: ${depths.menu};
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  min-width: 180px;
  max-width: 100%;
  min-height: 44px;
  max-height: 90vh;

  ${borderRadius(8)}

  background: ${s("menuBackground")};

  @media print {
    display: none;
  }
`;

const StyledInnerContent = styled(Flex)`
  padding: 6px;
  padding-bottom: calc(6px + var(--sab, 0px));
  height: 100%;
`;

const TitleWrapper = styled(Flex)`
  padding: 8px 0;
`;

export { Drawer, DrawerTrigger, DrawerHandle, DrawerContent, DrawerTitle };
