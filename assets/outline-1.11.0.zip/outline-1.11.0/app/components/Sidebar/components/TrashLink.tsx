import { observer } from "mobx-react";
import { TrashIcon } from "outline-icons";
import { useTranslation } from "react-i18next";
import DocumentDelete from "~/scenes/DocumentDelete";
import { DialogTitle } from "~/components/DialogTitle";
import useStores from "~/hooks/useStores";
import * as Scenes from "~/routes/scenes";
import { trashPath } from "~/utils/routeHelpers";
import { type DragObject, useDropRef } from "../hooks/useDragAndDrop";
import SidebarLink from "./SidebarLink";

function TrashLink() {
  const { policies, dialogs, documents } = useStores();
  const { t } = useTranslation();

  const [{ isDocumentDropping }, dropToTrashRef] = useDropRef({
    accept: "document",
    drop: async (item: DragObject) => {
      const document = documents.get(item.id);
      if (!document) {
        return;
      }

      dialogs.openModal({
        title: (
          <DialogTitle
            title={t("Delete {{ documentName }}", {
              documentName: document.noun,
            })}
            model={document}
          />
        ),
        content: (
          <DocumentDelete
            document={document}
            onSubmit={dialogs.closeAllModals}
          />
        ),
      });
    },
    canDrop: (item) => policies.abilities(item.id).delete,
    collect: (monitor) => ({
      isDocumentDropping: monitor.isOver(),
    }),
  });

  return (
    <div ref={dropToTrashRef}>
      <SidebarLink
        to={trashPath()}
        onClickIntent={Scenes.Trash.preload}
        icon={<TrashIcon open={isDocumentDropping} />}
        exact={false}
        label={t("Trash")}
        active={documents.active?.isDeleted}
        isActiveDrop={isDocumentDropping}
      />
    </div>
  );
}

export default observer(TrashLink);
