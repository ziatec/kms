import type { LocationDescriptor } from "history";
import * as React from "react";
import styled, { useTheme, css } from "styled-components";
import breakpoint from "styled-components-breakpoint";
import { ellipsis, hover, s } from "@shared/styles";
import { isMobile } from "@shared/utils/browser";
import { UnreadBadge } from "~/components/UnreadBadge";
import useClickIntent from "~/hooks/useClickIntent";
import { undraggableOnDesktop } from "~/styles";
import Disclosure from "./Disclosure";
import type { Props as NavLinkProps } from "./NavLink";
import NavLink from "./NavLink";
import {
  SidebarActions,
  hoveredOrMenuOpen,
  revealActionsOnHover,
} from "./SidebarActions";
import type { ActionFactory, ActionWithChildren } from "~/types";
import { ContextMenu } from "~/components/Menu/ContextMenu";
import { useTranslation } from "react-i18next";

/**
 * Returns the inline-start offset in pixels of a sidebar row's content at the
 * given nesting depth.
 *
 * @param depth The nesting depth of the row, 0-based.
 * @returns the offset in pixels.
 */
export function indentForDepth(depth: number): number {
  return depth * 16 + 12;
}

/**
 * Props for the SidebarLink component.
 * Extends NavLink props with additional sidebar-specific functionality.
 */
type Props = Omit<NavLinkProps, "to"> & {
  /** The location to navigate to when the link is clicked */
  to?: LocationDescriptor;
  /** Ref callback to access the underlying HTML element */
  innerRef?: (ref: HTMLElement | null | undefined) => void;
  /** Ref to the rendered link element */
  ref?: React.Ref<HTMLAnchorElement>;
  /** Callback fired when the link is clicked */
  onClick?: React.MouseEventHandler<HTMLAnchorElement>;
  /** Callback when we expect the user to click on the link. Used for prefetching data. */
  onClickIntent?: React.MouseEventHandler<HTMLElement>;
  /** Callback fired when the disclosure icon is clicked */
  onDisclosureClick?: React.MouseEventHandler<HTMLElement>;
  /** Icon to display on the left side of the link */
  icon?: React.ReactNode;
  /** Text label or content to display for the link */
  label?: React.ReactNode;
  /** Optional menu to display on hover or interaction */
  menu?: React.ReactNode;
  /** Whether to show an unread badge indicator */
  unreadBadge?: boolean;
  /** Whether to show action buttons on hover */
  $showActions?: boolean;
  /** Whether the link is disabled and non-interactive */
  disabled?: boolean;
  /** Whether the link is currently active */
  active?: boolean;
  /** If set, a disclosure will be rendered to the left of any icon */
  expanded?: boolean;
  /** Whether this link is the current active drop target for drag and drop */
  isActiveDrop?: boolean;
  /** Whether this link represents a draft document */
  isDraft?: boolean;
  /** Nesting depth level for indentation (0-based) */
  depth?: number;
  /** Whether to truncate the label text (default: true, causes overflow: hidden) */
  ellipsis?: boolean;
  /** Whether to automatically scroll this link into view if needed */
  scrollIntoViewIfNeeded?: boolean;
  /** Optional context menu action to display */
  contextAction?: ActionWithChildren | ActionFactory;
};

const activeDropStyle = {
  fontWeight: 600,
};

// Prevents the parent NavLink's mousedown handler from firing (which would
// navigate or toggle), without calling preventDefault — that would block the
// native HTML5 drag from initiating on the draggable row.
const stopPropagation = (ev: React.MouseEvent) => {
  ev.stopPropagation();
};

function SidebarLink({
  icon,
  onClick,
  onClickIntent,
  to,
  label,
  active,
  isActiveDrop,
  isDraft,
  menu,
  $showActions,
  exact,
  href,
  depth,
  className,
  expanded,
  onDisclosureClick,
  disabled,
  unreadBadge,
  contextAction,
  ellipsis = true,
  ref,
  ...rest
}: Props) {
  const hasDisclosure = expanded !== undefined;
  const { t } = useTranslation();
  const theme = useTheme();
  const [isInteractive, setIsInteractive] = React.useState(false);
  const { handleMouseEnter, handleMouseLeave } = useClickIntent(onClickIntent);
  const style = React.useMemo(
    () => ({
      paddingInlineStart: `${indentForDepth(depth || 0) - (icon ? 20 : 0)}px`,
      paddingInlineEnd: unreadBadge ? "32px" : undefined,
    }),
    [depth, icon, unreadBadge]
  );

  const unreadStyle = React.useMemo(
    () => ({
      insetInlineEnd: -20,
    }),
    []
  );

  const activeStyle = React.useMemo(
    () => ({
      color: theme.text,
      background: theme.sidebarActiveBackground,
      ...style,
    }),
    [theme.text, theme.sidebarActiveBackground, style]
  );

  const handleClick = React.useCallback(
    (ev: React.MouseEvent<HTMLAnchorElement>) => {
      if (onClick && !disabled && ev.isDefaultPrevented() === false) {
        onClick(ev);
      }
    },
    [onClick, disabled]
  );

  const handleDisclosureClick = React.useCallback(
    (ev: React.MouseEvent<HTMLElement>) => {
      if (!hasDisclosure) {
        return;
      }
      ev.preventDefault();
      ev.stopPropagation();
      onDisclosureClick?.(ev);
    },
    [onDisclosureClick, hasDisclosure]
  );

  const handleFocusCapture = (event: React.FocusEvent<HTMLElement>) => {
    if (event.target === event.currentTarget) {
      setIsInteractive(true);
    }
  };

  const DisclosureComponent = icon ? HiddenDisclosure : Disclosure;

  const content = (
    <Content>
      {hasDisclosure && (
        <DisclosureComponent
          expanded={expanded}
          onClick={handleDisclosureClick}
          onMouseDown={stopPropagation}
          tabIndex={-1}
        />
      )}
      {icon && <IconWrapper aria-hidden>{icon}</IconWrapper>}
      <Label $ellipsis={ellipsis}>{label}</Label>
      {unreadBadge && <UnreadBadge style={unreadStyle} />}
    </Content>
  );

  const innerContent = (
    <>
      {isInteractive ? (
        <ContextMenu action={contextAction} ariaLabel={t("Link options")}>
          {content}
        </ContextMenu>
      ) : (
        content
      )}
      {isInteractive && menu && (
        <SidebarActions $showActions={$showActions}>{menu}</SidebarActions>
      )}
    </>
  );

  if (!to) {
    return (
      <Link
        as={href ? "a" : "button"}
        $isActiveDrop={isActiveDrop}
        $isDraft={isDraft}
        $disabled={disabled}
        style={active ? activeStyle : style}
        onClick={handleClick}
        onMouseEnter={handleMouseEnter}
        onPointerEnter={() => setIsInteractive(true)}
        onFocusCapture={handleFocusCapture}
        onMouseLeave={handleMouseLeave}
        onDragEnter={handleMouseEnter}
        href={href}
        className={className}
        ref={ref}
        {...rest}
      >
        {innerContent}
      </Link>
    );
  }

  return (
    <Link
      as={NavLink}
      $isActiveDrop={isActiveDrop}
      $isDraft={isDraft}
      $disabled={disabled}
      style={active ? activeStyle : style}
      activeStyle={isActiveDrop ? activeDropStyle : activeStyle}
      onClick={handleClick}
      onActiveClick={handleDisclosureClick}
      onMouseEnter={handleMouseEnter}
      onPointerEnter={() => setIsInteractive(true)}
      onFocusCapture={handleFocusCapture}
      onMouseLeave={handleMouseLeave}
      onDragEnter={handleMouseEnter}
      exact={exact !== false}
      to={to!}
      href={href}
      className={className}
      ref={ref}
      {...rest}
    >
      {innerContent}
    </Link>
  );
}

// accounts for whitespace around icon
export const IconWrapper = styled.span`
  margin-inline-start: -4px;
  height: 24px;
  overflow: hidden;
  flex-shrink: 0;
  transition: opacity 200ms ease-in-out;
`;

const Content = styled.span`
  display: flex;
  align-items: start;
  position: relative;
  width: 100%;
  min-width: 0;
`;

// Stays over the icon while invisible so that a tap on the icon toggles, even
// on touch devices where there is no hover to reveal it first.
const HiddenDisclosure = styled(Disclosure)`
  inset-inline-start: initial;
  opacity: 0;
  margin-inline-start: -2px;
`;

const Link = styled.a<{
  $isActiveDrop?: boolean;
  $isDraft?: boolean;
  $disabled?: boolean;
}>`
  ${hoveredOrMenuOpen} {
    --background: ${s("sidebarHoverBackground")};
  }

  &[aria-current="page"] ${SidebarActions} {
    --background: ${s("sidebarActiveBackground")};
  }

  ${(props) => props.$isActiveDrop && `--background: ${props.theme.slateDark};`}

  display: flex;
  position: relative;
  text-overflow: ellipsis;
  font-weight: 475;
  padding: ${isMobile() ? 12 : 6}px 16px;
  border-radius: 4px;
  min-height: 30px;
  user-select: none;
  white-space: nowrap;
  background: var(--background);
  color: ${(props) =>
    props.$isActiveDrop ? props.theme.white : props.theme.sidebarText};
  font-size: 16px;
  cursor: var(--pointer);
  overflow: hidden;
  border: 0;
  width: 100%;
  ${undraggableOnDesktop()}

  ${(props) =>
    props.$disabled &&
    css`
      pointer-events: none;
      opacity: 0.75;
    `}

  ${(props) =>
    props.$isDraft &&
    css`
      &:after {
        content: "";
        position: absolute;
        inset: 0;
        pointer-events: none;
        border-radius: 4px;
        border: 1.5px dashed ${props.theme.sidebarDraftBorder};
      }
    `}

  svg {
    ${(props) => (props.$isActiveDrop ? `fill: ${props.theme.white};` : "")}
    transition: fill 50ms;
  }

  &: ${hover},
  &:has([data-state="open"]) {
    ${HiddenDisclosure} {
      opacity: 1;
    }
    ${HiddenDisclosure} + ${IconWrapper} {
      visibility: hidden;
      opacity: 0;
    }
  }

  ${breakpoint("tablet")`
    padding-block: 3px;
    padding-inline: 12px 8px;
    font-size: 14px;
  `}

  ${revealActionsOnHover}

  @media (hover: hover) {
    ${hoveredOrMenuOpen} {
      color: ${(props) =>
        props.$isActiveDrop ? props.theme.white : props.theme.text};
    }
  }
`;

const Label = styled.div<{ $ellipsis: boolean }>`
  position: relative;
  width: 100%;
  line-height: 24px;
  margin-inline-start: 2px;
  min-width: 0;
  text-align: start;

  ${(props) => props.$ellipsis && ellipsis()}

  * {
    unicode-bidi: plaintext;
  }
`;

export default SidebarLink;
