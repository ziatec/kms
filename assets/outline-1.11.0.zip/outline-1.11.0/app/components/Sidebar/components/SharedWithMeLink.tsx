import fractionalIndex from "fractional-index";
import type { Location } from "history";
import { observer } from "mobx-react";
import * as React from "react";
import type { match } from "react-router";
import { IconType, NotificationEventType } from "@shared/types";
import { determineIconType } from "@shared/utils/icon";
import type GroupMembership from "~/models/GroupMembership";
import UserMembership from "~/models/UserMembership";
import { useActiveSidebarContext } from "~/hooks/useActiveSidebarContext";
import useBoolean from "~/hooks/useBoolean";
import { useComputed } from "~/hooks/useComputed";
import useStores from "~/hooks/useStores";
import DocumentMenu from "~/menus/DocumentMenu";
import * as Scenes from "~/routes/scenes";
import {
  useDragMembership,
  useDropToReorderUserMembership,
  useDropToReparentDocument,
} from "../hooks/useDragAndDrop";
import SidebarExpansionContext, {
  useSidebarExpansionState,
} from "./SidebarExpansionContext";
import { useSidebarLabelAndIcon } from "../hooks/useSidebarLabelAndIcon";
import { DocumentTree } from "./DocumentTree";
import DocumentRow from "./DocumentRow";
import DropCursor from "./DropCursor";
import Folder from "./Folder";
import SidebarDisclosureContext, {
  useSidebarDisclosure,
  useSidebarDisclosureState,
} from "./SidebarDisclosureContext";
import { useSidebarContext, type SidebarContextType } from "./SidebarContext";
import { useSidebarNavigation } from "./SidebarNavigation";

type Props = {
  membership: UserMembership | GroupMembership;
  depth?: number;
};

function SharedWithMeLink({ membership, depth = 0 }: Props) {
  const { ui, collections, documents } = useStores();
  const { fetchChildDocuments } = documents;
  const [menuOpen, handleMenuOpen, handleMenuClose] = useBoolean();
  const { documentId } = membership;
  const isActiveDocument = useComputed(
    () => documentId === ui.activeDocumentId,
    [documentId, ui]
  );
  const activeSidebarContext = useActiveSidebarContext();
  const sidebarContext = useSidebarContext();
  const document = documentId ? documents.get(documentId) : undefined;

  const membershipDocuments = membership.documents;
  const expansion = useSidebarExpansionState(membershipDocuments);
  const isActiveDocumentInPath = useComputed(
    () =>
      ui.activeDocumentId
        ? membership.pathToDocument(ui.activeDocumentId).length > 0
        : false,
    [membership, ui]
  );

  const [expanded, setExpanded, setCollapsed] = useBoolean(
    isActiveDocumentInPath && activeSidebarContext === sidebarContext
  );

  const { event: disclosureEvent, onDisclosureClick } =
    useSidebarDisclosureState();

  useSidebarDisclosure(setExpanded, setCollapsed);

  React.useEffect(() => {
    if (isActiveDocumentInPath && activeSidebarContext === sidebarContext) {
      setExpanded();
    }
  }, [
    isActiveDocumentInPath,
    sidebarContext,
    activeSidebarContext,
    setExpanded,
  ]);

  React.useEffect(() => {
    if (documentId) {
      void documents.fetch(documentId);
      void membership.fetchDocuments();
    }
  }, [documentId, documents, membership]);

  React.useEffect(() => {
    if (isActiveDocument && membership.documentId) {
      void fetchChildDocuments(membership.documentId);
    }
  }, [fetchChildDocuments, isActiveDocument, membership.documentId]);

  const handleDisclosureClick = React.useCallback(
    (ev?: React.MouseEvent<HTMLElement>) => {
      ev?.preventDefault();
      ev?.stopPropagation();
      const willExpand = !expanded;
      if (willExpand) {
        setExpanded();
        if (ev?.altKey && membershipDocuments) {
          expansion.expandAll(membershipDocuments);
        }
      } else {
        setCollapsed();
        if (ev?.altKey) {
          expansion.collapseAll();
        }
      }
      onDisclosureClick(willExpand, !!ev?.altKey);
    },
    [
      expanded,
      setExpanded,
      setCollapsed,
      onDisclosureClick,
      expansion,
      membershipDocuments,
    ]
  );

  const parentRef = React.useRef<HTMLDivElement>(null);
  const reparentableNode = React.useMemo(
    () => document?.asNavigationNode,
    [document]
  );
  const [{ isOverReparent }, dropToReparent] = useDropToReparentDocument(
    reparentableNode,
    setExpanded,
    parentRef
  );

  const { icon } = useSidebarLabelAndIcon(membership);
  const [{ isDragging }, draggableRef] = useDragMembership(membership);

  const getIndex = () => {
    if (membership instanceof UserMembership) {
      const next = membership?.next();
      return fractionalIndex(membership?.index || null, next?.index || null);
    }
    return "";
  };
  const [reorderProps, dropToReorderRef] =
    useDropToReorderUserMembership(getIndex);

  const isActive = React.useCallback(
    (
      match: match | null,
      location: Location<{ sidebarContext?: SidebarContextType }>
    ) => !!match && location.state?.sidebarContext === sidebarContext,
    [sidebarContext]
  );

  const displayChildDocuments = expanded && !isDragging;

  const getNavigationItems = React.useCallback(
    () =>
      document
        ? [
            {
              id: document.id,
              url: document.path,
              title: document.title,
              sidebarContext,
              collapsedChildren: displayChildDocuments
                ? undefined
                : membershipDocuments,
            },
          ]
        : [],
    [document, sidebarContext, displayChildDocuments, membershipDocuments]
  );
  useSidebarNavigation(parentRef, getNavigationItems);

  if (!document) {
    return null;
  }

  const { icon: docIcon } = document;
  const label =
    determineIconType(docIcon) === IconType.Emoji
      ? document.title.replace(docIcon!, "")
      : document.titleWithDefault;
  const collection = document.collectionId
    ? collections.get(document.collectionId)
    : undefined;

  const childDocuments = membershipDocuments ?? [];
  const hasChildren = childDocuments.length > 0;

  const unreadBadge =
    document.unreadNotifications.filter(
      (notification) =>
        notification.event === NotificationEventType.AddUserToDocument
    ).length > 0;

  const menu = !isDragging ? (
    <DocumentMenu
      document={document}
      onOpen={handleMenuOpen}
      onClose={handleMenuClose}
    />
  ) : undefined;

  return (
    <DocumentRow
      documentId={documentId ?? ""}
      document={document}
      to={{ pathname: document.path, state: { sidebarContext } }}
      onClickIntent={Scenes.Document.preload}
      depth={depth}
      icon={icon}
      canEdit={false}
      label={label}
      unreadBadge={unreadBadge}
      expanded={expanded && !isDragging}
      hasChildren={hasChildren}
      onDisclosureClick={handleDisclosureClick}
      onExpand={setExpanded}
      onCollapse={setCollapsed}
      dragRef={draggableRef}
      isDragging={isDragging}
      parentRef={parentRef}
      dropToReparentRef={dropToReparent}
      isActiveDropTarget={isOverReparent}
      menu={menu}
      menuOpen={menuOpen}
      isActiveOverride={isActive}
    >
      <SidebarDisclosureContext.Provider value={disclosureEvent}>
        <SidebarExpansionContext.Provider value={expansion}>
          <Folder expanded={displayChildDocuments}>
            <DocumentTree
              nodes={childDocuments}
              depth={depth + 1}
              parentId={document.id}
              collection={collection}
              membership={membership}
            />
          </Folder>
        </SidebarExpansionContext.Provider>
      </SidebarDisclosureContext.Provider>
      {reorderProps.isDragging && (
        <DropCursor
          isActiveDrop={reorderProps.isOverCursor}
          innerRef={dropToReorderRef}
        />
      )}
    </DocumentRow>
  );
}

export default observer(SharedWithMeLink);
