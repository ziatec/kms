import { observer } from "mobx-react";
import * as React from "react";
import type Group from "~/models/Group";
import { ResolvedGroupIcon } from "~/components/Icons/GroupIcon";
import { useActiveSidebarContext } from "~/hooks/useActiveSidebarContext";
import Folder from "./Folder";
import Relative from "./Relative";
import SharedWithMeLink from "./SharedWithMeLink";
import SidebarContext, { groupSidebarContext } from "./SidebarContext";
import SidebarDisclosureContext, {
  useSidebarDisclosureState,
} from "./SidebarDisclosureContext";
import SidebarLink from "./SidebarLink";

type Props = {
  /** The group to render */
  group: Group;
};

const GroupLink: React.FC<Props> = ({ group }) => {
  const activeSidebarContext = useActiveSidebarContext();
  const sidebarContext = groupSidebarContext(group.id);
  const [expanded, setExpanded] = React.useState(
    activeSidebarContext === sidebarContext
  );

  const { event: disclosureEvent, onDisclosureClick } =
    useSidebarDisclosureState();

  const handleDisclosureClick = React.useCallback(
    (ev?: React.MouseEvent<HTMLElement>) => {
      ev?.preventDefault();
      setExpanded((e) => {
        const willExpand = !e;
        onDisclosureClick(willExpand, !!ev?.altKey);
        return willExpand;
      });
    },
    [onDisclosureClick]
  );

  React.useEffect(() => {
    if (activeSidebarContext === sidebarContext) {
      setExpanded(true);
    }
  }, [sidebarContext, activeSidebarContext, setExpanded]);

  return (
    <Relative>
      <SidebarLink
        label={group.name}
        icon={<ResolvedGroupIcon group={group} />}
        expanded={expanded}
        onClick={handleDisclosureClick}
        depth={0}
      />
      <SidebarContext.Provider value={sidebarContext}>
        <SidebarDisclosureContext.Provider value={disclosureEvent}>
          <Folder expanded={expanded}>
            {group.documentMemberships.map((membership) => (
              <SharedWithMeLink
                key={membership.id}
                membership={membership}
                depth={2}
              />
            ))}
          </Folder>
        </SidebarDisclosureContext.Provider>
      </SidebarContext.Provider>
    </Relative>
  );
};

export default observer(GroupLink);
