import fractionalIndex from "fractional-index";
import { observer } from "mobx-react";
import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import styled from "styled-components";
import type Collection from "~/models/Collection";
import Flex from "~/components/Flex";
import Error from "~/components/List/Error";
import PaginatedList from "~/components/PaginatedList";
import { createCollection } from "~/actions/definitions/collections";
import { useActiveSidebarContext } from "~/hooks/useActiveSidebarContext";
import useStores from "~/hooks/useStores";
import { type DragObject, useDropRef } from "../hooks/useDragAndDrop";
import DraggableCollectionLink from "./DraggableCollectionLink";
import DropCursor from "./DropCursor";
import Header from "./Header";
import PlaceholderCollections from "./PlaceholderCollections";
import Relative from "./Relative";
import SidebarAction from "./SidebarAction";
import SidebarContext from "./SidebarContext";
import SidebarLink from "./SidebarLink";
import Text from "@shared/components/Text";
import usePolicy from "~/hooks/usePolicy";

const headerActions = [createCollection];

function Collections() {
  const { auth, collections, policies, ui } = useStores();
  const activeSidebarContext = useActiveSidebarContext() ?? "collections";
  const { t } = useTranslation();
  const can = usePolicy(auth.team?.id);
  const orderedCollections = collections.allActive;

  const params = useMemo(
    () => ({
      limit: 100,
    }),
    []
  );

  const [
    { isCollectionDropping, isDraggingAnyCollection },
    dropToReorderCollection,
  ] = useDropRef({
    accept: "collection",
    drop: async (item: DragObject) => {
      void collections.move(
        item.id,
        fractionalIndex(null, orderedCollections[0].index)
      );
    },
    canDrop: (item) =>
      item.id !== orderedCollections[0]?.id &&
      !!policies.abilities(item.id).move,
    collect: (monitor) => ({
      isCollectionDropping: monitor.isOver(),
      isDraggingAnyCollection: monitor.canDrop(),
    }),
  });

  return (
    <SidebarContext.Provider value="collections">
      <Flex column>
        <Header
          id="collections"
          title={t("Collections")}
          actions={headerActions}
          primaryAction={createCollection}
        >
          <Relative>
            <PaginatedList<Collection>
              options={params}
              aria-label={t("Collections")}
              items={orderedCollections}
              activeItemId={
                activeSidebarContext === "collections"
                  ? ui.activeCollectionId
                  : undefined
              }
              loading={<PlaceholderCollections />}
              heading={
                isDraggingAnyCollection ? (
                  <DropCursor
                    isActiveDrop={isCollectionDropping}
                    innerRef={dropToReorderCollection}
                    position="top"
                  />
                ) : undefined
              }
              empty={
                // No need for empty state if we're displaying the createCollection action
                can.createCollection ? null : (
                  <SidebarLink
                    label={
                      <Text type="tertiary" size="small" italic>
                        {t("No collections")}
                      </Text>
                    }
                    onClick={() => {}}
                    depth={1.5}
                  />
                )
              }
              renderError={(props) => <StyledError {...props} />}
              renderItem={(item, index) => (
                <DraggableCollectionLink
                  key={item.id}
                  collection={item}
                  belowCollection={orderedCollections[index + 1]}
                />
              )}
            />
            <SidebarAction action={createCollection} depth={0} />
          </Relative>
        </Header>
      </Flex>
    </SidebarContext.Provider>
  );
}

export const StyledError = styled(Error)`
  font-size: 15px;
  padding: 0 8px;
`;

export default observer(Collections);
