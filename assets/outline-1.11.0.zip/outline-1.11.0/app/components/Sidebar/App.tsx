import { observer } from "mobx-react";
import { SearchIcon, HomeIcon, SidebarIcon } from "outline-icons";
import { useEffect, useState, useCallback } from "react";
import {
  DragActiveProvider,
  SidebarScrollProvider,
} from "./components/DragActiveContext";
import { useTranslation } from "react-i18next";
import { useHistory } from "react-router-dom";
import styled from "styled-components";
import { SidebarSection, UserPreference } from "@shared/types";
import { metaDisplay } from "@shared/utils/keyboard";
import Scrollable from "~/components/Scrollable";
import { navigateToImport } from "~/actions/definitions/navigation";
import { inviteUser } from "~/actions/definitions/users";
import useCurrentTeam from "~/hooks/useCurrentTeam";
import useCurrentUser from "~/hooks/useCurrentUser";
import usePolicy from "~/hooks/usePolicy";
import useStores from "~/hooks/useStores";
import TeamMenu from "~/menus/TeamMenu";
import * as Scenes from "~/routes/scenes";
import { homePath, searchPath } from "~/utils/routeHelpers";
import TeamLogo from "../TeamLogo";
import Tooltip from "../Tooltip";
import Sidebar from "./Sidebar";
import ArchiveLink from "./components/ArchiveLink";
import Collections from "./components/Collections";
import DraggableSection, {
  normalizeSidebarSectionOrder,
} from "./components/DraggableSection";
import { DraftsLink } from "./components/DraftsLink";
import DragPlaceholder from "./components/DragPlaceholder";
import { DismissableSidebarAction } from "./components/DismissableSidebarAction";
import HistoryNavigation from "./components/HistoryNavigation";
import Section from "./components/Section";
import SharedWithMe from "./components/SharedWithMe";
import SidebarButton from "./components/SidebarButton";
import SidebarLink from "./components/SidebarLink";
import { SidebarNavigationProvider } from "./components/SidebarNavigation";
import Starred from "./components/Starred";
import ToggleButton from "./components/ToggleButton";
import TrashLink from "./components/TrashLink";
import useMobile from "~/hooks/useMobile";

function AppSidebar() {
  const { t } = useTranslation();
  const { documents, ui, collections } = useStores();
  const team = useCurrentTeam();
  const user = useCurrentUser();
  const can = usePolicy(team);
  const history = useHistory();
  const isMobile = useMobile();

  const handleSearchClick = useCallback(() => {
    const basePath = searchPath();
    const { pathname, search } = history.location;
    if (pathname.startsWith(basePath) && (search || pathname !== basePath)) {
      history.push(basePath);
    }
  }, [history]);

  useEffect(() => {
    void collections.fetchAllIfNeeded();

    if (!user.isViewer) {
      void documents.fetchDrafts();
    }
  }, [documents, collections, user.isViewer]);

  // Hold the scroll element in state so the SidebarScrollProvider can
  // re-render descendants with it.
  const [scrollArea, setScrollArea] = useState<HTMLElement | null>(null);

  const sectionOrder = normalizeSidebarSectionOrder(
    user.getPreference(UserPreference.SidebarSectionOrder, [])
  );

  const sectionContent = {
    [SidebarSection.Starred]: <Starred />,
    [SidebarSection.SharedWithMe]: <SharedWithMe />,
    [SidebarSection.Collections]: <Collections />,
  };

  return (
    <Sidebar hidden={!ui.readyToShow}>
      <DragActiveProvider>
        <DragPlaceholder />

        <TeamMenu>
          <SidebarButton
            title={team.name}
            image={<TeamLogo model={team} size={24} alt={t("Logo")} />}
          >
            {isMobile ? null : (
              <Tooltip
                content={t("Toggle sidebar")}
                shortcut={`${metaDisplay}+.`}
              >
                <ToggleButton
                  position="bottom"
                  image={<SidebarIcon />}
                  aria-label={
                    ui.sidebarCollapsed
                      ? t("Expand sidebar")
                      : t("Collapse sidebar")
                  }
                  style={{ paddingInline: 4 }}
                  onClick={() => {
                    ui.toggleCollapsedSidebar();
                    (document.activeElement as HTMLElement)?.blur();
                  }}
                />
              </Tooltip>
            )}
          </SidebarButton>
        </TeamMenu>
        <Overflow>
          <Section>
            <SidebarLink
              to={homePath()}
              icon={<HomeIcon />}
              exact={false}
              label={t("Home")}
              onClickIntent={Scenes.Home.preload}
            />
            <SidebarLink
              to={searchPath()}
              icon={<SearchIcon />}
              label={t("Search")}
              exact={false}
              onClick={handleSearchClick}
              onClickIntent={Scenes.Search.preload}
            />
            {can.createDocument && <DraftsLink />}
          </Section>
        </Overflow>
        <Scrollable flex shadow ref={setScrollArea}>
          <SidebarScrollProvider value={scrollArea}>
            <SidebarNavigationProvider>
              {sectionOrder.map((section) => (
                <DraggableSection key={section} section={section}>
                  {sectionContent[section]}
                </DraggableSection>
              ))}
              {can.createDocument && (
                <Section auto>
                  <ArchiveLink />
                </Section>
              )}
            </SidebarNavigationProvider>
            <Section>
              {can.createDocument && <TrashLink />}
              <DismissableSidebarAction
                id="sidebar-import-hidden"
                action={navigateToImport}
              />
              <DismissableSidebarAction
                id="sidebar-invite-hidden"
                action={inviteUser}
              />
            </Section>
          </SidebarScrollProvider>
        </Scrollable>
      </DragActiveProvider>
      <HistoryNavigation />
    </Sidebar>
  );
}

const Overflow = styled.div`
  overflow: hidden;
  flex-shrink: 0;
`;

export default observer(AppSidebar);
