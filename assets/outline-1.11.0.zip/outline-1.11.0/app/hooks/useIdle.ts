import { throttle } from "es-toolkit/compat";
import { useState, useRef, useCallback, useEffect } from "react";
import { Minute } from "@shared/utils/time";

const activityEvents = [
  "click",
  "mousemove",
  "keydown",
  "DOMMouseScroll",
  "mousewheel",
  "mousedown",
  "touchstart",
  "touchmove",
  "focus",
];

/**
 * Hook to detect user idle state.
 *
 * @param timeToIdle The time in ms until idle
 * @param events The events to listen to
 * @returns boolean if the user is idle
 */
export default function useIdle(
  timeToIdle: number = 3 * Minute.ms,
  events = activityEvents
) {
  const [isIdle, setIsIdle] = useState(false);
  const timeout = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  const onActivity = useCallback(() => {
    if (timeout.current) {
      clearTimeout(timeout.current);
    }

    timeout.current = setTimeout(() => {
      setIsIdle(true);
    }, timeToIdle);
  }, [timeToIdle]);

  useEffect(() => {
    const handleUserActivityEvent = throttle(() => {
      setIsIdle(false);
      onActivity();
    }, 1000);

    events.forEach((eventName) =>
      window.addEventListener(eventName, handleUserActivityEvent)
    );

    // Start the countdown immediately, otherwise the user is never considered
    // idle unless activity occurs after mount.
    onActivity();

    return () => {
      handleUserActivityEvent.cancel();
      if (timeout.current) {
        clearTimeout(timeout.current);
      }
      events.forEach((eventName) =>
        window.removeEventListener(eventName, handleUserActivityEvent)
      );
    };
  }, [events, onActivity]);

  return isIdle;
}
